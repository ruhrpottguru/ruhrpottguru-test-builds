# RuhrpottGuru Android · Testversion 0.9.0
Stand: 19.10.2026. Installierbare Test-App, keine Play-Store-Version.

Eine gemeinsame APK mit eigenen Kotlin/Compose-Ansichten für Start, Standort und alle fünf Hauptkategorien Events, Food, Highlights, Kultur und Aktivitäten, Suche/Filter und Details. Keine vollständige Website angezeigt. Zeitreise als eigene native Kartenansicht ergänzt.

Start: Events/Food → Trinkhallen-Radar → Highlights/Kultur → Industriekultur → Aktivitäten. Neue realistische Symbolmotive, orange Titel, Original-Logo, nur dunkles Design. Burger ohne Wortbeschriftung, oben rechts verankert, vier aufklappbare Gruppen.

Food: GPS, 53 Städte, PLZ oder Adresse; 1/2,5/5/10/25/50 km, Standardradius wie im Web 5 km. Keine Abfrage ohne Standort. Standort und Radius werden gemeinsam übernommen, alte Antworten nach Wechsel verworfen. GPS nutzt nur einen frischen Fix, zehn Sekunden Wartezeit, keine letzte bekannte Position oder Hintergrundortung. Nach Neustart mit GPS-Modus GPS erneut ermitteln. Manuelle Auswahl und Radius bleiben erhalten; keine vollständige Straße und kein GPS-Verlauf gespeichert. Standort aus 0.1 bitte einmal neu auswählen.

## Gemeinsame Regeln
Unveränderte Live-Snapshots runtime.js und api.js vom 19.10.2026. Entfernungssortierung und Kategorie-Filterprädikat aus CategoryView unverändert extrahiert und mit jeweiligem Kategorie-Kontext umschlossen. Herkunft/SHA256: app/src/main/assets/shared/source-manifest.json. Originale: shared-source/. Regenerieren: python3 tools/sync-shared.py.

Eine unsichtbare lokale WebView dient ausschließlich als JavaScript-Rechner. Keine Website geladen, kein Netzwerk-/Datei-/Content-Zugriff und keine JavaScript-Bridge. Alle sichtbaren Ansichten sind Compose. Ortsbilder werden mit Coil 3.1.0 (Compose, OkHttp, SVG; passend zum bestehenden Kotlin-Stand) geladen und gecacht. native-adapter.js erstellt Anzeigeobjekte, keine eigene Klassifikation oder Rangfolge.

Native HTTPS verwendet places/home mit category=food/highlights/culture/activities und limit=1500, postcode-location, address-location-token und address-location. Adresstoken pro Anfrage frisch holen. Kein Ort wird wegen fehlendem Bild entfernt. Website-, Menü-, Reservierungs- und Routenbuttons sind explizite externe Aktionen. Anrufen/Teilen verwenden Android.

## Noch offen
Weitere Specials, globale Suche/Karte, Impressum und Datenschutz sind noch nicht fertig. Zeitreise ist ab 0.7 nativ enthalten. Keine automatische WordPress-Menüsynchronisierung oder verifizierten App-Links.

Food-Details zeigen den gemeinsamen places/home-Bestand. Die native Detailansicht übernimmt nun die vorhandene food-info-Anreicherung und Community-/Änderungsformulare. Keine vollständige Gleichheit aller Website-Detailfunktionen behauptet. Spätere Änderungen der Website-JavaScript-Regeln müssen kontrolliert übernommen werden; Backend-Daten bleiben live.

## Bilder
Sieben neue KI-generierte generische Symbolmotive, keine dokumentarischen Fotos konkreter Betriebe/Events. Prompts: ASSET_MANIFEST.json, Verwendung: BILDNACHWEISE.md. Places-Bilder kommen wie auf der Webseite aus dem gemeinsamen Datenbestand, einschließlich vorhandener Galerie-, Ausschnitt- und Nachweisfelder. Fehlende oder nicht ladbare Bild-URLs nutzen den bestehenden food-media-Resolver mit derselben Anfrage und Antwortprüfung; maximal drei parallele Auflösungen. Keine neue Bildsuche oder Auswahl nach einer eigenen Quellenliste. KI-Erzeugung ist keine pauschale rechtliche Rechtegarantie. Logo aus vorhandenem Nutzerprojekt. Quellen-/Lizenzpflichten der gemeinsamen Ortsdaten bleiben maßgeblich.

## Bauen
JDK17, Android SDK36, Build Tools36.0.0, Gradle8.13, AGP8.13.2, Kotlin2.1.20. In Android Studio öffnen, lokalen SDK-Pfad setzen.

    ./gradlew :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
    node tests/shared-food.test.cjs
    node tests/shared-events.test.cjs
    node tests/shared-highlights.test.cjs
    node tests/shared-categories.test.cjs
    node tests/shared-details.test.cjs
    node tests/shared-time-travel.test.cjs
    node tests/shared-radar.test.cjs

APK: app/build/outputs/apk/debug/app-debug.apk. Node-Test mit anonymer Stadtfixture: Sortierung, Filter, Tags, fehlende Bilder, Datenersetzung. Geräteabnahme separat in GERAETETEST.md.

Paket de.ruhrpottguru.testapp, versionCode10, 0.9.0-test; Android8/API26+, targetSdk36. Testschlüssel aus 0.1 für Updates erhalten: signing/test-debug.jks, Testkennwort android, Alias androiddebugkey. Niemals Produktionsschlüssel verwenden. Keine WordPress-/Backendänderung.

## Korrektur 0.2.1
Food-Liste und Detailansicht zeigen vorhandene DB-Fotos. Details enthalten die vorhandene Galerie, Credits und Quellenlink. Der orange Schließen-X-Button sitzt dauerhaft oben rechts und führt in dieselbe Ergebnisliste zurück. User-Screenshot bestätigt, dass 0.2 auf dem Gerät die Food-Liste und GPS-Kontext anzeigt; kein Nachweis der neuen 0.2.1-Gerätefunktionen.

## Events 0.3
Events aus POST /events mit dem vorhandenen Standort, dessen Stadt und maxRadiusKm. Native Listen benutzen die unverändert extrahierte Kategorie-Pipeline: normalizeEvent, Zulassung abgelaufener/kommender Termine, cityScope ohne erfundene Koordinate, Deduplizierung, nachgewiesene Heute-/Morgen-Vorkommen, kollabierte spätere Serien, bestehende Dringlichkeit/Entfernungsreihenfolge und Radiusgrenze. Keine Bilderabhängigkeit der Zulassung. Keine neue eigene Events-Suchmaschine.

Native Filter: Text, Event-Art, Themen, Heute, Morgen, Wochenende und Kalender-Zeitraum. Alle Datumsgrenzen/Prädikate stammen aus dem bestehenden CategoryView. Komponenten für Datums-/Preisformatierung, Tagesereignisse und Kalenderdaten sind unverändert extrahiert. Tickets, Veranstalter-/Quellen-/Dokumentlinks und vorhandene Daten werden übernommen. Keine automatische Kalenderbuchung: der native Button öffnet eine vorausgefüllte Kalender-App zur Nutzerbestätigung, ohne Lese-/Schreibberechtigung für Kalender. Tagesereignisse werden mit erhaltenen Datumsgrenzen übergeben, zeitgebundene Termine ohne bekanntes Ende erhalten keine erfundene Dauer.

Weitere Termine öffnen über GET /events/<id>/related und den vorhandenen share-item-Readmodel-Aufruf mit token=e<id> im selben nativen Detail. Liste/Filter/Standort darunter bleiben erhalten. Source main.js ist als Provenienznachweis beigefügt. Rückkehr per X oder Android-Zurück.

Bilder bleiben Originale aus normalizeEvent und dem vorhandenen lokalen/optionalen asynchronen Medienpass. Event-Pool und Reihenfolge bleiben davon unberührt. Kein neuer Fotoquellenfilter. Originäre ET4/ODF-Bilder bleiben vorrangig. max. drei native Medien-Abfragen gleichzeitig, keine zusätzliche Live-Event-Bildsuche pro DB-Karte.

Neu generieren: python3 tools/sync-shared.py (führt sync-events.py mit aus). Android-Build, Lint, zwei JUnit-Tests, bestehende Food-Regressionsfälle und die neue Event-Regression sind die lokalen Prüfschritte. Kein Android-Gerät/Emulator angebunden; E2E-Geräteabnahme bleibt offen. Diese Version ist ein Testbuild, keine Produktions-/Store-Freigabe.

## Highlights 0.4
Eigene Highlights-Ansicht über Startkachel und Burger → Entdecken. Gemeinsame Standort-/Radiusauswahl und POST places/home mit category=highlights, limit=1500. normalizePlace, Entfernungssortierung und CategoryView-Prädikat bleiben Original-Webregeln, mit Highlights-Kontext. Die vollständige Kategorie erhält keinen zusätzlichen Home-Mindestradius oder künstlichen Ersatzbestand. Typ, Thema, Text, Pagination, native Details und festes X; Route starten, externe offizielle Website, Anrufen und Teilen aus vorhandenen Feldern.

Bilder, Galerie, Ausschnitte, Credits und Quellen aus demselben DB-Bestand wie im Web. Fehlende Bilder verstecken keine Orte. Der unveränderte asynchrone resolveItemMedia läuft für Highlights über nativen HTTPS-Transport, einschließlich place-info zum Ermitteln einer offiziellen Website und anschließend food-media; allowSymbolic bleibt wie im Original false. Der Adapter setzt nur Medien, verändert keine Identität, Kategorie, Sortierung oder Filter. Alte Antworten nach Kategorie-/Standortwechsel werden verworfen. Preise stammen aus charge/fee, unbekannte bleiben unbekannt. Zusätzliche place-info-Textanreicherung im Detail und redaktionelle Web-Inhalte sind nicht Bestandteil dieses DetailOverlay-Vertrags.

Live-Quellen runtime/api/views/components erneut unverändert bestätigt. Regression mit Wesel5/25km und Essen5km: 122 Kandidaten, 195 Filterfälle, 117 Originalbilder, leere/kleine Listen, fehlende Bilder, unbekannte Preise, zweistufige Medienauflösung mit parallelen Identitäten und Fehlerfall. Food und Events weiterhin bestanden. Keine Android-Geräteprüfung behauptet.

## Alle Hauptkategorien 0.5
Kultur und Aktivitäten über die vorhandenen Startkacheln und Burger → Entdecken aktiviert. Die fünf Kategorien teilen native Anzeige, GPS/Stadt/PLZ/Adresse/Radius, Filter, Galerie/Quellen, Details, X, externe Route/Website/Anrufen/Teilen. Jede Kategorie lädt mit eigenem category-Wert. Backend-Klassifikation bleibt maßgeblich; die volle Kategorienansicht übernimmt keine Home-Kurzliste oder Home-Radius-/Diversitätsregeln. normalizePlace, sortDistance und CategoryView-Prädikat bleiben unverändert aus dem aktuellen Web-Bestand.

Aktivitäten übernehmen placeOpeningStatus einschließlich publicOutdoorMode: öffentliche geeignete Sportflächen zeigen „Zugang & Nutzungszeiten“. Unbekannte Zeiten werden nicht als 24/7 dargestellt, privater/Indoor-/gebührenpflichtiger Zugang wird nicht durch eine neue App-Regel als öffentlich gewertet. Keine neue Zulassung oder eigene Fitness-/Erlebnis-Klassifikation.

Der bereits in 0.4 für Highlights integrierte Original-Medienresolver wird auch für Kultur/Aktivitäten über denselben nativen Transport ausgeführt. DB-Bildfelder und Nachweise bleiben vorrangig, keine neuen Symbolfotos für die beiden Kategorien. Die interne Bezeichnung highlightsMedia* bleibt aus Kompatibilitätsgründen erhalten. Das zusätzliche DTO-Feld hoursHeading stammt direkt aus placeOpeningStatus.

Neue Regression: Kultur/Aktivitäten in Wesel5/25km, Essen5km, Dortmund5km – insgesamt 1.285 Kandidaten über acht Fixtures (keine globale eindeutige Gesamtzahl), 1.635 Filterfälle inklusive Kombinationen, 533 Originalbilder/Galerieeinträge, 456 vorhandene Credits. Exakte Anfragekörper des zweistufigen Web-Medienresolvers, öffentliche Nutzungszeiten, leere/kleine Listen, fehlende Bilder, unbekannte Preise, Pagination und Kategorienwechsel geprüft. Food/Event/Highlights-Regression unverändert bestanden. Gerätetest bleibt offen.

## Detail-Angleichung 0.6
Aktuellen Web-DetailOverlay gelesen und native Reihenfolge angeglichen: Galerie/Titel → obere Aktionen → optionaler Industriekulturhinweis → Adresse und Öffnungs-/Nutzungszeiten bzw. Veranstaltungshinweis → „Darum geht’s“ → Event-Downloads/Kalender/Veranstalter/weitere Termine/„Auf einen Blick“/Quelle oder Orts-Events/Community/Mitmachen → „Mehr davon entdecken“. Native Darstellung bleibt Compose; keine Webseite eingebettet.

Food-info-Anfrage und Prioritäten aus Original-Code; offizielle Website, Menü, Reservierung, Zeiten und vorhandene offizielle Tags. Event-Kontakte mit Adresse, Telefon, E-Mail und Mitwirkendenlinks. Glance-Fakten unverändert aus Originalfunktion, keine erfundenen Gratis-/Zugangs-/Öffnungsfakten. Spezieller offizieller Industriekultur-Standortlink im Detail.

Orts-Events: unverändertes place-events.js (Quellsnapshot und Hash beigefügt), Alias-/Stadt-/Koordinaten-/Zeitgrenzen, Deduplizierung, Sortierung, 1-km-Kandidatenabruf und zweiminütiger Cache innerhalb des jeweiligen Datenkontexts. Native Transporttickets lösen auch nach Schließen/Reopen den ursprünglichen Promise auf; die UI verwirft alte Antworten. Bei Kategorie-/Standort-/Neuladen wird der Transportkontext samt Cache verworfen, ohne fachliche Matching-Regeln zu verändern. Zugeordnete Events öffnen nativ; weitere Termine auch aus gespeicherten Events ohne ausgewählten Standort.

Merkliste lokal, maximal100 Einträge wie Web, mit eigener Ansicht „Mein Pott“. Kein Login/Abgleich mit Web-Lokalspeicher. Gespeicherte IDs mit vorhandenem Share-Descriptor werden beim Öffnen über share-item frisch geladen; übrige Einträge verwenden ihren gespeicherten öffentlichen Places-Datensatz. Getrennte Detail-Schlüssel verhindern Überschreiben einer aktuellen Kategorie bei gleicher Place-ID. Detail-Tags führen zur fachlich richtigen Kategorie.

Teilen/„Komm rum“ verwendet exakt den vorhandenen Text-/URL-Generator mit optionaler Nachricht und30/60/120Minuten/keiner Angabe; nativer Android-Teilen-Dialog. Kein öffentlicher Live-Standort, Treffen-Backend oder automatische Nachricht. Kalenderübergabe bleibt native Android-Aktion.

Community: vorhandene freigegebene Beiträge und Galerie/Instagram anzeigen; Community-Beitrag und Ortsdaten-/Fotoeinsendung als native Formulare. Konfiguration, Pflichtfelder, Validierung, Multipart-Feldnamen, Rechte-/Einwilligungsflags und Moderations-/E-Mail-Bestätigungsablauf aus Original-Web-Code. User wählt Dateien im Android-Picker; Optimierung nur lokal im Arbeitsspeicher, maximal5 Bilder,20MB Ausgang,2400px/2MB Ausgabe WebP, weißer Alphahintergrund, Seitenverhältnis erhalten. Unterstützte HEIC/HEIF vom Gerätecodec abhängig. Kein Originalbild/EXIF/GPS-Verlauf gespeichert. Nur ausdrücklicher Formularbutton sendet, keine automatische Wiederholung. Feedback nutzt frischen feedback-token und beta-feedback, kein Testfeedback gesendet.

Neue Tests vergleichen176 echte Original-Web-Komponentenbäume mit nativen Daten aus allen5Kategorien; zwölf negative Formularfälle und weitere Rechte-/Preis-/Matching-/Einladungs-/Cache-/Veraltungsfälle. Food-info, Community, Orts-Event-Feed und Feedbacktoken read-only live200. Test-UCG/Uploads/Einladungen/Feedback wurden nicht verschickt. Gerätetest und echter Upload-/Freigabe-/E-Mail-Ablauf bleiben offen; keine allgemeine visuelle oder E2E-Gleichheit behauptet.

## Zeitreise 0.7
Eigene Compose-Karte mit sieben sichtbaren Luftbildständen: Aktuell,2009,1990,1980,1969,1952,1926. Originale RVR-/NRW-Layer, Aufnahmezeiträume und Quellenhinweise, EPSG3857/256px/Zoom9–20 wie Leaflet. Schieben, Pinch/Plus/Minus, Vollbild, eigene Stadt-/PLZ-/Adresssuche und Marker. Keine Rückschreibung dieser Suche in Kategorie-Standort oder Radius. Der App-Standort kann ausdrücklich übernommen werden. Aktuell bedeutet neuester verfügbarer Dienststand, kein erfundenes Aufnahmejahr.

Originaler18Byte-Share-Encoder mit getrenntem Kartenmittelpunkt/Marker; /z/-Links und alte Querylinks einfügen oder über unverifizierten Android-Intent öffnen. Keine behauptete automatische App-Link-Zuordnung. Bestehendes Backend liefert Vorschau; Live-Link und1200x630-Vorschaubild geprüft. OG:url bleibt bestehende generische Web-Adresse; keine SEO-/Backendänderung.

Sieben RVR-Kacheln live200. NRW-Zusatzlayer1980 lieferte hier503; originaler RVR1969-Untergrund bleibt erhalten, Beschriftung nennt regionale Ergänzung und Fehlerhinweis. Keine vollständige NRW-Abdeckung behauptet. Quellen-/Lizenzdialog enthält RVR-Namensnennung2.0 und die jeweiligen Originalhinweise sowie Leaflet-BSD-Lizenz. Tilecache begrenzt im Speicher, abgelöste Abrufe werden verworfen/abgebrochen. Geräteabnahme für Gesten, Rendering, Rotation, Netzwerkwechsel und OS-Teilen noch offen.

## Büdchen / Imbiss0.8
Beide Specials von Start und Burger nativ verfügbar. Eigene bestehende Endpunkte places/buedchen(limit200) und places/wurst(limit600); nur bei originalem404/no-route Imbiss-AJAX-Readfallback. Keine Food-Gesamtmenge als Ersatz. Originale Qualität: Büdchen verified/TierA, TierB füllt nur auf12, ausgeschlossene Kandidaten kommen durch Filter nicht hinzu. Schnellfilter mit originaler Trennung geöffnet vs. Sortiment; unbekannte Zeiten bleiben unbekannt.

Radar mit originalem WP-Kartenproxy, ©OpenStreetMap, Straßenzoom14/15/16 nach Radius, Zoom10–18, zwei Finger zum Bewegen/Zoomen, API-Viewportabfrage erst nach Loslassen350ms. Kartenmittelpunkt/halbe Diagonale wie Web,0,5–50km. Markerüberlappungen unter24CSSpx nicht klickbar, näher zoomen; maximal120 Marker. Standortpunkt/Rücksetzen. Viewportsuche schreibt globalen Ort/Radius nicht um. Überholte Feedantworten werden verworfen. Filter reduzieren die feste Qualitätsmenge.

Büdchen-Details: echte Fotos/Galerie/Credits, Adresse, Öffnungsstatus, belegte Ausstattung, OSM-Route, Website, Teilen/Komm rum, Merken und vorhandenes Daten-/Fotobeitragsformular. Festes oranges X. Imbiss: sechs angebotabhängige Spezialitätenfilter, Suche in Name/Stadt/Adresse/Speisekategorien, Entfernung/Neu-im-Radar wie Original; bekannte DB-Fotos, Geprüft/ImRadar-Marker, Standarddetails und moderierter Stammbudenvorschlag. Keine Testeinsendung ausgeführt.

Zeitreisekachel: echte unveränderte RVR1952-Luftbilddatei Essen/Zollverein statt generischem Fördergerüst. Historischer Gesamtbestand1951–1980, überwiegend1952; sichtbarer Nachweis ©Regionalverband Ruhr/dl-de/by-2-0. Keine exakte tages-/jahresgenaue Aufnahmebehauptung. „Link laden“-Pfeil aus Kopf entfernt; geteilten Link im Quellenmenü weiterhin einfügen.

Live20.10.2026: alle sieben maßgeblichen Web-Quelldateien bytegleich zum gesicherten Stand; sechs Feeds200, OSM-Proxy256px200, RVR-Lizenz-Capabilities200. 195 echte Original-Webansicht-Filter-/Sortiervergleiche mit Wesel5/25km und Essen5km. Vorhandene Regressionen erneut bestanden. Android-Gesten/Layout/Rotation/OS-Handoffs und tatsächliche Moderationsannahme weiterhin Geräteprüfung. Keine eingebettete Webseite, keine Backend-/SEO-/Datenquellenänderung.

Büdchen-/Imbissfilter und Imbisssortierung bleiben beim Radius-/Standortwechsel wie im Web innerhalb der geöffneten Themenwelt erhalten; die neue öffentliche Qualitätsmenge wird am neuen Ort neu ermittelt. Ein Kategorienwechsel startet deren eigenen Kontext. Markerübertragung an den nativen Kartenteil enthält nurID/Titel/Koordinate; keine unnötigen kompletten Detailobjekte.

## Bildtransport0.9
Gemeinsamer Coil-ImageLoader über die Android-ApplicationFactory für Listen, Details/Galerien, gespeicherte Orte und Radar. Ehrliche Kennung RuhrpottGuru/0.9.0 (+https://www.ruhrpottguru.de/) statt generischemOkHttp-User-Agent. Bildabrufe mitHTTP-Standardport werden vor dem Transport aufHTTPS desselbenHosts/Pfads/Queries umgestellt; kein Klartextverkehr und keinHTTPS→HTTP-Redirect. Die tatsächlicheHTTPS-Antwort/derDecoder entscheidet, ob dieQuelle einBild liefert. Kein neuesDB-Bildfeld und kein neuerFotoanbieter. Standard-TLS bleibt aktiv.

Originaler Places-Resolver und dessen Anfragekörper/Antwortprüfung bleiben unverändert. Die alteID-Sperre wurde durch eine begrenzteVersuchsverwaltung ersetzt: maximal2Resolverversuche proID/Datenkontext, nie paralleleDoppeljobs. TemporäreNetz-/408-/429-/5xx-Fehler erlauben einen verzögertenzweitenVersuch; reguläres„keinBild“ löst keineSchleife aus. Ein nach Auflösung gescheitertesBild kann den verbliebenenVersuch nutzen. AlteTransporttickets undCallbacks nach Datenwechsel werden verworfen. Der Imbisszweig und dieDB-Event-Regel erhalten ihre bestehenden Resolvergrenzen.

Bilddatei-UI: maximal1automatischerWiederholungsversuch nach transientemFehler jegeöffneterBildkomponente/URL; danach „Bild erneut laden“ als bewussteAktion. Wiederholungen umgehen lokalenBildcache. Keine automatischeWiederholung vonUploads/Feedback/Formularen. Fotos/Crops/Galerie/Credits/Lizenzen und alle fachlichenDatenregeln bleiben erhalten.

Die Diagnose0.8 ist alsQA/Bilddiagnose-2026-10-20 beigefügt. DieseKorrektur beseitigt Transport-/Wiederholungsfehler, füllt aber keine ungeprüften oder fehlendenQuellbilder auf. BildloseTreffer bleiben sichtbar. Live-Nachweise: Image-Live-0.9.json. Tests: MediaAttemptGateTest und ImageTransportTest (inkl.echtemTLS-Testserver), vorhandeneRegressionssuiten. Kein Android-Gerät/Emulator: wirklichesCoil-Rendering/Netzwechsel/Galerie/Scrollen weiter manuell prüfen.

## Navigation 0.10
Vier am Burger verankerte, aufklappbare Gruppen. Verfügbare Ziele nutzen bestehende native Ansichten. Nicht fertige Suche/Specials sind vor Klick als „In Vorbereitung“ markiert und deaktiviert; Suche leitet nicht mehr zu Food um. Zurück schließt zuerst das Menü. Menühöhe wird für kleine Displays begrenzt. Home-Platzhalter ebenfalls deaktiviert. App-Info, Bildnachweise, Impressum und Datenschutz sind eigene scrollbar lesbare native Textansichten. Original-Webrechtstexte vom20.10.2026 mit bewusstem Browserlink; zusätzliche App-Funktionshinweise sind keine rechtliche Beta-Abnahme. Kategorie-/Daten-/Bildregeln unverändert. Gerätetest offen.

## Kompakte Kopfzeile 0.11
Kleineres Original-Logo (64×38dp), Ort und Radius in derselben Kopfzeile. Die zusätzliche Standortkarte unter dem Logo entfällt. Fadenkreuz direkt links vom Burger bzw.Detail-X öffnet den unveränderten Standortdialog (GPS/Stadt/PLZ/Adresse/Radius); auch der Ortstext ist antippbar. Bedienelemente bleiben48dp groß; Kopfzeile mindestens56dp, bei großer Schrift flexibel. Lange Ortsnamen mit Auslassung, vollständige Auswahl weiterhin im Dialog. Zurück, Detail-X, verankertes Burger-Menü, sichere Statusabstände und Zeitreise-Vollbild bleiben erhalten. Keine Standort-/Filter-/Quellenänderung. Testversion0.11/code12 mit bisherigem Testschlüssel, keine Storefreigabe. Gerätetest offen.

## Logo 0.12
Original-Logo in derselben kompakten Kopfzeile auf96×52dp vergrößert. Ort/Radius und Standort-Symbol bleiben oben, separate Ortszeile bleibt entfernt. Sämtliche Fachlogik unverändert. Gerätetest offen.

## Drei Specials 0.13
Gemeinsame Test-APK mit größerem96×52dp-Logo plus nativer Route der Industriekultur, Halloween und Weihnachten von Start/Burger. Keine Webseiteneinbettung. Offizieller57er-Routenbestand mit Ankerpunkten/Panoramen/Siedlungen, Stadtfilter, originaler Backend-Reihenfolge/Entfernungen und offiziellen Links. Gematchte und nicht gematchte Standorte bleiben auch ohne Foto sichtbar; Bilder/Galerie/Credits wie Original. Unbekannte API-Koordinaten/Distanzen bleiben unbekannt (Ziethenstraße), kein Null-zu-0-Fehler im nativen Adapter. Route kann ohne GPS geöffnet werden. Route-Favoriten speichern den vorhandenen Primärstandortdatensatz; gematchte Einträge aktualisieren vor Öffnen über vorhandenen share-item-Vertrag.
Halloween/Weihnachten verwenden unverändert extrahierte aktuelle Web-Pipeline, Saison-/Signal-/Dedupe-/Sortier-/Themenregeln. Halloween vier Originalfilter und atomarer5→10→25-Fallback nur bei komplett fehlenden echten Treffern; Unterfiltertrefferlosigkeit erweitert nicht automatisch. Weihnachten startet Weihnachtsmärkte, dann Kinder&Familie/Konzerte&Musik/Advent&Mitmachen/Theater&Shows/Lichter&Ausflüge.25km nur als lokale Vorgabe ohne gespeicherten Radius; gespeicherte/gewählte Präferenz hat Vorrang. Kein Vorjahreskopieren, keine künstlichen Treffer, keine neue Top10-Funktion ohne produktiven Vertrag.
Eigene Themenweltfilter bleiben während Radiuswechsel erhalten. Verlassen verwirft Spezialjobs und lokale Vorgabe, verhindert spätere versteckte Radiusänderungen. Vorhandene Details, Bilder, X, Sharing/Kalender/Favoriten, Quellen und Beiträge weitergenutzt. Quellen special-helpers sind lokal; Computation-WebView hat unverändert Netzverbot. Homepage-Saisonbilder sind vorhandene KI-Symbolmotive.
Live-Vergleich20.10.: api unverändert, views/main enthalten inzwischen Büdchen-Direkteinstieg; nur separate aktuelle Special-Snapshots hinzugefügt. 504 Original-Reactansicht-Filter-/Sortier-/Detailvergleiche in Wesel/Essen/Dortmund; weitere Null-/Saison-/Trefferlos-/Über300-Kandidatenfälle. Alle bisherigen Fachsuiten und Android-Checks erneut. Keine UGC-Testeinsendung, kein Web-/Backenddeployment. Physischer Gerätetest bleibt offen.


## Geprüfte Bildkorrektur 0.14: Peter-Behrens-Bau
Foto: Peter-Behrens-Bau-Oberhausen-2025.jpg, Tuxyso, 17.05.2025, eigenes Werk.
Quelle: https://commons.wikimedia.org/wiki/File:Peter-Behrens-Bau-Oberhausen-2025.jpg
Lizenz: Creative Commons Namensnennung – Weitergabe unter gleichen Bedingungen 4.0 International, https://creativecommons.org/licenses/by-sa/4.0/
Datei app/src/main/assets/media/peter-behrens-bau-tuxyso-2025.jpg ist das unveränderte Original (6009×2118); eingepasste Anzeige, keine Bildbearbeitung. Die Lizenz gilt für dieses Foto. Attribution und anklickbare Quellen-/Lizenzlinks im nativen Detail.
Gezielte App-Korrektur ausschließlich Place8407 / OSMway37642158; der Datenbestand liefert weiterhin Rheinisches Industriemuseum.jpg. Kein pauschaler Ersatz aller Museumsbilder. Alle übrigen Galeriebilder bleiben erhalten; das nachgewiesen falsche Foto wird für diesen Ort entfernt.


## Optimierte interne Testversion0.15
Sieben generische KI-Fotokacheln sind WebP-Ableitungen der0.14-PNGs, Qualität88, unveränderte1536×1024Pixel. Motive, Ressourcennamen und Layout unverändert. Originale/Prompts im bisherigen Quellstand0.14 und ASSET_MANIFEST.json; reproduzierbare Kodierung tools/optimize-tiles.py. Logo, historisches RVR-Luftbild und Tuxyso-Foto bleiben unverändert. Alle bisherigen Quellen-/Lizenznachweise gelten weiter.
Release-Build mit R8 und Ressourcenoptimierung, nicht debuggable. Auslieferung weiterhin als interne Test-APK mit bisherigem Testschlüssel und Paketde.ruhrpottguru.testapp (updatefähig von0.14). Keine öffentliche/Play-Store-Freigabe oder neue Produktionsidentität. Laufzeitprüfung auf echtem Android-Gerät bleibt erforderlich, insbesondere lokale Datenengine und Bilddecoder nach Minifizierung.
