const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=__dirname+'/../',assets=root+'app/src/main/assets/shared/';
function make(native){const c={console,URL,URLSearchParams,window:{wp:{element:{}},ruhrpottSettings:{root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/',foodMediaUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/food-media',placeInfoUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/place-info'},location:{href:'https://www.ruhrpottguru.de/',origin:'https://www.ruhrpottguru.de',hostname:'www.ruhrpottguru.de'}}};vm.createContext(c);for(const name of ['runtime','api',...(native?['media-layout','location-helpers','category-food','category-highlights','category-events','native-adapter']:[])])vm.runInContext(fs.readFileSync(assets+name+'.js','utf8'),c);return c;}
const c=make(true),ref=make(false),n=c.window.NativeFood,R=c.window.RPGReact,views=fs.readFileSync(root+'shared-source/views.js','utf8');
const a=views.indexOf('  function sortDistance(items){'),b=views.indexOf('\n\n  // V104:',a),f=views.indexOf('    const filtered=s.items.filter(x=>{'),e=views.indexOf('\n    const visibleItems=',f);
const predicate=views.slice(f,e),sort=views.slice(a,b);
assert.ok(fs.readFileSync(assets+'category-highlights.js','utf8').includes(predicate));
vm.runInContext('(function(){const RPG=window.RPGReact;\n'+sort+'\nwindow.baseline=(raw,point)=>sortDistance(raw.map(x=>RPG.normalizePlace(x,"highlights",point)));window.filter=(items,query,tagFilter,sub)=>{const category="highlights",s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";\n'+predicate+'\nreturn filtered;};})();',ref);
const ids=a=>JSON.stringify(a.map(x=>String(x.id)));
function ingest(rows,point,km){n.reset('highlights');n.append(rows);n.commit(point,km);}
let cases=0,photos=0;const summaries=[];
for(const [name,point,km] of [['wesel-5km',{lat:51.6572,lng:6.6186,city:'Wesel'},5],['wesel-25km',{lat:51.6572,lng:6.6186,city:'Wesel'},25],['essen-5km',{lat:51.4556,lng:7.0116,city:'Essen'},5]]){
 const raw=JSON.parse(fs.readFileSync(__dirname+'/fixtures/highlights-'+name+'.json')).elements;assert.ok(raw.length>0);
 const baseline=ref.window.baseline(raw,point);ingest(raw,point,km);const page=n.query('','','',99999);
 assert.equal(ids(page.items),ids(baseline));assert.equal(page.total,raw.length);assert.ok(page.items.every(x=>x.category==='highlights'&&!x.event));
 const tests=[['','',''],['keine treffer 123','',''],['Wesel','',''],['Industrie','',''],...page.tags.map(t=>['',t.slug,'']),...page.subtypes.map(s=>['','',s])];
 for(const [q,t,s]of tests){assert.equal(ids(n.query(q,t,s,99999).items),ids(ref.window.filter(baseline,q,t,s)));cases++;}
 for(const x of baseline){const detail=n.detail(String(x.id));assert.equal(detail.title,ref.window.RPGReact.displayPlaceTitle(x));assert.equal(detail.media.url,x.displayImageSuppressed?'':(x.displayImageUrl||x.imageUrl||''));assert.equal(JSON.stringify(detail.labels.map(x=>x.label)),JSON.stringify(ref.window.RPGReact.categoryFilterTags(x)));assert.equal(detail.price,(x.tags&&(x.tags.charge||x.tags.fee))||'');assert.equal(detail.gallery.length,(x.galleryImages||[]).length);if(x.imageUrl)photos++;}
 summaries.push({fixture:name,places:page.total});
}
const point={lat:51.6572,lng:6.6186,city:'Wesel'};
const row=id=>({id,type:'node',lat:point.lat,lon:point.lng,tags:{name:'Industrieller Ort '+id,'addr:city':'Wesel',tourism:'attraction',wikidata:'Q1'}});
ingest([row(9000001)],point,1);const plain=n.query('','','',24);assert.equal(plain.total,1,'small category remains one: no Home radius expansion');assert.equal(plain.items[0].media.url,'');assert.equal(plain.items[0].price,'','unknown fee stays unknown');assert.ok(n.detail(plain.items[0].id));
ingest([],point,1);assert.equal(n.query('','','',24).total,0,'empty results stay empty');
const flush=()=>new Promise(setImmediate),post=R.api.post;
(async()=>{
 // Two simultaneous asynchronous original resolvers must keep identity/credits
 // through place-info -> food-media, including failed place-info continuation.
 ingest([row(9000001),row(9000002)],point,5);
 const keys=n.query('','','',24).items.map(x=>x.id),before=ids(n.query('','','',24).items);
 for(const id of keys){const req=n.highlightsMediaRequest(id,'');assert.equal(req.url,R.settings.placeInfoUrl);assert.equal(req.body.category,'highlights');assert.equal(R.api.post,post);}
 for(const [i,id]of keys.entries()){
  n.highlightsMediaAdvance(id,i===0?{status:'success',website:'https://example.org/venue'}:null);await flush();
  const state=n.highlightsMediaState(id);assert.equal(state.request.url,R.settings.foodMediaUrl);assert.equal(state.request.body.allowSymbolic,false);assert.equal(state.request.body.category,'highlights');assert.equal(state.request.body.website,i===0?'https://example.org/venue':'');assert.equal(R.api.post,post);
  const data={imageUrl:'https://example.org/place-'+i+'.jpg',credit:'Autor '+i,license:'CC BY 4.0',sourceUrl:'https://example.org/source'};
  n.highlightsMediaAdvance(id,data);await flush();assert.equal(n.highlightsMediaState(id).applied,true);assert.equal(n.detail(id).media.url,data.imageUrl);assert.equal(n.detail(id).media.credit,data.credit);assert.equal(R.api.post,post);
 }
 assert.equal(ids(n.query('','','',24).items),before,'media cannot change inclusion/order');
 ingest([row(9000003)],point,5);const id=n.query('','','',24).items[0].id;n.highlightsMediaRequest(id,'');n.highlightsMediaAdvance(id,{status:'success'});await flush();assert.ok(n.highlightsMediaState(id).request);n.highlightsMediaAdvance(id,{imageUrl:'https://example.org/portrait.jpg',alt:'Portrait einer Person'});await flush();assert.equal(n.highlightsMediaState(id).applied,false,'original person guard');
 // Reset invalidates outstanding media jobs; old replies cannot alter new list.
 n.highlightsMediaRequest(id,'');n.reset('food');assert.equal(n.highlightsMediaAdvance(id,{imageUrl:'https://example.org/old.jpg'}),false);n.append([row(9000004)]);n.commit(point);assert.equal(n.query('','','',24).items[0].category,'food');
 console.log(JSON.stringify({result:'PASS',summaries,filterParityCases:cases,originalImages:photos,edgeCases:['empty and small results','no photo exclusion','unknown prices','original async media chain','parallel identity isolation','failed place-info','original person guard','stale media invalidation','Food switch']}));
})().catch(e=>{console.error(e);process.exitCode=1;});
