process.env.TZ='Europe/Berlin';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const base=__dirname+'/../',assets=base+'app/src/main/assets/shared/';
const NOW=Date.parse('2026-10-19T20:30:00Z');
class TestDate extends Date{constructor(...a){super(...(a.length?a:[NOW]));}static now(){return NOW;}}
function context(native){const c={Date:TestDate,URL,URLSearchParams,console,window:{wp:{element:{}},ruhrpottSettings:{root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/',eventMediaDiversityEnabled:true},location:{href:'https://www.ruhrpottguru.de/',origin:'https://www.ruhrpottguru.de',hostname:'www.ruhrpottguru.de'}}};vm.createContext(c);for(const name of ['runtime','api'])vm.runInContext(fs.readFileSync(assets+name+'.js','utf8'),c);if(native)for(const name of ['media-layout','location-helpers','category-food','category-events','native-adapter'])vm.runInContext(fs.readFileSync(assets+name+'.js','utf8'),c);return c;}
const c=context(true),R=c.window.RPGReact,n=c.window.NativeFood,reference=context(false);
const views=fs.readFileSync(base+'shared-source/views.js','utf8');
const components=fs.readFileSync(base+'shared-source/components.js','utf8');
const helpers=views.slice(views.indexOf('  function homeEventDayAccess('),views.indexOf('  function useCategoryItems('));
const dates=views.slice(views.indexOf('  function localIsoDate('),views.indexOf('  function CalendarGlyph('));
const pipelineStart=views.indexOf('            let items=raw.map(x=>RPG.normalizeEvent(x,location))');
const pipeline=views.slice(pipelineStart,views.indexOf('            if(live)setState({loading:false,error:',pipelineStart));
const predStart=views.indexOf('    const filtered=s.items.filter(x=>{');
const predicate=views.slice(predStart,views.indexOf('\n    const visibleItems=',predStart));
vm.runInContext('(function(){const RPG=window.RPGReact;\n'+helpers+dates+'\nwindow.baseline=function(raw,location,radius){const home=false,mode="",eventWindow="";\n'+pipeline+'\nreturn localItems;};window.filter=function(items,query,tagFilter,sub,dateFrom,dateTo){const category="events",s={items},q=query.trim().toLowerCase();\n'+predicate+'\nreturn filtered;};})();',reference);
const generated=fs.readFileSync(assets+'category-events.js','utf8');for(const exact of [helpers,dates,pipeline,predicate])assert.ok(generated.includes(exact),'unchanged source extraction');
function ingest(raw,point,km){n.reset('events');for(let i=0;i<raw.length;i+=80)n.append(raw.slice(i,i+80));n.commit(point,km);}
const ids=a=>JSON.stringify(a.map(x=>String(x._rpgNearTermKey||x.id)));
let filterCases=0,total=0,originalImages=0;const summaries=[];
for(const [name,point,km] of [
 ['wesel-5km',{lat:51.6572,lng:6.6186,city:'Wesel'},5],
 ['wesel-25km',{lat:51.6572,lng:6.6186,city:'Wesel'},25],
 ['essen-5km',{lat:51.4556,lng:7.0116,city:'Essen'},5]
]){
 const fixture=JSON.parse(fs.readFileSync(__dirname+'/fixtures/events-'+name+'.json'));
 assert.ok(Array.isArray(fixture.items)&&fixture.items.length>20);
 const baseline=reference.window.baseline(fixture.items,point,km);ingest(fixture.items,point,km);
 let page=n.query('','','',99999);assert.equal(ids(page.items),ids(baseline));assert.equal(page.total,baseline.length);
 assert.equal(new Set(page.items.map(x=>x.id)).size,page.items.length,'unique occurrence card keys');
 assert.ok(baseline.every(x=>x.cityScope===true||(Number.isFinite(x.distanceKm)&&x.distanceKm<=km)));
 const compare=(q,tag,sub,from,to)=>{const expected=reference.window.filter(baseline,q,tag,sub,from,to);const actual=n.query(q,tag,sub,99999,from,to);assert.equal(ids(actual.items),ids(expected));assert.equal(actual.total,expected.length);filterCases++;};
 compare('','','','','');compare('Konzert','','','','');compare('KeineTrefferXYZ','','','','');
 for(const mode of ['today','tomorrow','weekend']){const d=n.preset(mode);compare('','','',d.from,d.to);}
 compare('','','','2026-10-20','2026-10-25');
 for(const t of page.tags)compare('',t.slug,'','','');for(const type of page.subtypes)compare('','',type,'','');
 for(const item of baseline.slice(0,24)){
  const shown=n.detail(String(item._rpgNearTermKey||item.id));
  assert.equal(shown.title,item.title);assert.equal(shown.distance,R.formatDistance(item.distanceKm));
  assert.equal(JSON.stringify(shown.labels.map(x=>x.label)),JSON.stringify(reference.window.RPGReact.categoryFilterTags(item)));
  assert.ok(shown.event.date);assert.equal(shown.share,R.buildShareUrl(item));
 }
 for(const item of baseline){const source=String(item.raw?.rpg_event_media?.source||'');if(/et4|odf|et2014/i.test(source)&&item.imageUrl&&!item.displayImageUrl&&!item.displayImageSuppressed){assert.equal(page.items.find(x=>x.id===String(item._rpgNearTermKey||item.id)).media.url,item.imageUrl);originalImages++;}}
 // Removing media from the already admitted canonical rows must not remove an event.
 const noPhotos=JSON.parse(JSON.stringify(fixture.items));
 for(const x of noPhotos){x.rpg_event_media={};for(const key of Object.keys(x))if(/image|media_object|gallery|thumbnail/i.test(key))delete x[key];}
 ingest(noPhotos,point,km);assert.equal(ids(n.query('','','',99999).items),ids(baseline));
 summaries.push({fixture:name,raw:fixture.items.length,admitted:baseline.length});total+=baseline.length;
}
assert.equal(n.preset('today').from,'2026-10-19');assert.equal(n.preset('tomorrow').from,'2026-10-20');assert.equal(n.preset('weekend').from,'2026-10-23');assert.equal(n.preset('weekend').to,'2026-10-25');
const point={lat:51.6572,lng:6.6186,city:'Wesel'};
const make=(id,start,end,extra={})=>({id:'event:'+id,title:'Konzert '+id,start,end,geo:{latitude:point.lat,longitude:point.lng},city:'Wesel',location:{name:'Testsaal'},rpg_event_db:{eventId:id},...extra});
const dateOnly=make(99001,'2026-10-20T00:00:00+02:00','2026-10-21T00:00:00+02:00',{allDay:true,rpg_event_details:{allDay:true,priceText:'45.00EUR 45.00EUR',ticketUrl:'https://tickets.example.org/99001'}});
const cityScoped=make(99002,'2026-10-20T20:00:00+02:00','2026-10-20T22:00:00+02:00',{geo:null,rpg_geo_scope:'city'});
const expired=make(99003,'2026-10-15T20:00:00+02:00','2026-10-15T22:00:00+02:00');
const outside=make(99004,'2026-10-20T20:00:00+02:00','2026-10-20T22:00:00+02:00',{geo:{latitude:51.9,longitude:6.6}});
ingest([dateOnly,cityScoped,expired,outside],point,5);let page=n.query('','','',99);assert.equal(page.total,2);assert.ok(page.items.every(x=>x.media.url===''));
const allday=n.detail('event:99001');assert.equal(allday.event.calendar.allDay,true);assert.equal(allday.event.calendar.startDay,'20261020');assert.equal(allday.event.calendar.endDay,'20261021');assert.equal(allday.event.priceText,'45 €');assert.equal(allday.event.ticketUrl,'https://tickets.example.org/99001');
const unknown=n.detail('event:99002');assert.equal(unknown.distance,'');assert.equal(unknown.directions,'');
const request=n.relatedRequest('event:99001');assert.equal(request.url,'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/events/99001/related');
const before=ids(page.items);const external=n.externalDetail(make(99005,'2026-11-01T12:00:00+01:00',null),point);assert.equal(external.canonicalId,'event:99005');assert.equal(ids(n.query('','','',99).items),before,'related detail must not change the list');assert.equal(external.event.calendar.end,null,'no invented duration');
const related=n.relatedRows({items:[{eventId:99005,title:'Weiterer Termin',start:'2026-11-01T12:00:00+01:00',end:null}]});assert.ok(related[0].date.includes('2026'));
// One source-proven occurrence today and tomorrow must keep distinct native keys.
const series=make(99006,'2026-10-19T20:00:00+02:00','2026-10-19T23:30:00+02:00',{rpg_event_series:{nearTerm:[{start:'2026-10-19T20:00:00+02:00',end:'2026-10-19T23:30:00+02:00',eventId:99006},{start:'2026-10-20T20:00:00+02:00',end:'2026-10-20T23:30:00+02:00',eventId:99007}],laterSeries:{start:'2026-10-26T20:00:00+01:00',end:'2026-10-26T23:30:00+01:00',eventId:99008}}});
ingest([series],point,5);page=n.query('','','',99);assert.equal(page.total,3);assert.equal(new Set(page.items.map(x=>x.id)).size,3);for(const row of page.items)assert.equal(n.detail(row.id).event.date,row.event.date);
// Category switch clears items and preserves the native bridge's old Food contract.
n.reset('food');n.append([]);n.commit(point,5);assert.equal(n.query('','','',99).total,0);
console.log(JSON.stringify({result:'PASS',clock:'2026-10-19T20:30:00Z',timezone:'Europe/Berlin',summaries,total,filterParityCases:filterCases,verifiedOriginalEventImages:originalImages,edgeCases:['missing photos','city-scoped distance','expired/outside','date-only calendar','ticket and price formatting','related detail keeps list','distinct near-term keys','Food switch']}));
