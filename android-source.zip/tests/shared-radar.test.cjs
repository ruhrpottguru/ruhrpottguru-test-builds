process.env.TZ='Europe/Berlin';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');const root=__dirname+'/../',assets=root+'app/src/main/assets/shared/';
const now=Date.parse('2026-10-20T10:00:00Z');class Clock extends Date {constructor(...a){super(...(a.length?a:[now]));}static now(){return now;}}
function boot(native){const states=[],effects=[];let index=0,override=[];const element={createElement:(type,props,...children)=>({type:typeof type==='function'?type.name:type,props:props||{},children}),useState:v=>{let i=index++;return [override[i]===undefined?(states[i]===undefined?(typeof v==='function'?v():v):states[i]):override[i],f=>{states[i]=typeof f==='function'?f(states[i]):f;}];},useEffect:f=>effects.push(f),useMemo:f=>f(),useRef:v=>({current:v})};
const c={Date:Clock,console,URL,URLSearchParams,document:{getElementById:()=>null},window:{wp:{element},ruhrpottSettings:{root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/'},location:{href:'https://www.ruhrpottguru.de/',origin:'https://www.ruhrpottguru.de'}}};vm.createContext(c);
for(const file of ['runtime','api',...(native?['media-layout','category-food','category-highlights','category-places','category-events','radar-helpers','native-adapter']:[])])vm.runInContext(fs.readFileSync(assets+file+'.js','utf8'),c);
if(!native){c.window.RPGReact.Components={};vm.runInContext(fs.readFileSync(root+'shared-source/views.js','utf8'),c);}
return {c,states,effects,render:(category,opts={})=>{index=0;override=opts.override||[];effects.length=0;return c.window.RPGReact.Views[category==='buedchen'?'BuedchenRadarView':'WurstView'](opts.props);}};
}
function nodes(tree){if(!tree||typeof tree!=='object')return [];if(Array.isArray(tree))return tree.flatMap(nodes);return [tree,...(tree.children||[]).flatMap(nodes)];}
function ids(rows){return JSON.stringify(rows.map(x=>String(x.id)));}
function raw(id,tags){return {id,type:'node',lat:51.6572,lon:6.6186,tags:{name:'Test '+id,'addr:city':'Wesel',...tags}};}
const nctx=boot(true),n=nctx.c.window.NativeFood;const report=[];let cases=0;
(async()=>{
for(const cat of ['buedchen','wurst'])for(const [name,point,km] of [['wesel-5km',{lat:51.6572,lng:6.6186,city:'Wesel'},5],['wesel-25km',{lat:51.6572,lng:6.6186,city:'Wesel'},25],['essen-5km',{lat:51.4556,lng:7.0116,city:'Essen'},5]]){
 const payload=JSON.parse(fs.readFileSync(__dirname+'/fixtures/'+cat+'-'+name+'.json'));
 const web=boot(false),R=web.c.window.RPGReact;const props={location:point,radius:km,onRadius(){},onLocation(){},onOpen(){}};
 if(cat==='buedchen')R.api.buedchen=async()=>payload.elements;else R.api.wurst=async()=>payload;
 web.render(cat,{props});web.effects.forEach(f=>f());await new Promise(setImmediate);
 n.reset(cat);n.append(payload.elements);n.commit(point,km);
 let original=web.states[0].items;assert.ok(original.length>0);let native=n.query('','','',9999);const webTree=web.render(cat,{props});
 const selected=cat==='buedchen'?nodes(webTree).filter(x=>x.type==='BudeMap')[0].props.items:nodes(webTree).filter(x=>x.type==='WurstCard').map(x=>x.props.item);
 if(cat==='wurst'){const available=new Set(original.flatMap(x=>String((x.tags||{})['rg:wurst_menu_items']||'').split('|').filter(Boolean)));assert.equal(JSON.stringify(native.tags.map(x=>x.slug)),JSON.stringify(['currywurst','pommes','schnitzel','frikadelle','schaschlik','bratwurst'].filter(x=>available.has(x))));}
 const pageSize=cat==='buedchen'?20:18;assert.equal(ids(native.items.slice(0,pageSize)),ids(selected.slice(0,pageSize)),'real original view initial order');assert.equal(native.total,original.length);
 const choices=cat==='buedchen'?[{},...['open','lottery','mixed_candy','coffee','seating','parcel_shop'].map(x=>({[x]:true})),{coffee:true,seating:true},{lottery:true,parcel_shop:true}]:['all','currywurst','pommes','schnitzel','frikadelle','schaschlik','bratwurst'];
 for(const f of choices){
  if(cat==='buedchen'){
   n.radarClear();for(const key of Object.keys(f))n.radarToggle(key);
   const tree=web.render(cat,{props,override:[undefined,f,undefined,9999]});const expected=nodes(tree).find(x=>x.type==='BudeMap').props.items;
   const actual=n.query('','','',9999);assert.equal(ids(actual.items),ids(expected));assert.equal(ids(actual.mapItems),ids(expected.slice(0,120)));assert.ok(actual.mapItems.every(x=>Object.keys(x).sort().join(',')==='coords,id,title'),'map bridge only sends marker data');assert.ok(actual.items.every(x=>original.some(o=>String(o.id)===x.id)),'filters only reduce fixed public set');cases++;
  }else for(const sort of ['distance','new'])for(const q of ['',point.city,'pommes','keinTreffer123']){
   const tree=web.render(cat,{props,override:[undefined,f,sort,q,9999]});const expected=nodes(tree).filter(x=>x.type==='WurstCard').map(x=>x.props.item);n.radarSetSort(sort);const actual=n.query(q,f==='all'?'':f,'',9999);assert.equal(ids(actual.items),ids(expected));cases++;
  }
 }
 n.radarClear();const all=n.query('','','',9999).items;
 for(const x of all){const source=original.find(o=>String(o.id)===x.id);assert.ok(source);assert.equal(x.media.url,source.displayImageSuppressed?'':source.displayImageUrl||source.imageUrl||'');assert.equal(x.gallery.length,(source.galleryImages||[]).length);const detail=n.detail(x.id);assert.ok(detail);if(cat==='buedchen'){assert.ok(detail.special.opening);assert.equal(detail.coords.lat,source.coords.lat);}else assert.equal(detail.subtitle,'Imbissbude');}
 report.push({category:cat,fixture:name,candidates:payload.elements.length,publicItems:original.length});
}
// More than 12 tier-A means no B; fewer A fill to12 only. Photos never change admission.
const a=Array.from({length:13},(_,i)=>raw(9000+i,{'rg:buedchen_tier':'A'})),b=Array.from({length:20},(_,i)=>raw(9100+i,{'rg:buedchen_tier':'B'})),c=raw(9999,{'rg:buedchen_tier':'C','rg:buedchen_feature_coffee':'yes'});
n.reset('buedchen');n.append([...a,...b,c]);n.commit({lat:51.6572,lng:6.6186});assert.equal(n.query('','','',999).total,13);n.radarToggle('coffee');assert.equal(n.query('','','',999).total,0,'filter cannot import excluded B/C');
n.reset('buedchen');n.append([...a.slice(0,3),...b,c]);n.commit({lat:51.6572,lng:6.6186});assert.equal(n.query('','','',999).total,12);assert.ok(n.query('','','',999).items.every(x=>!x.media.url),'no photo requirement');
n.radarToggle('open');const features=n.radarToggle('coffee');assert.equal(features.open,false);const opened=n.radarToggle('open');assert.equal(opened.coffee,false);assert.equal(opened.open,true);
// Unknown opening hours and explicitly denied coffee never become positive.
n.reset('buedchen');n.append([raw(1,{'rg:buedchen_tier':'A','drink:coffee':'yes','rg:buedchen_feature_coffee':'no'}),raw(2,{'rg:buedchen_tier':'A',opening_hours:'24/7','rg:buedchen_feature_coffee':'yes'})]);n.commit({lat:51.6572,lng:6.6186});n.radarToggle('open');assert.equal(n.query('','','',99).total,1);assert.equal(n.query('','','',99).items[0].canonicalId,'node:2');
// Request contracts match live original API; transport does not submit anything.
const api=nctx.c.window.RPGReact.api,captured=[];api.post=async(url,body)=>{captured.push({url,body});return {elements:[],verifiedTotal:0};};await api.buedchen({lat:51.6572,lng:6.6186},5,200);await api.wurst({lat:51.6572,lng:6.6186},5,600);assert.deepEqual(JSON.parse(JSON.stringify(captured.map(x=>x.body.limit))),[200,600]);
console.log(JSON.stringify({result:'PASS',realOriginalViewFilterComparisons:cases,fixtures:report,qualityAndNoPhotoCases:true,filterModeExclusion:true,unknownHours:true,submissionsSent:false}));
})().catch(e=>{console.error(e);process.exitCode=1;});
