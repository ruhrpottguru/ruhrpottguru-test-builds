process.env.TZ='Europe/Berlin';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=__dirname+'/../',assets=root+'app/src/main/assets/shared/',source=fs.readFileSync(root+'shared-source/specials-views.js','utf8');
const now=Date.parse('2026-10-20T10:00:00Z');class Clock extends Date{constructor(...a){super(...(a.length?a:[now]));}static now(){return now;}}
function boot(native){const states=[],effects=[];let index=0,override=[];const element={createElement:(type,props,...children)=>({type:typeof type==='function'?type.name:type,props:props||{},children}),useState:v=>{const i=index++;return [override[i]===undefined?(states[i]===undefined?(typeof v==='function'?v():v):states[i]):override[i],f=>states[i]=typeof f==='function'?f(states[i]):f]},useEffect:f=>effects.push(f),useMemo:f=>f(),useRef:v=>({current:v})};
 const c={Date:Clock,console,URL,URLSearchParams,document:{getElementById:()=>null},window:{wp:{element},ruhrpottSettings:{root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/',eventMediaDiversityEnabled:false},location:{href:'https://www.ruhrpottguru.de/',origin:'https://www.ruhrpottguru.de'}}};vm.createContext(c);
 for(const f of ['runtime','api',...(native?['media-layout','location-helpers','category-food','category-highlights','category-places','category-events','detail-helpers','radar-helpers','special-helpers','native-adapter']:[])])vm.runInContext(fs.readFileSync(assets+f+'.js','utf8'),c);
 if(!native){c.window.RPGReact.Components={Card:function Card(){}};vm.runInContext(source.replace('  RPG.Views={','  window.RouteFallbackCard=RouteFallbackCard;RPG.Views={'),c)}
 return {c,states,effects,render:(name,props,over=[])=>{index=0;override=over;return (name==='fallback'?c.window.RouteFallbackCard:c.window.RPGReact.Views[name])(props)}};
}
function nodes(t){if(!t||typeof t!=='object')return [];if(Array.isArray(t))return t.flatMap(nodes);return [t,...(t.children||[]).flatMap(nodes)]}
async function drain(){for(let i=0;i<5;i++)await new Promise(setImmediate)}
function ing(n,raw,point,mode,km=25){n.reset(mode==='route'?'highlights':'events',mode);n.append(raw);return n.commit(point,km)}
let cases=0;const report=[];
(async()=>{
const nat=boot(true),n=nat.c.window.NativeFood;
for(const [city,lat,lng] of [['wesel',51.6572,6.6186],['essen',51.4556,7.0116],['dortmund',51.5136,7.4653]]){
 const point={city:city[0].toUpperCase()+city.slice(1),lat,lng};const route=JSON.parse(fs.readFileSync(__dirname+'/fixtures/specials/route-'+city+'.json')).items;
 const web=boot(false),R=web.c.window.RPGReact;R.api.industrialRoute=async()=>route;const props={location:point,onOpen(){}};web.render('RouteView',props);web.effects.forEach(f=>f());await drain();assert.equal(web.states[0].items.length,57);assert.equal(ing(n,route,point,'route'),57);
 const cities=[...new Set(route.map(x=>x.city).filter(Boolean))];
 for(const type of ['all','anchor','panorama','settlement'])for(const place of ['',...cities,'KeineStadt']){
  const tree=web.render('RouteView',props,[undefined,type,place]);const cards=nodes(tree).filter(x=>['Card','RouteFallbackCard'].includes(x.type));n.specialSelect(type,place);const actual=n.query('','','',9999);
  assert.equal(JSON.stringify(actual.items.map(x=>x.title)),JSON.stringify(cards.map(x=>x.props.item.title)),'route original order/filter');assert.equal(actual.total,cards.length);cases++;
 }
 n.specialSelect('all','');const all=n.query('','','',9999);assert.equal(new Set(all.items.map(x=>x.id)).size,57);assert.equal(all.specialInfo.cities.length,cities.length);
 const tree=web.render('RouteView',props,[undefined,'all','']);for(const card of nodes(tree).filter(x=>['Card','RouteFallbackCard'].includes(x.type))){let expected=card.props.item;if(card.type==='RouteFallbackCard'){let opened;const fallback=web.render('fallback',{item:expected,onOpen:x=>opened=x},[expected.fallbackImage||'']);nodes(fallback).find(x=>x.type==='button').props.onClick();expected=opened;}
  const actual=all.items.find(x=>x.title===expected.title);assert.ok(actual);if(expected._nativeRoute?.slug==='peter-behrens-bau'||actual.id==='route:peter-behrens-bau')assert.equal(actual.media.url,'file:///android_asset/media/peter-behrens-bau-tuxyso-2025.jpg');else assert.equal(actual.media.url,expected.imageUrl||'');assert.equal(actual.city,expected.city);const detail=n.detail(actual.id);assert.equal(detail.details.routeOfficialUrl,expected.routeOfficialUrl);assert.equal(detail.details.routeIndustrial,true);
  const saved=n.snapshot(actual.id);assert.ok(saved.routeRecord);const restored=n.restoreSaved(saved,point);assert.equal(restored.title,actual.title);assert.equal(restored.media.url,actual.media.url);const far={lat:51.5136,lng:7.4653,city:"Dortmund"};const moved=n.restoreSaved(saved,far);if(moved.coords)assert.equal(moved.distance,nat.c.window.RPGReact.formatDistance(nat.c.window.RPGReact.distanceKm(far.lat,far.lng,moved.coords.lat,moved.coords.lng)));cases++;
 }
 // All routes, including entries with no DB match or photo, remain visible.
 const missing=route.find(x=>!x.element&&x.fallbackLat==null&&x.fallbackLng==null&&x.distanceKm==null);if(missing){n.reset('highlights','route');n.append([missing]);n.commit(null,25);const row=n.query('','','',99).items[0];assert.equal(row.coords,null);assert.equal(row.distance,'');assert.equal(row.directions,'');}
 const noLocation=JSON.parse(JSON.stringify(route));for(const x of noLocation)x.distanceKm=null;ing(n,noLocation,null,'route');assert.ok(n.query('','','',999).items.every(x=>!x.distance),'no synthetic distance when route opened without location');
 const noPhotos=JSON.parse(JSON.stringify(route));for(const x of noPhotos){x.element=null;x.fallbackImage='';}assert.equal(ing(n,noPhotos,null,'route'),57);n.specialSelect('all','');assert.equal(n.query('','','',999).total,57);assert.ok(n.query('','','',999).items.every(x=>!x.media.url));cases++;
 const raw=JSON.parse(fs.readFileSync(__dirname+'/fixtures/specials/events-'+city+'.json')).items;
 for(const mode of ['halloween','weihnachten']){
  const web=boot(false),R=web.c.window.RPGReact;R.api.events=async()=>raw;const props={location:point,radius:25,onRadius(){},onLocation(){},onOpen(){}};const view=mode==='halloween'?'HalloweenView':'ChristmasView';web.render(view,props);web.effects.forEach(f=>f());await drain();assert.equal(web.states[0].loading,false);ing(n,raw,point,mode);const base=n.query('','','',9999);const filters=base.specialInfo.filters;
  if(mode==='weihnachten')assert.equal(filters.map(x=>x.key).join('|'),'weihnachtsmaerkte|kinder-familie|konzerte-musik|advent-mitmachen|theater-shows|lichter-ausfluege');
  for(const f of filters){n.specialSelect(f.key,'');const actual=n.query('','','',9999);const tree=web.render(view,props,[undefined,f.key]);const expected=nodes(tree).filter(x=>x.type==='Card').map(x=>x.props.item);assert.equal(JSON.stringify(actual.items.map(x=>x.canonicalId)),JSON.stringify(expected.map(x=>x.id)),city+' '+mode+' '+f.key);assert.equal(actual.total,expected.length);for(const x of actual.items){assert.ok(n.detail(x.id).event.date);assert.equal(x.media.url,expected.find(y=>y.id===x.canonicalId).displayImageSuppressed?'':expected.find(y=>y.id===x.canonicalId).displayImageUrl||expected.find(y=>y.id===x.canonicalId).imageUrl||'');}cases++;
  }
  report.push({city,mode,raw:raw.length,total:base.specialInfo.count,initial:base.total});
 }
}
const noGps=JSON.parse(fs.readFileSync(__dirname+'/fixtures/specials/route-no-location.json')).items;assert.equal(noGps.length,57);ing(n,noGps,null,'route');assert.equal(n.query('','','',999).total,57);assert.ok(n.query('','','',999).items.every(x=>x.distance===''));
const point={lat:51.6572,lng:6.6186,city:'Wesel'},mk=(id,title,start,extra={})=>({id:'event:'+id,title,start,end:start,geo:{latitude:point.lat,longitude:point.lng},city:'Wesel',location:{name:'Testsaal'},rpg_event_db:{eventId:id},...extra});
const ordinary=Array.from({length:360},(_,i)=>mk(90000+i,'Konzert '+i,'2026-10-21T20:00:00+02:00'));
const late=mk(99990,'Halloween Gruselnacht','2026-10-31T20:00:00+01:00');ing(n,[...ordinary,late],point,'halloween');assert.equal(n.query('','','',9999).total,1,'qualify complete candidate pool before media/presentation cap');
const wrong=mk(99991,'Märchen für die Familie','2026-10-31T20:00:00+01:00',{providerMeta:'Halloween'});ing(n,[wrong],point,'halloween');assert.equal(n.query('','','',9999).total,0,'no provider-only Halloween inference');
const xmas=[mk(99992,'Adventskonzert','2026-12-12T20:00:00+01:00',{description:'Beim Weihnachtsmarkt'}),mk(99993,'Weihnachtsmarkt','2026-12-12T12:00:00+01:00',{categories:'Theater'}),mk(99994,'Weihnachtsmarkt','2025-12-12T12:00:00+01:00')];ing(n,xmas,point,'weihnachten');assert.equal(n.query('','','',999).total,1,'default market and only current season');n.specialSelect('theater-shows');assert.equal(n.query('','','',999).total,0,'market generic theater taxonomy not show evidence');n.specialSelect('konzerte-musik');assert.equal(n.query('','','',999).total,1);
const qa=nat.c.window.rpgSpecialQA;assert.equal(qa.christmasSeasonYear(new Clock('2027-01-04')),2026);assert.equal(qa.christmasSeasonYear(new Clock('2027-02-04')),2027);
for(const [name,expected] of [['halloween',0],['weihnachten',0],['route',0]]){ing(n,[],point,name);assert.equal(n.query('','','',999).total,expected)}
console.log(JSON.stringify({result:'PASS',originalViewComparisons:cases,report,completePool:true,noSourceMetadataFalseMatches:true,noPhotoExclusion:true,routeFavorites:true,seasonRollover:true,submissionsSent:false}));
})().catch(e=>{console.error(e);process.exitCode=1});
