const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=__dirname+'/../',assets=root+'app/src/main/assets/shared/';
function context(native){const c={console,URL,URLSearchParams,window:{wp:{element:{}},ruhrpottSettings:{root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/',foodMediaUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/food-media',placeInfoUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/place-info'},location:{href:'https://www.ruhrpottguru.de/',origin:'https://www.ruhrpottguru.de',hostname:'www.ruhrpottguru.de'}}};vm.createContext(c);for(const name of ['runtime','api',...(native?['media-layout','location-helpers','category-food','category-highlights','category-places','category-events','native-adapter']:[])])vm.runInContext(fs.readFileSync(assets+name+'.js','utf8'),c);return c;}
const c=context(true),ref=context(false),n=c.window.NativeFood,R=c.window.RPGReact,views=fs.readFileSync(root+'shared-source/views.js','utf8');
const a=views.indexOf('  function sortDistance(items){'),b=views.indexOf('\n\n  // V104:',a),f=views.indexOf('    const filtered=s.items.filter(x=>{'),e=views.indexOf('\n    const visibleItems=',f),predicate=views.slice(f,e);
assert.ok(fs.readFileSync(assets+'category-places.js','utf8').includes(predicate),'exact original category predicate');
vm.runInContext('(function(){const RPG=window.RPGReact;\n'+views.slice(a,b)+'\nwindow.baseline=(category,raw,point)=>sortDistance(raw.map(x=>RPG.normalizePlace(x,category,point)));window.filter=(category,items,query,tagFilter,sub)=>{const s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";\n'+predicate+'\nreturn filtered;};})();',ref);
const manifest=JSON.parse(fs.readFileSync(assets+'source-manifest.json'));
for(const name of ['runtime','api','views','components'])assert.equal(crypto.createHash('sha256').update(fs.readFileSync(root+'shared-source/'+name+'.js')).digest('hex'),manifest.files[name+'.js']);
const ids=a=>JSON.stringify(a.map(x=>String(x.id))),point={lat:51.6572,lng:6.6186,city:'Wesel'};
function ingest(cat,rows,p=point,km=5){n.reset(cat);for(let i=0;i<rows.length;i+=80)n.append(rows.slice(i,i+80));n.commit(p,km);}
let filterCases=0,originalImages=0,credits=0,galleryImages=0;const summaries=[];
for(const cat of ['culture','activities'])for(const [name,p,km]of [['wesel-5km',point,5],['wesel-25km',point,25],['essen-5km',{lat:51.4556,lng:7.0116,city:'Essen'},5],['dortmund-5km',{lat:51.5136,lng:7.4653,city:'Dortmund'},5]]){
 const raw=JSON.parse(fs.readFileSync(__dirname+'/fixtures/'+cat+'-'+name+'.json')).elements;assert.ok(raw.length>0);
 const baseline=ref.window.baseline(cat,raw,p);ingest(cat,raw,p,km);const page=n.query('','','',99999);
 assert.equal(ids(page.items),ids(baseline),'source IDs and distance order');assert.equal(page.total,raw.length,'full category, no Home shortlist');assert.ok(page.items.every(x=>x.category===cat&&!x.event));assert.equal(new Set(page.items.map(x=>x.id)).size,page.total);
 const cases=[['','',''],['nichts123456','',''],[p.city,'',''],['Park','',''],...page.tags.map(t=>['',t.slug,'']),...page.subtypes.map(t=>['','',t])];
 for(const t of page.tags.slice(0,12))for(const s of page.subtypes.slice(0,6))cases.push([p.city,t.slug,s]);
 for(const [q,t,s]of cases){assert.equal(ids(n.query(q,t,s,99999).items),ids(ref.window.filter(cat,baseline,q,t,s)));filterCases++;}
 assert.equal(n.query('','','',24).items.length,Math.min(24,baseline.length),'native pagination');
 for(const x of baseline){const d=n.detail(String(x.id)),h=ref.window.RPGReact.placeOpeningStatus(x,x.openingHours);assert.equal(d.title,ref.window.RPGReact.displayPlaceTitle(x));assert.equal(d.distance,ref.window.RPGReact.formatDistance(x.distanceKm));assert.equal(JSON.stringify(d.labels.map(x=>x.label)),JSON.stringify(ref.window.RPGReact.categoryFilterTags(x)));assert.equal(d.hours,h.label||'');assert.equal(d.hoursHeading,h.heading||'');assert.equal(d.hoursFormatted,h.formatted||'');assert.equal(d.price,(x.tags&&(x.tags.charge||x.tags.fee))||'');
  assert.equal(d.media.url,x.displayImageSuppressed?'':(x.displayImageUrl||x.imageUrl||''));assert.equal(d.gallery.length,(x.galleryImages||[]).length);galleryImages+=d.gallery.length;
  if(x.imageUrl&&!x.displayImageSuppressed&&(!x.displayImageUrl||x.displayImageUrl===x.imageUrl)){originalImages++;const entry=(x.galleryImages||[]).find(e=>e.url===x.imageUrl)||{};assert.equal(d.media.credit,String(entry.credit||(x.tags||{})['rg:image_credit']||''));assert.equal(d.media.license,String(entry.license||(x.tags||{})['rg:image_license']||''));if(d.media.credit)credits++;}
 }
 summaries.push({category:cat,fixture:name,places:page.total});
}
const row=(id,tags={})=>({id,type:'node',lat:point.lat,lon:point.lng,tags:{name:'Testort '+id,'addr:city':'Wesel',...tags}});
for(const cat of ['culture','activities']){
 ingest(cat,[],point,1);assert.equal(n.query('','','',24).total,0,'no invented empty-result radius fallback');
 ingest(cat,[row(9100001)],point,1);const page=n.query('','','',24);assert.equal(page.total,1);assert.equal(page.items[0].media.url,'');assert.equal(page.items[0].price,'');assert.ok(n.detail(page.items[0].id));
}
// Original Activity Public Outdoor semantics, including unknown access hours.
for(const tags of [
 {'rg:activity_v2_primary':'skatepark',access:'public'},
 {'rg:activity_v2_primary':'skatepark',access:'public',opening_hours:'24/7'},
 {'rg:activity_v2_primary':'pumptrack',access:'public',opening_hours:'Mo-Su 10:00-18:00'},
 {'rg:activity_v2_primary':'skatepark',access:'private'},
 {'rg:activity_v2_primary':'skatepark',access:'public',indoor:'yes'},
 {'rg:activity_v2_primary':'table_tennis',access:'public','addr:street':'Am Testpark',name:'Tischtennisanlage'},
 {'rg:activity_v2_primary':'skatepark',access:'public',fee:'yes'}
]){
 const raw=row(9100002,tags);ingest('activities',[raw]);const original=ref.window.RPGReact.normalizePlace(raw,'activities',point),h=ref.window.RPGReact.placeOpeningStatus(original,original.openingHours),d=n.query('','','',24).items[0];assert.equal(d.hours,h.label);assert.equal(d.hoursHeading,h.heading);assert.equal(d.title,ref.window.RPGReact.displayPlaceTitle(original));if(!tags.opening_hours&&R.activityPublicOutdoorMode(original)){assert.equal(d.hoursHeading,'Zugang & Nutzungszeiten');assert.ok(d.hours.includes('nicht bekannt'));assert.ok(!d.hours.includes('Rund um die Uhr'));}
}
const flush=()=>new Promise(setImmediate),post=R.api.post;
(async()=>{
 for(const cat of ['culture','activities']){
  const raw=row(9100003,{wikidata:'Q1'});ingest(cat,[raw]);const id=n.query('','','',24).items[0].id,oldIds=ids(n.query('','','',24).items);let request=n.highlightsMediaRequest(id,'');assert.equal(request.url,R.settings.placeInfoUrl);assert.equal(request.body.category,cat);
  // Compare complete captured bodies with the actual original asynchronous API.
  const original=ref.window.RPGReact.normalizePlace(raw,cat,point),captured=[];
  ref.window.RPGReact.api.post=async(url,body)=>{captured.push(JSON.parse(JSON.stringify({url,body})));return url===R.settings.placeInfoUrl?{status:'success',website:'https://example.org/official'}:{imageUrl:'https://example.org/venue.jpg',credit:'Fotograf',license:'CC BY 4.0'};};
  const expected=await ref.window.RPGReact.resolveItemMedia(original);assert.equal(JSON.stringify(request),JSON.stringify(captured[0]));
  n.highlightsMediaAdvance(id,{status:'success',website:'https://example.org/official'});await flush();request=n.highlightsMediaState(id).request;assert.equal(JSON.stringify(request),JSON.stringify(captured[1]));assert.equal(request.body.allowSymbolic,false);assert.equal(R.api.post,post);
  n.highlightsMediaAdvance(id,{imageUrl:expected,credit:'Fotograf',license:'CC BY 4.0'});await flush();assert.equal(n.highlightsMediaState(id).applied,true);assert.equal(n.detail(id).media.url,expected);assert.equal(n.detail(id).media.credit,'Fotograf');assert.equal(ids(n.query('','','',24).items),oldIds);
  n.highlightsMediaRequest(id,'');n.reset(cat==='culture'?'activities':'culture');assert.equal(n.highlightsMediaAdvance(id,{imageUrl:'https://example.org/stale.jpg'}),false);n.append([raw]);n.commit(point);assert.equal(n.query('','','',24).items[0].media.url,'','same ID in different category has no stale media');
 }
 // Category switch also clears old per-category query state in the JS pool.
 for(const cat of ['food','highlights','culture','activities']){ingest(cat,[row(9100004)]);assert.equal(n.query('','','',24).items[0].category,cat);}
 console.log(JSON.stringify({result:'PASS',summaries,filterParityCases:filterCases,originalImages,credits,galleryImages,edgeCases:['full category not Home shortlist','combined text/type/theme filters','pagination','no photo exclusion','empty lists','unknown prices','original public outdoor semantics','original title enrichment','exact original async resolver request bodies','category switch and stale media isolation']}));
})().catch(e=>{console.error(e);process.exitCode=1;});
