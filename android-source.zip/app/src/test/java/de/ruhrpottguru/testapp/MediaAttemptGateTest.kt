package de.ruhrpottguru.testapp

import org.junit.Assert.*
import org.junit.Test
import de.ruhrpottguru.testapp.MediaAttemptGate.Outcome.*

class MediaAttemptGateTest {
    @Test fun transientFailureWaitsThenRetriesOnce() {
        var now=0L;val gate=MediaAttemptGate{now}
        val first=gate.begin("a")!!;assertNull(gate.begin("a"));assertTrue(gate.finish(first,TRANSIENT_FAILURE))
        assertNull(gate.begin("a"));assertNull(gate.begin("a",true))
        now=MediaAttemptGate.RETRY_DELAY_MS;val second=gate.begin("a")!!
        assertFalse(gate.finish(second,TRANSIENT_FAILURE));now+=100000;assertNull(gate.begin("a"));assertNull(gate.begin("a",true))
    }
    @Test fun actualNoImageDoesNotLoopOnFilterRefresh() {
        val gate=MediaAttemptGate();val ticket=gate.begin("none")!!
        assertFalse(gate.finish(ticket,NO_IMAGE));repeat(100){assertNull(gate.begin("none"))}
    }
    @Test fun resolvedImageMayFailLaterWithoutPermanentLock() {
        val gate=MediaAttemptGate();val first=gate.begin("resolved")!!;gate.finish(first,APPLIED)
        assertNull(gate.begin("resolved"));val repair=gate.begin("resolved",true)!!
        assertNull(gate.begin("resolved",true));gate.finish(repair,NO_IMAGE);assertNull(gate.begin("resolved",true))
    }
    @Test fun resetDoesNotAcceptAnOldTicketForNewContext() {
        val gate=MediaAttemptGate();val old=gate.begin("same")!!;gate.clear();val current=gate.begin("same")!!
        assertNotEquals(old.serial,current.serial);assertFalse(gate.finish(old,TRANSIENT_FAILURE));assertNull(gate.begin("same"))
        assertFalse(gate.finish(current,NO_IMAGE));assertNull(gate.begin("same"))
    }
    @Test fun independentIdsDoNotBlockEachOtherAndDuplicateCompletionIsIgnored() {
        val gate=MediaAttemptGate();val a=gate.begin("a")!!;val b=gate.begin("b")!!
        assertFalse(gate.finish(a,APPLIED));assertFalse(gate.finish(a,TRANSIENT_FAILURE));assertNull(gate.begin("b"));assertFalse(gate.finish(b,NO_IMAGE))
    }
}
