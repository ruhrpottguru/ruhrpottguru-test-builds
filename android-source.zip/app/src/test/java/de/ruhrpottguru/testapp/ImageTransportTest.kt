package de.ruhrpottguru.testapp

import org.junit.Assert.*
import org.junit.Test
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import okhttp3.tls.HandshakeCertificates
import okhttp3.tls.HeldCertificate
import java.util.concurrent.TimeUnit

class ImageTransportTest {
    @Test fun upgradeKeepsSameHostPathQueryAndHttpsUnchanged() {
        assertEquals("https://example.org/foto.jpg?size=1200&license=by",ImageTransportPolicy.secureUrl("http://example.org:80/foto.jpg?size=1200&license=by"))
        assertEquals("https://example.org:8443/foto%20%C3%A4.jpg?x=%2F",ImageTransportPolicy.secureUrl("https://example.org:8443/foto%20%C3%A4.jpg?x=%2F"))
        assertEquals("https://example.org/a#copyright",ImageTransportPolicy.secureUrl("https://example.org/a#copyright"))
    }
    @Test fun noUnsafeSchemesCredentialsOrPlainCustomPorts() {
        listOf("file:///etc/passwd","data:image/png;base64,AA","http://example.org:8080/a","https://user:pass@example.org/a").forEach {value->assertThrows(IllegalArgumentException::class.java){ImageTransportPolicy.secureUrl(value)}}
    }
    @Test fun retryableHttpStatusesExcludePermanentErrors() {
        listOf(408,429,500,502,503,504).forEach {assertTrue(ImageTransportPolicy.transientStatus(it))}
        listOf(200,301,400,401,403,404,410).forEach {assertFalse(ImageTransportPolicy.transientStatus(it))}
    }
    private fun trusted(client:OkHttpClient,certificate:HeldCertificate):OkHttpClient {
        val trust=HandshakeCertificates.Builder().addTrustedCertificate(certificate.certificate).build()
        return client.newBuilder().sslSocketFactory(trust.sslSocketFactory(),trust.trustManager).build()
    }
    private fun withServer(block:(MockWebServer,HeldCertificate)->Unit) {
        val cert=HeldCertificate.Builder().addSubjectAlternativeName("localhost").commonName("localhost").build()
        val tls=HandshakeCertificates.Builder().heldCertificate(cert).build()
        MockWebServer().use {server->server.useHttps(tls.sslSocketFactory(),false);server.start();block(server,cert)}
    }
    @Test fun productionInterceptorSolvesGenericClient403WithoutBrowserImpersonation()=withServer {server,cert->
        server.dispatcher=object:Dispatcher(){override fun dispatch(request:RecordedRequest)=if(request.getHeader("User-Agent")==ImageTransportPolicy.USER_AGENT)MockResponse().setBody("photo").setHeader("Content-Type","image/jpeg") else MockResponse().setResponseCode(403)}
        val request=Request.Builder().url(server.url("/image.jpg?width=1200")).build()
        trusted(OkHttpClient(),cert).newCall(request).execute().use {assertEquals(403,it.code)}
        trusted(ImageTransportClient.create(),cert).newCall(request).execute().use {assertEquals(200,it.code);assertEquals("photo",it.body!!.string())}
        val original=server.takeRequest(2,TimeUnit.SECONDS)!!;val repaired=server.takeRequest(2,TimeUnit.SECONDS)!!
        assertTrue(original.getHeader("User-Agent")!!.startsWith("okhttp/"));assertEquals(ImageTransportPolicy.USER_AGENT,repaired.getHeader("User-Agent"));assertFalse(ImageTransportPolicy.USER_AGENT.contains("Mozilla"));assertEquals(original.path,repaired.path)
    }
    @Test fun httpsRedirectKeepsIdentificationButNeverFollowsDowngrade()=withServer {server,cert->
        val client=trusted(ImageTransportClient.create(),cert)
        server.enqueue(MockResponse().setResponseCode(302).setHeader("Location",server.url("/next.jpg")))
        server.enqueue(MockResponse().setBody("photo"))
        client.newCall(Request.Builder().url(server.url("/first")).build()).execute().use {assertEquals(200,it.code)}
        repeat(2){assertEquals(ImageTransportPolicy.USER_AGENT,server.takeRequest(2,TimeUnit.SECONDS)!!.getHeader("User-Agent"))}
        server.enqueue(MockResponse().setResponseCode(302).setHeader("Location","http://localhost:${server.port}/unsafe.jpg"))
        client.newCall(Request.Builder().url(server.url("/downgrade")).build()).execute().use {assertEquals(302,it.code)}
        assertEquals("/downgrade",server.takeRequest(2,TimeUnit.SECONDS)!!.path);assertNull(server.takeRequest(200,TimeUnit.MILLISECONDS))
    }
    @Test fun permanentAndTransientResponsesAreNotRetriedByAnUnboundedInterceptor()=withServer {server,cert->
        val client=trusted(ImageTransportClient.create(),cert)
        for(code in listOf(404,503)) {
            server.enqueue(MockResponse().setResponseCode(code))
            client.newCall(Request.Builder().url(server.url("/broken.jpg")).build()).execute().use {assertEquals(code,it.code)}
            assertNotNull(server.takeRequest(2,TimeUnit.SECONDS));assertNull(server.takeRequest(100,TimeUnit.MILLISECONDS))
        }
    }
}
