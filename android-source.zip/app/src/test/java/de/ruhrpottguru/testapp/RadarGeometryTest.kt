package de.ruhrpottguru.testapp

import org.junit.Assert.*
import org.junit.Test

class RadarGeometryTest {
    @Test fun webZoomAndViewportRadius() {
        assertEquals(16.0,RadarGeometry.initialZoom(1.0),0.0)
        assertEquals(15.0,RadarGeometry.initialZoom(2.5),0.0)
        assertEquals(14.0,RadarGeometry.initialZoom(5.0),0.0)
        // Original BudeMap formula at Wesel for320x360 CSS pixels.
        assertEquals(1.4274968312744705,RadarGeometry.radiusKm(51.6572,14.0,320.0,360.0),1e-9)
        assertEquals(.5,RadarGeometry.radiusKm(51.6572,18.0,320.0,360.0),0.0)
        assertEquals(50.0,RadarGeometry.radiusKm(0.0,10.0,50000.0,50000.0),0.0)
    }
    @Test fun originalProxyAndWrap() {
        assertEquals("https://www.ruhrpottguru.de/wp-admin/admin-ajax.php?action=rg_places_map_tile&z=14&x=16383&y=5438",RadarGeometry.tileUrl(14,-1,5438))
        assertThrows(IllegalArgumentException::class.java){RadarGeometry.tileUrl(9,0,0)}
        assertThrows(IllegalArgumentException::class.java){RadarGeometry.tileUrl(14,0,-1)}
    }
    @Test fun overlappingMarkersStayNonClickable() {
        val points=listOf(TravelPixel(0.0,0.0),TravelPixel(23.0,0.0),TravelPixel(24.0,24.0))
        assertTrue(RadarGeometry.overlaps(points,0));assertTrue(RadarGeometry.overlaps(points,1));assertFalse(RadarGeometry.overlaps(points,2))
        assertFalse(RadarGeometry.overlaps(listOf(TravelPixel(0.0,0.0),TravelPixel(24.0,0.0)),0))
    }
}
