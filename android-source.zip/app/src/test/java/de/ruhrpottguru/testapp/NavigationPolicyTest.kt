package de.ruhrpottguru.testapp
import org.junit.Assert.*
import org.junit.Test
class NavigationPolicyTest {
 @Test fun explicitVenueAndDirectionsActionsWork() {
  listOf("https://www.ruhrpottguru.de/food/", "https://example.org/menu.pdf", "http://example.org/", "https://www.google.com/maps/dir/?api=1&destination=51.6%2C6.6", "tel:+49 (0)281 1234", "mailto:kontakt@example.org").forEach {assertTrue(it,allowedExternalUrl(it))}
 }
 @Test fun credentialsAndActiveSchemesAreRejected() {
  listOf("https://name@example.org/", "javascript:alert(1)", "file:///etc/passwd", "intent://example", "data:text/html,hello", "bad url", "tel:123?extra=1", "https:///no-host", "mailto:kontakt@example.org?bcc=other@example.org", "mailto:bad\n@example.org", "mailto:bad%0A@example.org", "mailto:a@example.org,b@example.org").forEach {assertFalse(it,allowedExternalUrl(it))}
 }
}
