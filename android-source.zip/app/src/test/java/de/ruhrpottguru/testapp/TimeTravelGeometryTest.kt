package de.ruhrpottguru.testapp

import org.junit.Assert.*
import org.junit.Test
import java.net.URI
import java.net.URLDecoder
import kotlin.math.*

class TimeTravelGeometryTest {
    private val rows=javaClass.classLoader!!.getResourceAsStream("time-travel-golden.tsv")!!.bufferedReader().use {it.readLines()}.map {it.split('\t')}
    private val years=rows.first {it[0]=="years"}.drop(1)
    @Test fun projectionMatchesOriginalLeaflet() {
        rows.filter {it[0]=="project"}.forEach {r->val lat=r[1].toDouble();val lng=r[2].toDouble();val z=r[3].toDouble();val p=TravelGeometry.project(lat,lng);val w=TravelGeometry.world(lat,lng,z);assertEquals(r[4].toDouble(),p.x,.000001);assertEquals(r[5].toDouble(),p.y,.000001);assertEquals(r[6].toDouble(),w.x,.000001);assertEquals(r[7].toDouble(),w.y,.000001);val back=TravelGeometry.point(w.x,w.y,z);assertEquals(lat.coerceIn(-TravelGeometry.MAX_LAT,TravelGeometry.MAX_LAT),back.lat,.00000001);assertEquals(lng,back.lng,.00000001)}
    }
    @Test fun wmsLayersTimeAndAxisOrderMatchWeb() {
        rows.filter {it[0]=="tile"}.forEach {r->val z=r[2].toInt();val x=r[3].toInt();val y=r[4].toInt();val spec=WmsSpec(r[5],r[6],r[7],r[8],r[9].toBoolean(),r[10]);val url=TravelGeometry.tileUrl(spec,z,x,y);val query=URI(url).rawQuery.split('&').associate {p->val pair=p.split('=',limit=2);pair[0]to URLDecoder.decode(pair[1],"UTF-8")};assertEquals("WMS",query["service"]);assertEquals("GetMap",query["request"]);assertEquals(spec.layer,query["layers"]);assertEquals(spec.format,query["format"]);assertEquals(spec.version,query["version"]);assertEquals("256",query["width"]);assertEquals("256",query["height"]);assertEquals(spec.transparent.toString(),query["transparent"]);assertEquals("EPSG:3857",query[if(spec.version=="1.3.0")"crs" else "srs"]);assertEquals(spec.time.ifBlank {null},query["time"]);val expected=URI(r[15]).rawQuery.split('&').associate {p->val pair=p.split('=',limit=2);pair[0]to URLDecoder.decode(pair[1],"UTF-8")};assertEquals(expected.keys,query.keys);expected.filterKeys {it!="bbox"}.forEach {(k,v)->assertEquals(v,query[k])};val box=query.getValue("bbox").split(',').map {it.toDouble()};for(i in 0..3)assertEquals(r[11+i].toDouble(),box[i],.0001)}
    }
    @Test fun originalShortShareLinksKeepYearCenterAndMarker() {
        rows.filter {it[0]=="share"}.forEach {r->val s=TravelGeometry.parseLink(r[1],years)!!;assertEquals(r[2].toDouble(),s.lat,.000000001);assertEquals(r[3].toDouble(),s.lng,.000000001);assertEquals(r[4].toInt(),s.zoom);assertEquals(r[5],s.year);assertEquals(r[6].toDouble(),s.markerLat,.000000001);assertEquals(r[7].toDouble(),s.markerLng,.000000001);assertNotEquals(s.lat,s.markerLat)}
    }
    @Test fun legacyQueryLinksAndMalformedInput() {
        val s=TravelGeometry.parseLink("https://www.ruhrpottguru.de/zeitreise-von-oben/?zvo_lat=51.5&zvo_lng=7.1&zvo_y=1934&zvo_z=18&zvo_mlat=51.6&zvo_mlng=7.2",years)!!;assertEquals("1934",s.year);assertEquals(18,s.zoom);assertEquals(51.6,s.markerLat,0.0)
        val fallback=TravelGeometry.parseLink("https://www.ruhrpottguru.de/zeitreise-von-oben/?zvo_lat=51.5&zvo_lng=7.1&zvo_y=unknown&zvo_z=99",years)!!;assertEquals("current",fallback.year);assertEquals(17,fallback.zoom);assertEquals(fallback.lat,fallback.markerLat,0.0)
        for(url in listOf("https://evil.example/z/AE54qgAKrc8ATnjwAAqtxBEC/","javascript:alert(1)","https://www.ruhrpottguru.de/z/bad/","https://name@www.ruhrpottguru.de/z/AE54qgAKrc8ATnjwAAqtxBEC/","https://www.ruhrpottguru.de/zeitreise-von-oben/?zvo_lat=NaN&zvo_lng=7.1","https://www.ruhrpottguru.de/zeitreise-von-oben/?zvo_lat=91&zvo_lng=7.1"))assertNull(url,TravelGeometry.parseLink(url,years))
    }
    @Test fun panAndPinchPreserveGeographicAnchor() {
        val c=TravelCamera(51.6572,6.6186,17.0);val p=TravelGeometry.world(c.lat,c.lng,c.zoom);val moved=TravelGeometry.transform(c,400.0,300.0,200.0,150.0,100.0,0.0,1.0);val m=TravelGeometry.world(moved.lat,moved.lng,moved.zoom);assertEquals(p.x-100,m.x,.0000001);assertEquals(p.y,m.y,.0000001)
        val z=TravelGeometry.transform(c,400.0,300.0,100.0,70.0,0.0,0.0,2.0);assertEquals(18.0,z.zoom,0.0);val anchorOld=TravelGeometry.point(p.x-100,p.y-80,17.0);val centerNew=TravelGeometry.world(z.lat,z.lng,18.0);val anchorNew=TravelGeometry.point(centerNew.x-100,centerNew.y-80,18.0);assertEquals(anchorOld.lat,anchorNew.lat,.00000001);assertEquals(anchorOld.lng,anchorNew.lng,.00000001)
    }
    @Test fun boundsAndZoomLimits() {
        assertEquals(20.0,TravelGeometry.transform(TravelCamera(51.6,6.6,20.0),400.0,300.0,200.0,150.0,0.0,0.0,4.0).zoom,0.0);assertEquals(9.0,TravelGeometry.transform(TravelCamera(51.6,6.6,9.0),400.0,300.0,200.0,150.0,0.0,0.0,.1).zoom,0.0)
        assertEquals(TravelCamera(51.6,6.6),TravelGeometry.transform(TravelCamera(51.6,6.6),400.0,300.0,200.0,150.0,0.0,0.0,Double.NaN))
        try{TravelGeometry.tileUrl(WmsSpec("https://example.org/other","x","1.1.1","image/jpeg",false),17,1,1);fail("unexpected provider accepted")}catch(_:IllegalArgumentException){}
    }
}
