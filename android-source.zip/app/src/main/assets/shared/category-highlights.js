(function(){
const RPG=window.RPGReact;
window.rpgHighlightsFilter=function(items,query,tagFilter,sub){
const category="highlights",s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";
    const filtered=s.items.filter(x=>{
      const facet=category==='events'?x.eventType:x.subtitle;
      const textOk=!q||[x.title,x.subtitle,x.eventType,x.city,x.address].concat(Array.isArray(x.labels)?x.labels:[]).join(' ').toLowerCase().includes(q);
      const tagOk=!tagFilter||RPG.categoryFilterTags(x).some(label=>RPG.tagSlug(label)===tagFilter);
      const dateOk=category!=='events'||!dateFrom||eventOverlapsDateRange(x,dateFrom,dateTo);
      return (!sub||facet===sub)&&textOk&&tagOk&&dateOk;
    });
return filtered;
};})();
