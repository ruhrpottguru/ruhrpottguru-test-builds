(function(){const RPG=window.RPGReact;
  function mediaCropValues(crop){
    if(!crop||!['auto','manual'].includes(String(crop.mode||'')))return null;
    const raw=Number(crop.zoom??1);
    return {x:Math.max(0,Math.min(100,Number(crop.x??50))),y:Math.max(0,Math.min(100,Number(crop.y??50))),zoom:Number.isFinite(raw)?Math.max(0,Math.min(2.5,raw)):1};
  }
  function cropForImage(item,image,which,entry){
    if(entry&&entry.url===image){const c=which==='detail'?entry.cropDetail:entry.cropCard;if(c)return c;}
    if(item&&image&&image===item.imageUrl)return which==='detail'?item.imageCropDetail:item.imageCropCard;
    return null;
  }
window.rpgMediaCropValues=mediaCropValues;window.rpgCropForImage=cropForImage;
window.rpgNativeMediaResponse=function(item,data){
      const image = data.imageUrl || '';
      const meta = [data.alt,data.credit,data.reason,data.sourceUrl,image].join(' ');
      if (item.category !== 'events' && RPG.personHint(meta)) return '';
      return image;
};})();
