(function(){const RPG=window.RPGReact,eventAllDayValue=window.rpgEventAllDayValue;
  function routeTypeLabel(value) {
    const v=String(value||'').toLowerCase();
    if(v==='anchor'||v==='ankerpunkt')return 'Ankerpunkt';
    if(v==='panorama')return 'Panorama';
    if(v==='settlement'||v==='siedlung')return 'Siedlung';
    return String(value||'');
  }

  // V174: Restore the proven event calendar actions from the pre-source-React
  // build. Apple/iPhone receives a standards-compliant .ics file; Android uses
  // Google Calendar with the same title, time, location and description.
  function eventTypeBadgeMeta(item) {
    if(!item||item.category!=='events'||RPG.settings.eventTypeBadgesEnabled===false)return null;
    const bits=[];
    const push=value=>{
      if(value==null)return;
      if(typeof value==='string'||typeof value==='number'){const v=String(value).trim();if(v)bits.push(v);return;}
      if(Array.isArray(value)){value.forEach(push);return;}
      if(typeof value==='object'){
        ['name','title','label','value','category','type','classification','eventType'].forEach(k=>{if(value[k]!=null)push(value[k]);});
      }
    };
    const info=item.eventInfo&&typeof item.eventInfo==='object'?item.eventInfo:{};
    push(info.categories);push(info.features);push(info.keywords);
    const raw=item.raw&&typeof item.raw==='object'?item.raw:{};
    push(raw.categories);push(raw.keywords);push(raw.features);push(raw.type);push(raw.types);push(raw.classification);push(raw.classifications);
    push(item.title);
    const text=bits.join(' ').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('de');
    if(!text)return null;

    // Specific signals win over broad umbrella categories. If no explicit signal
    // exists we intentionally render no badge rather than inventing an event type.
    if(/raetsel|ratsel|escape|quiz|schnitzeljagd|detektiv/.test(text))return {key:'puzzle',label:'Rätsel'};
    if(/fuehrung|fuhrung|guided\s+tour|rundgang|stadtrundgang|werksfuehrung|werksfuhrung/.test(text))return {key:'tour',label:'Führung'};
    if(/ausstellung|exhibition|vernissage|galerie|kunstschau/.test(text))return {key:'exhibition',label:'Ausstellung'};
    if(/konzert|live\s*music|musikveranstaltung|chor|orchester|\bband\b|\bjazz\b|\brock\b|\bpop\b/.test(text))return {key:'concert',label:'Konzert'};
    if(/theater|schauspiel|operette|\boper\b|musical|performance|buehne|buhne/.test(text))return {key:'stage',label:'Bühne'};
    if(/workshop|kurs|seminar|mitmach|atelierkurs/.test(text))return {key:'workshop',label:'Workshop'};
    if(/vortrag|lesung|lecture|talk|diskussion|podium/.test(text))return {key:'talk',label:'Vortrag'};
    if(/kino|filmvorfuehrung|filmvorfuhrung|screening|\bfilm\b/.test(text))return {key:'film',label:'Film'};
    if(/kinder|familien|familie|kids|ferienprogramm/.test(text))return {key:'family',label:'Familie'};
    if(/flohmarkt|troedelmarkt|trodelmarkt|weihnachtsmarkt|\bmarkt\b|stadtfest|strassenfest|straßenfest|kirmes|volksfest/.test(text))return {key:'market',label:'Markt/Fest'};
    if(/sport|marathon|laufveranstaltung|turnier|rennen|fussball|fußball|handball|basketball|radsport/.test(text))return {key:'sport',label:'Sport'};
    if(/party|clubnacht|nightlife|disco|tanzparty/.test(text))return {key:'party',label:'Party'};
    return null;
  }

  const CONTRIBUTION_FIELDS={
    food:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['menu_url','Speisekarte / Menü','url'],['reservation_url','Reservierungslink','url'],['cuisine','Küche / Angebot','text'],['price_tier','Preis-Hinweis','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']],
    highlights:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['access','Zugang / Zugänglichkeit','text'],['accessibility','Barrierefreiheit','text'],['admission','Eintritt / Kosten','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']],
    culture:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['ticket_url','Tickets','url'],['program_url','Programm','url'],['admission','Eintritt / Kosten','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']],
    activities:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['booking_url','Buchung / Reservierung','url'],['activity_type','Art der Aktivität / Ausstattung','text'],['price_tier','Preis-Hinweis','text'],['admission','Eintritt / Kosten','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']],
    buedchen:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['instagram','Instagram','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']],
    wurst:[['opening_hours','Öffnungszeiten','text'],['website','Website','url'],['phone','Telefon','tel'],['menu_url','Speisekarte / Menü','url'],['cuisine','Angebot / Spezialitäten','text'],['price_tier','Preis-Hinweis','text'],['description','Beschreibung / Hinweis','textarea'],['community_status','Status des Ortes','status']]
  };
window.rpgContributionFields=CONTRIBUTION_FIELDS;
window.rpgDetailFacts=function(item,foodInfo=null){const onTagFilter=()=>{};
    const meta=RPG.CATEGORIES[item.category]||{};
    const categoryTitle=meta.title||item.category||'';
    const displayTitle=RPG.displayPlaceTitle(item)||item.title;
    const routeUrl=RPG.settings.industrialRoutePageUrl||'/route-industriekultur/';
    const directions=item.coords?'https://www.google.com/maps/dir/?api=1&destination='+encodeURIComponent(item.coords.lat+','+item.coords.lng):'';
    const description=item.category==='events'
      ?String(item.description||'').replace(/<\s*br\s*\/?\s*>/gi,'\n').replace(/<\/\s*(?:p|div|li|h[1-6]|section|article)\s*>/gi,'\n').replace(/<[^>]*>/g,' ').replace(/[ \t]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim()
      :String(item.description||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
    const tags=RPG.categoryFilterTags(item);
    const tagFilterActive=RPG.isTagFilterCategory(item.category)&&typeof onTagFilter==='function';
    const routeType=routeTypeLabel(item.routeType);
    const effectiveWebsite=(foodInfo&&foodInfo.website)||item.website||'';
    const effectiveMenuUrl=(foodInfo&&foodInfo.menuUrl)||item.menuUrl||'';
    const effectiveReservationUrl=(foodInfo&&foodInfo.reservationUrl)||item.reservationUrl||'';
    const openingPilot=RPG.isOpeningHoursPilot(item);
    const effectiveOpeningHours=openingPilot?(item.openingHours||(item.tags&&item.tags.opening_hours)||(foodInfo&&foodInfo.openingHours)||''):((foodInfo&&foodInfo.openingHours)||item.openingHours||(item.tags&&item.tags.opening_hours)||'');
    const opening=RPG.formatOpeningHours(String(effectiveOpeningHours).trim());
    const openingStatus=openingPilot?RPG.placeOpeningStatus(item,effectiveOpeningHours):null;
    const parseEventLocalDate=value=>{if(value instanceof Date)return isNaN(value)?null:value;const text=String(value||'').trim();if(!text)return null;const m=text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);if(m){const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),Number(m[4]||0),Number(m[5]||0),Number(m[6]||0));return isNaN(d)?null:d;}const d=new Date(text);return isNaN(d)?null:d;};
    const formatEventTiming=(start,end,allDayFlag=false)=>{const a=parseEventLocalDate(start),b=parseEventLocalDate(end);if(!a)return '';const dateLong=new Intl.DateTimeFormat('de-DE',{weekday:'long',day:'numeric',month:'long',year:'numeric'});const dateShort=new Intl.DateTimeFormat('de-DE',{day:'numeric',month:'long',year:'numeric'});const time=new Intl.DateTimeFormat('de-DE',{hour:'2-digit',minute:'2-digit'});const midnight=d=>!!d&&d.getHours()===0&&d.getMinutes()===0&&d.getSeconds()===0;const sameDay=(x,y)=>x.getFullYear()===y.getFullYear()&&x.getMonth()===y.getMonth()&&x.getDate()===y.getDate();const allDay=!!allDayFlag||(midnight(a)&&(!b||!(b>a)||midnight(b)));if(allDay){if(b&&b>a&&midnight(b)){const last=new Date(b);last.setDate(last.getDate()-1);if(!sameDay(a,last))return dateShort.format(a)+' – '+dateShort.format(last);}return dateLong.format(a);}if(b&&b>a){if(sameDay(a,b))return dateLong.format(a)+' · '+time.format(a)+'–'+time.format(b)+' Uhr';return dateLong.format(a)+' · '+time.format(a)+' – '+dateLong.format(b)+' · '+time.format(b)+' Uhr';}return dateLong.format(a)+' · '+time.format(a)+' Uhr';};
    const eventDate=item.start?formatEventTiming(item.start,item.end,eventAllDayValue(item,item.start,item.end)):'';
    const eventDocuments=item.category==='events'?(Array.isArray(item.documents)?item.documents:[]).filter(d=>d&&String(d.url||'').trim()).slice(0,8):[];
    const eventVisitorHours=item.category==='events'?String(item.visitorHours||'').trim():'';
    const eventDayHours=item.category==='events'?String(item.dayHours||'').trim():'';
    const collapseExactRepeat=value=>{let text=String(value==null?'':value).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();for(let pass=0;pass<3;pass++){const words=text.split(/\s+/);if(words.length<2||words.length%2)break;const half=words.length/2;const a=words.slice(0,half).join(' '),b=words.slice(half).join(' ');const norm=v=>v.toLocaleLowerCase('de').replace(/[.,;:!?]+$/g,'').trim();if(norm(a)!==norm(b))break;text=a;}return text;};
    const foodPriceTier=item.category==='food'?String(item.priceTier||''):'';
    // V317: canonical Wesel prices can arrive compact as e.g. `45.00EUR`.
    // Normalize currency notation for visitors before deciding whether a usable
    // price signal exists. This keeps the source value authoritative while
    // presenting it in German notation.
    const formatEventPrice=value=>{let text=collapseExactRepeat(value||'');if(!text)return '';text=text.replace(/(\d+(?:[.,]\d{1,2})?)\s*EUR\b/ig,(_,raw)=>{const n=Number(String(raw).replace(',','.'));if(!Number.isFinite(n))return raw+' €';const hasCents=Math.abs(n-Math.round(n))>0.0001;return n.toLocaleString('de-DE',{minimumFractionDigits:hasCents?2:0,maximumFractionDigits:2})+' €';});return text;};
    const price=item.category==='events'?formatEventPrice(item.priceText||''):(item.category==='food'?foodPriceTier:((item.tags&&(item.tags['charge']||item.tags['fee']))||''));
    const eventFacts=item.category==='events'&&item.eventInfo&&typeof item.eventInfo==='object'?item.eventInfo:{};
    const cleanEventInfoList=values=>{const seen=new Set();return (Array.isArray(values)?values:[]).map(v=>String(v||'').trim()).filter(v=>{const k=v.toLocaleLowerCase('de');if(!v||/^(?:divers|sonstiges?|weitere events?)$/i.test(v)||seen.has(k))return false;seen.add(k);return true;});};
    const eventFeatures=cleanEventInfoList(eventFacts.features).slice(0,12);
    const eventCategories=cleanEventInfoList(eventFacts.categories).slice(0,10);
    const eventKeywords=cleanEventInfoList(eventFacts.keywords).slice(0,20);
    const eventAttributes=Array.isArray(eventFacts.attributes)?eventFacts.attributes:[];
    const eventNumbers=Array.isArray(eventFacts.numbers)?eventFacts.numbers:[];
    const isRichEvent=item.category==='events';
    const cleanRepeatedText=collapseExactRepeat;
    const cleanPriceLabel=value=>String(value||'').replace(/[_-]+/g,' ').replace(/\b(price|preis|admission|eintritt|fee|cost|charge)\b/ig,'').replace(/\s+/g,' ').trim();
    const structuredPrices=isRichEvent&&item.prices&&Array.isArray(item.prices.items)?(()=>{const seen=new Set();return item.prices.items.map(row=>row&&typeof row==='object'?Object.assign({},row,{value:cleanRepeatedText(row.value)}):row).filter(row=>{if(!row||!String(row.value||'').trim())return false;const key=(String(row.label||'')+'|'+String(row.value||'')).toLocaleLowerCase('de');if(seen.has(key))return false;seen.add(key);return true;}).slice(0,14);})():[];
    const priceHasSignal=value=>/(?:€|EUR\b|\beuro\b|kostenlos|eintritt\s+frei|freier\s+eintritt|ermäß|ermaess|familienkarte|\bpreis\b|\bgebühr\b|\bgebuehr\b|\d+[,.]\d{1,2}\s*(?:€|EUR|euro))/i.test(String(value||''));
    const displayPrice=structuredPrices.length||priceHasSignal(price)?price:'';
    // V319: ticket URLs sometimes arrive embedded in free-form price text (e.g.
    // "Tickets - Ticketlink: https://…; 15 € An der Abendkasse … 20 €").
    // Pull the URL out into its own action and keep only visitor-readable price facts.
    const embeddedTicketUrl=(()=>{const m=String(displayPrice||'').match(/https?:\/\/[^\s;|•]+/i);return m?m[0].replace(/[),.]+$/,''):'';})();
    const eventTicketUrl=item.category==='events'?(String(item.ticketUrl||embeddedTicketUrl||'').trim()):'';
    const cleanFreePriceText=value=>{let text=String(value||'');if(embeddedTicketUrl)text=text.replace(embeddedTicketUrl,' ');text=text.replace(/\bTickets?\s*-?\s*Ticketlink\s*:?/ig,' ').replace(/\bTicketlink\s*:?/ig,' ').replace(/\s+/g,' ').trim();return text.replace(/^[;|•,:\-\s]+|[;|•,:\-\s]+$/g,'').trim();};
    const fallbackPriceRows=(()=>{if(!displayPrice||structuredPrices.length)return [];const cleaned=cleanFreePriceText(displayPrice);if(!cleaned)return [];let rows=cleaned.split(/\s*(?:;|•|\|)\s*/).filter(Boolean);rows=rows.flatMap(v=>String(v).split(/\s+(?=An der Abendkasse\b|Abendkasse\b)/i)).filter(Boolean);if(rows.length<2&&cleaned.length>90)rows=cleaned.split(/,\s+(?=[A-ZÄÖÜ0-9])/).filter(Boolean);const seen=new Set();return rows.map(cleanRepeatedText).map(v=>v.replace(/^An der Abendkasse kostet (?:der )?Einlass\s*/i,'Abendkasse: ').replace(/^An der Abendkasse\s*/i,'Abendkasse: ')).filter(v=>{const k=v.toLocaleLowerCase('de');if(!v||seen.has(k))return false;seen.add(k);return true;}).slice(0,14).map(v=>({label:'',value:v}));})();
    const priceRows=structuredPrices.length?structuredPrices:fallbackPriceRows;
    const hasEventOrganizers=item.category==='events'&&Array.isArray(item.organizers)&&item.organizers.length>0;
    const hasEventParticipants=item.category==='events'&&Array.isArray(item.participants)&&item.participants.length>0;
    // V318: event type remains exclusively a discovery facet under
    // "Mehr davon entdecken". Timing, price and ET4 participants are grouped
    // in the upper Veranstaltungshinweis card next to Adresse & Ort.

    // V250: visitor-facing event facts. Keep the complete ET4 metadata internally,
    // but surface only a small set of facts that help a visitor decide quickly.
    // No fact is guessed from unrelated data: absent/ambiguous values simply stay hidden.
    const eventGlanceFacts=(()=>{
      if(item.category!=='events')return [];
      const out=[];const seen=new Set();
      const norm=v=>String(v==null?'':v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('de').replace(/\s+/g,' ').trim();
      const push=(key,label,kind,type)=>{const text=String(label||'').replace(/\s+/g,' ').trim();const k=norm(text);if(!text||seen.has(k)||out.length>=6)return;seen.add(k);out.push({key,label:text,kind:kind||key,type:type||''});};
      const values=eventCategories.concat(eventFeatures,eventKeywords);
      const valueText=values.join(' · ');
      const valueNorm=norm(valueText);
      const typedRows=eventAttributes.concat(eventNumbers).filter(r=>r&&typeof r==='object');
      const typedValue=(pattern)=>{for(const row of typedRows){const key=norm(row.key||row.type||row.label||'');const value=String(row.value==null?'':row.value).trim();if(pattern.test(key)&&value)return value;}return '';};
      const positiveTyped=(pattern)=>{for(const row of typedRows){const key=norm(row.key||row.type||row.label||'');const value=norm(row.value);if(!pattern.test(key))continue;if(/^(?:1|true|yes|ja|y|on|voll|full|accessible|barrierefrei|rollstuhlgerecht)$/.test(value))return true;}return false;};

      const typeMeta=eventTypeBadgeMeta(item);
      if(typeMeta)push('type',typeMeta.label,'type',typeMeta.key);

      // Price summary: exact free-admission signals first, otherwise only a short
      // explicit price string. Detailed tiers remain in the separate price block.
      const priceSignals=[displayPrice].concat(values).join(' · ');
      if(/(?:eintritt\s+frei|freier\s+eintritt|kostenlos|free\s+admission)/i.test(priceSignals)){
        push('price','Eintritt frei','free');
      }else{
        let quick='';
        if(structuredPrices.length===1)quick=cleanRepeatedText(structuredPrices[0].value||'');
        if(!quick&&displayPrice&&String(displayPrice).length<=42&&!/[;|•]/.test(String(displayPrice)))quick=cleanRepeatedText(displayPrice);
        if(quick&&/(?:€|\beuro\b|\d+[,.]?\d*\s*(?:€|euro)|\bab\s+\d+)/i.test(quick))push('price',quick,'price');
      }

      // Duration is derived only from one concrete same-day timed occurrence.
      const a=parseEventLocalDate(item.start),b=parseEventLocalDate(item.end);
      if(a&&b&&b>a&&a.toDateString()===b.toDateString()&&(a.getHours()||a.getMinutes())&&(b.getHours()||b.getMinutes())){
        const minutes=Math.round((b-a)/60000);
        if(minutes>0&&minutes<=12*60){
          const label=minutes<60?minutes+' Min.':(minutes%60?Math.floor(minutes/60)+' Std. '+(minutes%60)+' Min.':Math.floor(minutes/60)+' Std.');
          push('duration',label,'duration');
        }
      }

      // Explicit audience signals only. More specific labels win.
      if(/(?:\bfamilie(?:n)?\b|familienfreund|\bkinder\b|\bkids\b)/.test(valueNorm))push('audience','Familien','audience');
      else if(/(?:\bjugend(?:liche)?\b|teenager)/.test(valueNorm))push('audience','Jugendliche','audience');
      else if(/(?:\bsenior(?:en|innen)?\b)/.test(valueNorm))push('audience','Senioren','audience');
      else if(/(?:\berwachsene\b|adults?)/.test(valueNorm))push('audience','Erwachsene','audience');

      // Accessibility only on explicit positive source data.
      const negativeAccess=/(?:nicht\s+barrierefrei|nicht\s+rollstuhl|wheelchair\s*[:=]?\s*(?:no|false|0))/.test(valueNorm);
      if(!negativeAccess&&(/(?:barrierefrei|rollstuhlgerecht|wheelchair\s+accessible)/.test(valueNorm)||positiveTyped(/(?:barrier|accessib|wheelchair|rollstuhl)/)))push('access','Barrierefrei','access');

      // Indoor/outdoor only when the source says one side unambiguously.
      const hasIndoor=/(?:^|[ ·,;/])indoor(?:$|[ ·,;/])/.test(valueNorm);
      const hasOutdoor=/(?:^|[ ·,;/])outdoor(?:$|[ ·,;/])/.test(valueNorm);
      if(hasIndoor&&!hasOutdoor)push('setting','Indoor','indoor');
      else if(hasOutdoor&&!hasIndoor)push('setting','Outdoor','outdoor');

      // Language is shown only from an explicitly typed source field.
      let language=typedValue(/(?:^|\b)(?:language|sprache)(?:$|\b)/);
      if(language){const n=norm(language);if(/^(?:de|deu|ger|deutsch|german)$/.test(n))language='Deutsch';else if(/^(?:en|eng|englisch|english)$/.test(n))language='Englisch';else if(/^(?:fr|fra|fre|franzosisch|french)$/.test(n))language='Französisch';if(String(language).length<=28)push('language',language,'language');}
      return out.slice(0,6);
    })();

return {description,website:effectiveWebsite,menu:effectiveMenuUrl,reservation:effectiveReservationUrl,opening,openingStatus,price,glance:eventGlanceFacts,routeType,routeIndustrial:!!item.routeIndustrial,routeOfficialUrl:item.routeOfficialUrl||""};};
window.rpgDetailShare=function(item,mode,inviteMessage,inviteDuration){
      let url=RPG.buildShareUrl(item);
      // Buedchen without a canonical numeric place ID cannot use the /teilen/
      // resolver. Share the actual coordinates instead of a misleading radar homepage.
      // This fallback never changes SEO routes or normal item URL generation.
      if(item&&item.category==='buedchen'&&!RPG.shareDescriptor(item)&&!RPG.safeUrl(item.canonicalUrl)){
        const coords=item.coords||{};
        const lat=Number(coords.lat),lng=Number(coords.lng);
        if(Number.isFinite(lat)&&Number.isFinite(lng)&&Math.abs(lat)<=90&&Math.abs(lng)<=180){
          const p=lat.toFixed(6)+','+lng.toFixed(6);
          url='https://www.openstreetmap.org/?mlat='+encodeURIComponent(lat.toFixed(6))+'&mlon='+encodeURIComponent(lng.toFixed(6))+'#map=17/'+p.replace(',', '/');
        }
      }
      // The original v344 detail payload for the normal mode must remain exact.
      let text=(item.subtitle?item.subtitle+' – ':'')+(item.city||'Ruhrgebiet');
      if(item.category==='events'&&item.start instanceof Date&&!isNaN(item.start)){
        text=new Intl.DateTimeFormat('de-DE',eventAllDayValue(item,item.start,item.end)?{dateStyle:'medium'}:{dateStyle:'medium',timeStyle:'short'}).format(item.start)+(item.city?' · '+item.city:'');
      }
      if(mode==='invite'){
        const durationText=inviteDuration==='30'?'Ich bin ungefähr noch 30 Minuten hier.':inviteDuration==='60'?'Ich bin ungefähr noch 1 Stunde hier.':inviteDuration==='120'?'Ich bin ungefähr noch 2 Stunden hier.':'';
        text=[inviteMessage.trim(),durationText].filter(Boolean).join('\n');
      }
      const payload={title:item.title,text,url};
return payload;};
class FormData{constructor(){this.fields={};}append(k,v){if(!/^image_\d+$/.test(k))this.fields[k]=String(v);}}
window.rpgContributionPayload=function(item,input){const photoOnly=false,processingImages=false,fields=input.fields||{},images=(input.images||[]).map(x=>({...x,file:{name:x.name}})),rights=!!input.rights,submitterName=input.name||"",submitterEmail=input.email||"",sender=input.sender||"community";
    const hasData=Object.values(fields).some(v=>String(v||'').trim()!=='');
    const copyrightOk=images.every(x=>String(x.copyright||'').trim()!=='');
    const contactOk=!images.length||(submitterName.trim()!=='' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(submitterEmail.trim()));
    const canSend=!processingImages&&(hasData||images.length>0)&&(!images.length||(copyrightOk&&rights&&contactOk));
    const validationMessage=()=>{
      if(!hasData&&!images.length)return photoOnly?'Bitte wähle mindestens ein Foto aus.':'Bitte ergänze mindestens eine Angabe oder wähle ein Bild aus.';
      if(images.length&&!copyrightOk)return 'Bitte trage für jedes Bild Copyright / Urheber bzw. Rechteinhaber ein.';
      if(images.length&&submitterName.trim()==='')return 'Bitte trage deinen Namen oder deine Firma ein.';
      if(images.length&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(submitterEmail.trim()))return 'Bitte trage eine gültige E-Mail-Adresse ein.';
      if(images.length&&!rights)return 'Bitte bestätige die Rechteerklärung für den Bild-Upload.';
      return '';
    };

if(!canSend)return {error:validationMessage()};
      const clean={};Object.entries(fields).forEach(([k,v])=>{if(String(v||'').trim()!=='')clean[k]=v;});
      const fd=new FormData();fd.append('place_id',item.id);fd.append('category',item.category);fd.append('submitter_type',sender);fd.append('fields_json',JSON.stringify(clean));fd.append('rights_confirmed',rights?'1':'0');fd.append('submitter_name',submitterName.trim());fd.append('submitter_email',submitterEmail.trim());
      images.forEach((x,i)=>{fd.append('image_'+i,x.file,x.file.name);fd.append('copyright_'+i,x.copyright.trim());if(String(x.sourceUrl||'').trim())fd.append('source_url_'+i,String(x.sourceUrl).trim());});

return {fields:fd.fields};};
window.rpgStoryPayload=function(item,input){const title=input.title||"",content=input.content||"",nickname=input.name||"",email=input.email||"",instagram=input.instagram||"",images=input.images||[],rights=!!input.rights,terms=!!input.terms,privacy=!!input.privacy,maxFiles=5;let error="";const setStatus=s=>{error=s;};(function(){
      if(!images.length){setStatus('Bitte wähle mindestens ein Foto aus. Ein Bild ist für Community-Beiträge Pflicht.');return;}
      if(title.trim().length<4){setStatus('Bitte gib eine kurze Überschrift mit mindestens 4 Zeichen ein.');return;}
      if(content.trim().length<20){setStatus('Dein Tipp sollte mindestens 20 Zeichen lang sein.');return;}
      if(!nickname.trim()){setStatus('Bitte trage einen Namen oder Nickname ein.');return;}
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){setStatus('Bitte trage eine gültige E-Mail-Adresse ein.');return;}
      if(!rights){setStatus('Bitte bestätige die Bildrechte.');return;}
      if(!terms){setStatus('Bitte stimme den Einreichungsbedingungen zu.');return;}
      if(!privacy){setStatus('Bitte stimme der Datenschutzerklärung zu.');return;}

})();if(error)return {error};
      const fd=new FormData();fd.append('place_id',item.id);fd.append('category',item.category);fd.append('title',title.trim());fd.append('content',content.trim());fd.append('nickname',nickname.trim());fd.append('email',email.trim());fd.append('instagram',instagram.trim());fd.append('terms_accepted','1');fd.append('privacy_accepted','1');fd.append('image_rights_confirmed','1');fd.append('company','');images.slice(0,maxFiles).forEach((f,i)=>fd.append('image_'+i,f,f.name));

return {fields:fd.fields};};
  function communityInstagram(value){
    const raw=String(value||'').trim();if(!raw)return null;
    let handle=raw.replace(/^https?:\/\/(?:www\.)?instagram\.com\//i,'').replace(/^@/,'').split(/[\/?#]/)[0].trim();
    if(!/^[A-Za-z0-9._]{1,30}$/.test(handle))return {label:raw,url:''};
    return {label:'@'+handle,url:'https://www.instagram.com/'+handle+'/'};
  }

window.rpgCommunityInstagram=communityInstagram;})();

window.rpgPlaceEventRow=function(event){const RPG=window.RPGReact;
        const id=Number(event.raw&&event.raw.rpg_event_db&&event.raw.rpg_event_db.eventId||0);
        const href=event.canonicalUrl||RPG.buildShareUrl(event);
        const dateOptions={day:'2-digit',month:'2-digit',year:'numeric',...(event.allDay?{timeZone:'UTC'}:{})};
        const when=(event.end&&event.start<Date.now()&&event.end>Date.now()?'Läuft bis '+event.end.toLocaleDateString('de-DE',dateOptions):event.start.toLocaleDateString('de-DE',dateOptions)+(event.allDay?'':' · '+event.start.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'})+' Uhr'));

return {eventId:id,title:event.title,date:when,canonicalUrl:href};};
