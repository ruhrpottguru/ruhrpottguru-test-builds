(function(){const RPG=window.RPGReact;
  function homeEventDayAccess(item,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const dayCodes=['SO','MO','DI','MI','DO','FR','SA'];
    const day=dayCodes[now.getDay()];
    const minute=now.getHours()*60+now.getMinutes();
    const texts=[String(item&&item.dayHours||''),String(item&&item.visitorHours||'')];
    const description=String(item&&item.description||'').replace(/<[^>]*>/g,' ').replace(/&(?:nbsp|#160);/gi,' ');
    const heading=description.search(/Öffnungszeiten|Besuchszeiten/i);
    if(heading>=0)texts.push(description.slice(heading,heading+320));
    const codes=['MO','DI','MI','DO','FR','SA','SO'];
    for(const original of texts){
      const text=original.replace(/[–—−]/g,'-').replace(/\s+/g,' ').trim();
      if(!text)continue;
      // Free admission / free access alone is not proof of 24-hour access.
      if(/^(?:24\s*\/\s*7|täglich\s+rund\s+um\s+die\s+uhr)\s*$/i.test(text)||
        /(?:jederzeit|rund\s+um\s+die\s+uhr|24\s*\/\s*7).{0,55}(?:frei\s+zugänglich|öffentlich\s+zugänglich)/i.test(text)||
        /(?:frei\s+zugänglich|öffentlich\s+zugänglich).{0,55}(?:jederzeit|rund\s+um\s+die\s+uhr|24\s*\/\s*7)/i.test(text))
        return {state:'confirmed',openNow:true,availableToday:true,until:'',access:'24h'};
      const re=/(?:^|[^A-ZÄÖÜ])(MO|DI|MI|DO|FR|SA|SO)(?:\s*-\s*(MO|DI|MI|DO|FR|SA|SO))?\s*(?:\||:|\s)\s*(\d{1,2})(?::(\d{2}))?\s*-\s*(\d{1,2})(?::(\d{2}))?\s*(?:Uhr)?/gi;
      const windows=[];
      let m,valid=0;
      while((m=re.exec(text))){
        const a=codes.indexOf(m[1].toUpperCase()),b=m[2]?codes.indexOf(m[2].toUpperCase()):a;
        const from=Number(m[3])*60+Number(m[4]||0),to=Number(m[5])*60+Number(m[6]||0);
        if(a<0||b<0||from>=to||to>1440||Number(m[4]||0)>59||Number(m[6]||0)>59)continue;
        valid++;
        for(let d=a,guard=0;guard<7;guard++){
          if(codes[d]===day)windows.push({from,to});
          if(d===b)break;
          d=(d+1)%7;
        }
      }
      if(!valid)continue;
      const openNow=windows.some(w=>minute>=w.from&&minute<w.to);
      const remaining=windows.filter(w=>minute<w.to).sort((a,b)=>a.to-b.to);
      const until=remaining.length?String(Math.floor(remaining[0].to/60)).padStart(2,'0')+':'+String(remaining[0].to%60).padStart(2,'0'):'';
      return {state:remaining.length?'confirmed':'closed',openNow,availableToday:!!remaining.length,until,access:'regular'};
    }
    return {state:'unknown',openNow:false,availableToday:false,until:'',access:''};
  }

  function homeEventMatchesTime(item,windowMode,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    const end=item&&item.end instanceof Date?item.end:(item&&item.end?new Date(item.end):null);
    if(isNaN(start.getTime()))return false;
    const st=start.getTime(),nt=now.getTime();
    const en=end instanceof Date&&!isNaN(end.getTime())?end.getTime():NaN;
    const nextDay=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1).getTime();
    const dayAfter=new Date(now.getFullYear(),now.getMonth(),now.getDate()+2).getTime();
    const spans=eventIsLongRunning(item);
    const hasEnd=Number.isFinite(en)&&en>=st;
    if(windowMode==='now'){
      const concrete=!spans&&st>=nt-5*60000&&st<=nt+30*60000&&(!hasEnd||en>nt);
      const access=spans?homeEventDayAccess(item,now):null;
      const longActive=spans&&st<=nt&&hasEnd&&en>nt&&(!access||access.state==='unknown'||access.openNow);
      return concrete||longActive;
    }
    if(windowMode==='today'){
      const futureConcrete=!spans&&st>nt&&st<nextDay;
      const access=spans?homeEventDayAccess(item,now):null;
      const longVisit=spans&&st<nextDay&&hasEnd&&en>nt&&(!access||access.state==='unknown'||access.availableToday);
      return futureConcrete||longVisit;
    }
    if(windowMode==='tomorrow'){
      const tomorrowConcrete=!spans&&st>=nextDay&&st<dayAfter;
      const overnight=!spans&&st<nextDay&&hasEnd&&en>nextDay;
      const longVisit=spans&&st<dayAfter&&hasEnd&&en>nextDay;
      return tomorrowConcrete||overnight||longVisit;
    }
    return false;
  }

  function homeEventTimeHint(item,windowMode,nowDate){
    if(!homeEventMatchesTime(item,windowMode,nowDate))return '';
    const now=nowDate instanceof Date?nowDate:new Date();
    const start=item.start instanceof Date?item.start:new Date(item.start);
    const hhmm=d=>String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
    if(eventIsLongRunning(item)){
      if(windowMode==='tomorrow')return 'Morgen besuchbar · Zeiten prüfen';
      const access=homeEventDayAccess(item,now);
      if(access.state==='confirmed')return access.access==='24h'?'Laut Angaben jederzeit zugänglich':
        (windowMode==='now'?'Reguläre Besuchszeit':'Heute noch Besuchszeit')+(access.until?' · bis '+access.until:'');
      return 'Laufende Veranstaltung · Öffnungszeiten unbekannt';
    }
    if(windowMode==='tomorrow'&&start.getTime()<new Date(now.getFullYear(),now.getMonth(),now.getDate()+1).getTime())return 'Läuft bis morgen';
    if(windowMode==='now')return start<=now?'Gerade gestartet':'Beginnt in '+Math.ceil((start.getTime()-now.getTime())/60000)+' Min.';
    if(item.allDay)return windowMode==='tomorrow'?'Morgen · ganztägig':'Heute · ganztägig';
    return (windowMode==='tomorrow'?'Morgen ':'Heute ')+hhmm(start);
  }

  // Recreate only source-proven today/tomorrow occurrences.  Preserve the
  // canonical event identity, rights/media and details of the series owner.
  // No daily fan-out of any later date (no duplicate multi-day result flood).
  function eventNearTermCards(items,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    const after=new Date(now.getFullYear(),now.getMonth(),now.getDate()+2);
    const result=[];
    items.forEach(item=>{
      const series=item&&item.series||{};
      const near=Array.isArray(series.nearTerm)?series.nearTerm:[];
      const unique=new Set(),selected=[];
      near.forEach(occ=>{
        const st=new Date(occ&&occ.start||'');
        const en=occ&&occ.end?new Date(occ.end):null;
        if(isNaN(st.getTime())||st>=after)return;
        if(st<today&&(!en||isNaN(en.getTime())||en<=today))return;
        if(en instanceof Date&&!isNaN(en.getTime())&&en.getTime()<now.getTime()-3600000)return;
        const key=st.toISOString()+'|'+(en&&!isNaN(en.getTime())?en.toISOString():'');
        if(unique.has(key))return;unique.add(key);
        selected.push({start:st,end:en&&!isNaN(en.getTime())?en:null,key,
          eventId:Number(occ.eventId)||0,canonicalUrl:String(occ.canonicalUrl||'')});
      });
      const later=series.laterSeries;
      const laterStart=new Date(later&&later.start||'');
      const hasLater=!isNaN(laterStart.getTime())&&laterStart>=after;
      const laterEnd=later&&later.end?new Date(later.end):null;
      const cloneFor=(source,properties)=>{
        const eventId=Number(source&&source.eventId)||0;
        const canonicalUrl=String(source&&source.canonicalUrl||'').trim();
        const raw=item.raw&&typeof item.raw==='object'?item.raw:{};
        const originalDb=raw.rpg_event_db&&typeof raw.rpg_event_db==='object'?raw.rpg_event_db:{};
        return Object.assign({},item,properties,canonicalUrl?{canonicalUrl}:{},
          eventId?{raw:Object.assign({},raw,{rpg_event_db:Object.assign({},originalDb,{eventId})})}:{});
      };
      const laterItem=()=>cloneFor(later,{start:laterStart,
        end:laterEnd&&!isNaN(laterEnd.getTime())?laterEnd:null,
        _rpgCollapsedFutureSeries:true,
        _rpgNearTermKey:String(item.id)+'@future-series'});
      if(!selected.length){result.push(hasLater?laterItem():item);return;}
      selected.forEach(occ=>result.push(cloneFor(occ,{start:occ.start,end:occ.end,
        _rpgNearTermKey:String(item.id)+'@'+occ.key})));
      // Keep one collapsed future-series card after tomorrow. The full catalog
      // must remain reachable without one card for every distant day.
      if(hasLater)result.push(laterItem());
    });
    return result;
  }

  // V332: In the handoff time tiers, exact coordinates keep exact precedence.
  // Only source-verified city-scoped events without a point coordinate receive
  // an INTERNAL proximity proxy: median of already-geocoded event distances
  // in that same explicitly selected city. This is not an event's real km,
  // is never displayed, and does not form city groups or change radius rules.
  // If there are no reliable same-city samples, these events remain unsorted
  // by geography (Infinity), as in v331; do not invent a point/centroid.
  const HOME_EVENT_PRIORITY_KEY='rpg-home-events-priority-v1';
  function eventIsLongRunning(item){
    if(item&&item.allDay)return true;
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    const end=item&&item.end instanceof Date?item.end:new Date(item&&item.end||0);
    return !isNaN(start.getTime())&&!isNaN(end.getTime())&&end.getTime()-start.getTime()>=20*3600000;
  }
  function eventPriorityCompare(items,mode,location,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const todayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
    const cityKey=value=>String(value||'').normalize('NFKC').trim().toLocaleLowerCase('de');
    const selectedCity=cityKey(location&&location.city);
    const localSamples=selectedCity?(Array.isArray(items)?items:[])
      .filter(x=>cityKey(x&&x.city)===selectedCity&&Number.isFinite(x&&x.distanceKm)&&x.distanceKm>=0)
      .map(x=>x.distanceKm).sort((a,b)=>a-b):[];
    // Use only real existing coordinates as evidence for a sort-only local
    // proxy. It is not a geocode, real event distance, or a displayed km.
    const mid=Math.floor(localSamples.length/2);
    const localProxy=localSamples.length
      ?(localSamples.length%2?localSamples[mid]:(localSamples[mid-1]+localSamples[mid])/2)
      :Infinity;
    const distance=x=>{
      if(x&&Number.isFinite(x.distanceKm)&&x.distanceKm>=0)return x.distanceKm;
      if(x&&x.cityScope===true&&selectedCity&&cityKey(x.city)===selectedCity)return localProxy;
      return Infinity;
    };
    const startTime=x=>{
      const d=x&&x.start instanceof Date?x.start:new Date(x&&x.start||0);
      return isNaN(d.getTime())?Infinity:d.getTime();
    };
    const calendarDay=x=>{
      const d=x&&x.start instanceof Date?x.start:new Date(x&&x.start||0);
      if(isNaN(d.getTime()))return Infinity;
      // An already-running multi-day event has no new occurrence on its
      // original start date: place it in today's remaining catalogue, not in
      // a historical day. This affects only the priority-enabled view.
      const day=new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime();
      return eventIsLongRunning(x)&&day<todayStart?todayStart:day;
    };
    const rankCache=new WeakMap();
    const group=x=>{
      if(rankCache.has(x))return rankCache.get(x);
      const match=homeEventMatchesTime(x,mode,now);
      let rank=2;
      if(match){
        if(!eventIsLongRunning(x))rank=0;
        else rank=(mode==='now'||mode==='today')&&homeEventDayAccess(x,now).state==='unknown'?1.5:1;
      }
      rankCache.set(x,rank);
      return rank;
    };
    return (a,b)=>{
      const ga=group(a),gb=group(b);
      if(ga!==gb)return ga-gb;
      // The selected Home window has already been grouped above. Only the
      // remaining catalogue uses day-first sorting, then exact proximity.
      if(ga===2){
        const ad=calendarDay(a),bd=calendarDay(b);
        if(ad!==bd)return ad-bd;
      }
      const ad=distance(a),bd=distance(b);
      if(ad!==bd)return ad-bd;
      const at=startTime(a),bt=startTime(b);
      if(at!==bt)return at-bt;
      const ai=String(a&&a._rpgNearTermKey||a&&a.id||'');
      const bi=String(b&&b._rpgNearTermKey||b&&b.id||'');
      if(ai!==bi)return ai.localeCompare(bi,'de');
      return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
    };
  }
  function storeHomeEventPriority(mode,location,radius){
    if(!['now','today','tomorrow'].includes(mode))return;
    try{
      window.sessionStorage.setItem(HOME_EVENT_PRIORITY_KEY,JSON.stringify({mode,at:Date.now(),lat:location&&location.lat,lng:location&&location.lng,radius}));
    }catch(_){}
  }
  function consumeHomeEventPriority(location,radius){
    try{
      const raw=window.sessionStorage.getItem(HOME_EVENT_PRIORITY_KEY);
      window.sessionStorage.removeItem(HOME_EVENT_PRIORITY_KEY);
      const d=JSON.parse(raw||'null');
      if(!d||!['now','today','tomorrow'].includes(d.mode)||Date.now()-d.at>300000||Date.now()<d.at)return '';
      if(Number(d.radius)!==Number(radius))return '';
      if(location&&Number.isFinite(Number(d.lat))&&Number.isFinite(Number(d.lng))&&
        (Math.abs(Number(d.lat)-Number(location.lat))>0.001||Math.abs(Number(d.lng)-Number(location.lng))>0.001))return '';
      return d.mode;
    }catch(_){return '';}
  }

  function eventUrgencyCompare(a,b){
    const now=Date.now();
    const dayKey=d=>{const x=d instanceof Date?d:new Date(d||0);return isNaN(x)?'':x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0');};
    const today=dayKey(new Date(now));
    const rank=item=>{
      const startValue=item&&item.start;
      const endValue=item&&item.end;
      const start=startValue instanceof Date?startValue:(startValue?new Date(startValue):null);
      const end=endValue instanceof Date?endValue:(endValue?new Date(endValue):null);
      const st=!start||isNaN(start)?Number.POSITIVE_INFINITY:start.getTime();
      const et=!end||isNaN(end)?Number.NaN:end.getTime();
      const startDay=dayKey(start);
      const endDay=dayKey(end);
      const running=st<=now&&(!Number.isFinite(et)||et>=now);
      const multiDay=Boolean(startDay&&endDay&&startDay!==endDay);

      // V296: today's concrete appointments must not disappear behind exhibitions,
      // fairs or other long-running events that merely remain active today.
      // Keep the established radius boundary and date-first principle; only split
      // the former "running" bucket into current same-day appointments and true
      // multi-day/older running events.
      if(running&&!multiDay&&startDay===today)return {bucket:0,time:st};
      if(st>now&&startDay===today)return {bucket:1,time:st};
      if(running)return {bucket:2,time:Number.isFinite(et)?et:st};
      return {bucket:3,time:st};
    };
    const ar=rank(a),br=rank(b);
    if(ar.bucket!==br.bucket)return ar.bucket-br.bucket;
    if(ar.time!==br.time)return ar.time-br.time;
    const ad=Number.isFinite(a&&a.distanceKm)?a.distanceKm:Number.POSITIVE_INFINITY;
    const bd=Number.isFinite(b&&b.distanceKm)?b.distanceKm:Number.POSITIVE_INFINITY;
    if(ad!==bd)return ad-bd;
    return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
  }

  function halloweenTargetDate(now){
    const d=now instanceof Date?now:new Date();
    const thisYear=new Date(d.getFullYear(),9,31,0,0,0,0);
    const endThisYear=new Date(d.getFullYear(),10,1,23,59,59,999);
    return d<=endThisYear?thisYear:new Date(d.getFullYear()+1,9,31,0,0,0,0);
  }
  function halloweenCountdown(now){
    const d=now instanceof Date?now:new Date();
    const target=halloweenTargetDate(d);
    if(d.getFullYear()===target.getFullYear()&&d.getMonth()===9&&d.getDate()===31)return 'Heute ist Halloween 🎃';
    const today=new Date(d.getFullYear(),d.getMonth(),d.getDate());
    const days=Math.max(0,Math.ceil((target.getTime()-today.getTime())/86400000));
    return 'Noch '+days+' Tag'+(days===1?'':'e')+' bis Halloween';
  }
  function halloweenSeasonActive(now){
    const d=now instanceof Date?now:new Date();
    const start=new Date(d.getFullYear(),8,15,0,0,0,0);
    const end=new Date(d.getFullYear(),10,1,23,59,59,999);
    return d>=start&&d<=end;
  }
  function halloweenFold(value){
    return String(value==null?'':value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('de').replace(/ß/g,'ss');
  }
  function halloweenFieldText(value){
    if(typeof value==='string'||typeof value==='number')return String(value);
    if(Array.isArray(value))return value.map(halloweenFieldText).filter(Boolean).join(' ');
    if(value&&typeof value==='object'){
      return ['name','title','label','value'].map(key=>halloweenFieldText(value[key])).filter(Boolean).join(' ');
    }
    return '';
  }
  function halloweenEventText(item){
    const raw=item&&item.raw&&typeof item.raw==='object'?item.raw:{};
    const fields=[item&&item.title,item&&item.eventType,item&&item.description,item&&item.shortDescription];
    ['keywords','categories','category','tags','type','name','description','shortDescription','teaser'].forEach(key=>{
      const value=halloweenFieldText(raw[key]);
      if(value)fields.push(value);
    });
    // V279: deliberately no JSON-wide raw fallback. That fallback made unrelated
    // provider/meta text eligible for the seasonal special. Only visitor-facing
    // event text and explicit taxonomy fields may qualify an event now.
    return halloweenFold(fields.filter(Boolean).join(' '));
  }
  function halloweenEventDateInWindow(item){
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    if(isNaN(start.getTime()))return false;
    const target=halloweenTargetDate(new Date());
    const year=target.getFullYear();
    const from=new Date(year,8,15,0,0,0,0);
    const through=new Date(year,10,1,23,59,59,999);
    return start>=from&&start<=through;
  }
  function halloweenExplicitSignal(text){
    const value=halloweenFold(text);
    return /\bhalloween\b|\bhallowe'en\b|\bhorror[a-z]*\b|\bgrusel[a-z]*\b|\bspuk[a-z]*\b|\bgeister[a-z]*\b|\bgespenst[a-z]*\b|\bzombie[a-z]*\b|\bvampir[a-z]*\b|\bdracula\b|\bfrankenstein\b|\bnosferatu\b|\bparanormal\b|\bhaunted\b|\bghost(?:s)?\b|\bdamon[a-z]*\b|\bhexennacht\b|\brocky\s+horror\b|\btrick\s*(?:or|oder|&)\s*treat\b|\bsuss(?:es)?\s+oder\s+saures\b|\bkurbis(?:fest|schnitz[a-z]*|leucht[a-z]*|nacht|markt)\b/.test(value);
  }
  function halloweenEventKind(item){
    const text=halloweenEventText(item);
    if(/\bfamil[a-z]*\b|\bkinder[a-z]*\b|\bkindertheater\b|\bkids\b|\bkurbis[a-z]*\b|\btrick\s*(?:or|oder|&)\s*treat\b|\bsuss(?:es)?\s+oder\s+saures\b/.test(text))return 'family';
    if(/\bparty\b|\bclub\b|\bdj\b|\bdisco\b|\btanz[a-z]*\b|\bnachtparty\b|\baftershow\b/.test(text))return 'party';
    if(/\bhorror[a-z]*\b|\bgrusel[a-z]*\b|\bspuk[a-z]*\b|\bgeister[a-z]*\b|\bgespenst[a-z]*\b|\bzombie[a-z]*\b|\bvampir[a-z]*\b|\bdracula\b|\bfrankenstein\b|\bnosferatu\b|\bparanormal\b|\bhaunted\b|\bghost(?:s)?\b|\bdamon[a-z]*\b|\brocky\s+horror\b/.test(text))return 'horror';
    return 'special';
  }
  function isHalloweenEvent(item){
    if(!halloweenEventDateInWindow(item))return false;
    return halloweenExplicitSignal(halloweenEventText(item));
  }
  function halloweenSeriesText(value){
    return halloweenFold(value).replace(/[^a-z0-9]+/g,'').trim();
  }
  function halloweenSeriesTitleKey(value){
    return halloweenFold(value)
      .replace(/\b20\d{2}\b/g,' ')
      .replace(/\b\d{1,2}[.\/-]\d{1,2}(?:[.\/-]\d{2,4})?\b/g,' ')
      .replace(/[^a-z0-9]+/g,' ')
      .replace(/\b(?:am|im|in|der|die|das|von|vom|zum|zur)\b/g,' ')
      .replace(/\s+/g,' ').trim();
  }
  function halloweenSeriesTokens(value){
    return halloweenSeriesTitleKey(value).split(' ').filter(token=>token.length>=3);
  }
  function halloweenVenueKey(item){
    return halloweenSeriesText((item&&item.subtitle)||(item&&item.address)||'');
  }
  function halloweenStartsNear(a,b){
    const at=a&&a.start instanceof Date?a.start.getTime():NaN;
    const bt=b&&b.start instanceof Date?b.start.getTime():NaN;
    return Number.isFinite(at)&&Number.isFinite(bt)&&Math.abs(at-bt)<=45*60*1000;
  }
  function halloweenOrganizerKey(item){
    const list=item&&Array.isArray(item.organizers)?item.organizers:[];
    return halloweenSeriesText(list.map(x=>typeof x==='string'?x:(x&&x.name)||'').filter(Boolean).join(' '));
  }
  function halloweenSameSeries(a,b){
    const ai=halloweenSeriesText(a&&a.series&&a.series.identity);
    const bi=halloweenSeriesText(b&&b.series&&b.series.identity);
    if(ai&&bi&&ai===bi)return true;
    const ac=halloweenSeriesText(a&&a.city),bc=halloweenSeriesText(b&&b.city);
    if(ac!==bc)return false;
    const at=halloweenSeriesText(a&&a.title),bt=halloweenSeriesText(b&&b.title);
    const av=halloweenVenueKey(a),bv=halloweenVenueKey(b);
    const sameVenue=!!(av&&bv&&(av===bv||((av.length>=8&&bv.length>=8)&&(av.includes(bv)||bv.includes(av)))));
    if(at===bt){
      if(sameVenue)return true;
      const ao=halloweenOrganizerKey(a),bo=halloweenOrganizerKey(b);
      return !!(ao&&bo&&ao===bo);
    }
    // V299: cross-source Halloween duplicates often differ only by a year suffix
    // or a venue word (e.g. "Halloween Horror Festival" vs "... 2026",
    // or editorial "Halloween-Party am 31.10.2026" vs provider title).
    // Collapse only when the venue is the same; near-identical title keys may be
    // recurring dates, while looser token overlap additionally requires the same
    // start time (±45 min) to avoid merging distinct parties at one location.
    if(sameVenue){
      const ak=halloweenSeriesTitleKey(a&&a.title),bk=halloweenSeriesTitleKey(b&&b.title);
      if(ak&&bk&&ak===bk)return true;
      if(halloweenStartsNear(a,b)){
        const aset=new Set(halloweenSeriesTokens(a&&a.title));
        const shared=halloweenSeriesTokens(b&&b.title).filter(token=>aset.has(token));
        if(shared.length>=2&&shared.some(token=>/^(?:halloween|horror|party|festival|grusel)$/.test(token)))return true;
      }
    }
    return false;
  }
  function halloweenCalendarDay(item){
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    if(isNaN(start.getTime()))return Number.POSITIVE_INFINITY;
    return new Date(start.getFullYear(),start.getMonth(),start.getDate()).getTime();
  }
  function halloweenSpecialCompare(a,b){
    // V332: Halloween is an event-catalogue subset, not a countdown ranking.
    // Upcoming dates first (16.10 precedes 31.10); within a calendar date
    // use the existing exact distanceKm and then the appointment start time.
    // City names never form groups; the established Halloween relevance,
    // source, radius, fallback and dedupe rules remain unchanged.
    const aday=halloweenCalendarDay(a),bday=halloweenCalendarDay(b);
    if(aday!==bday)return aday-bday;
    const ax=Number.isFinite(a&&a.distanceKm)&&a.distanceKm>=0?a.distanceKm:Number.POSITIVE_INFINITY;
    const bx=Number.isFinite(b&&b.distanceKm)&&b.distanceKm>=0?b.distanceKm:Number.POSITIVE_INFINITY;
    if(ax!==bx)return ax-bx;
    const at=a&&a.start instanceof Date?a.start.getTime():Number.POSITIVE_INFINITY;
    const bt=b&&b.start instanceof Date?b.start.getTime():Number.POSITIVE_INFINITY;
    if(at!==bt)return at-bt;
    const ai=String(a&&a.id||''),bi=String(b&&b.id||'');
    if(ai!==bi)return ai.localeCompare(bi,'de');
    return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
  }
  function dedupeHalloweenSeries(items){
    const sorted=(Array.isArray(items)?items:[]).slice().sort(halloweenSpecialCompare);
    const out=[];
    for(const item of sorted){
      if(out.some(existing=>halloweenSameSeries(existing,item)))continue;
      out.push(item);
    }
    return out;
  }
  const CHRISTMAS_CATEGORIES=[
    ['weihnachtsmaerkte','Weihnachtsmärkte'],
    ['kinder-familie','Kinder & Familie'],
    ['konzerte-musik','Konzerte & Musik'],
    ['advent-mitmachen','Advent & Mitmachen'],
    ['theater-shows','Theater & Shows'],
    ['lichter-ausfluege','Lichter & Ausflüge']
  ];
  function christmasFold(value){
    return String(value||'').toLowerCase().replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss')
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
  }
  function christmasDate(item){
    const value=item&&item.start;
    const d=value instanceof Date?value:new Date(value||0);
    return Number.isFinite(d.getTime())?d:null;
  }
  function christmasSeasonYear(now){
    const d=now instanceof Date?now:new Date(now||Date.now());
    return d.getMonth()===0?d.getFullYear()-1:d.getFullYear();
  }
  function christmasSeasonEvent(item,now){
    const start=christmasDate(item);
    if(!start)return false;
    const year=christmasSeasonYear(now||new Date());
    return start>=new Date(year,10,1)&&start<=new Date(year+1,0,6,23,59,59,999);
  }
  function christmasCategories(item,now){
    if(!christmasSeasonEvent(item,now))return [];
    const raw=item&&item.raw&&typeof item.raw==='object'?item.raw:{};
    const title=christmasFold(item&&item.title);
    const taxonomy=christmasFold([raw.keywords,raw.tags,raw.categories,raw.category,item&&item.eventType]
      .filter(x=>typeof x==='string').join(' '));
    const description=christmasFold([item&&item.description,item&&item.shortDescription]
      .filter(x=>typeof x==='string').join(' '));
    const text=title+' '+taxonomy+' '+description;
    const seasonal=/\b(weihnacht[a-z]*|advent[a-z]*|nikolaus[a-z]*|christkind[a-z]*|christmas|xmas|winterleuchten|winterzauber)\b/;
    if(!seasonal.test(text))return [];
    const result=[];
    const market=/\b(weihnachtsmarkt|weihnachtsmaerkte|adventsmarkt|adventsmaerkte|christkindlmarkt|christkindlesmarkt|nikolausmarkt|weihnachtsdorf)\b/;
    const otherEventTitle=/\b(?:konzert|musik|chor|theater|musical|show|lesung|workshop|basteln|backen|(?:weihnachts|advents)(?:konzert|musik|theater|musical|show|maerchen))\b/;
    // Market evidence must describe the event, not merely its venue.
    if((market.test(title)&&!otherEventTitle.test(title))||(!otherEventTitle.test(title)&&market.test(taxonomy)))result.push('weihnachtsmaerkte');
    if(/\b(kinder|familie|familien|kids|nikolausbesuch|weihnachtsmannbesuch)\b/.test(title+' '+taxonomy)
       ||/\b(familienweihnacht|kinderweihnacht|familienadvent|nikolausfeier)\b/.test(text))result.push('kinder-familie');
    if(/\b(konzert|chor|musik|oratorium|kantate|carols|weihnachtslieder)\b/.test(title+' '+taxonomy)
       ||/\b(weihnachtskonzert|adventskonzert|weihnachtsoratorium|weihnachtsmusik)\b/.test(text))result.push('konzerte-musik');
    if(/\b(workshop|basteln|backen|mitmachen|werkstatt|adventskranz|kreativ)\b/.test(title+' '+taxonomy)
       ||/\b(adventswerkstatt|weihnachtswerkstatt|weihnachtsbasteln|weihnachtsbacken)\b/.test(text))result.push('advent-mitmachen');
    // A market's generic ET4 taxonomy (e.g. 'Bühne' or 'Theater') is not evidence
    // for an actual performance. Only the event title may opt a market into shows.
    const hasMarketIdentity=market.test(title);
    const theaterTitle=/\b(theater|maerchen|musical|show|nussknacker|buehne|ballett|theaterauffuehrung|weihnachtsmaerchen|weihnachtsshow|weihnachtstheater)\b/.test(title);
    const theaterTaxonomy=/\b(theater|maerchen|musical|show|nussknacker|buehne|ballett)\b/.test(taxonomy);
    if(theaterTitle||(!hasMarketIdentity&&theaterTaxonomy))result.push('theater-shows');
    if(/\b(lichter|lichterwelt|lichterpark|lichterglanz|illumination|winterleuchten|christmas garden)\b/.test(title+' '+taxonomy))result.push('lichter-ausfluege');
    return result;
  }

window.rpgSpecialListing=function(raw,location,radius,mode){const home=false,eventWindow="";
            let items=raw.map(x=>RPG.normalizeEvent(x,location)).filter(x=>{
              if(!x.start)return false;
              if(!x.end||x.end.getTime()>=Date.now()-3600000)return true;
              const series=x.series||{};
              const near=Array.isArray(series.nearTerm)?series.nearTerm:[];
              return near.some(o=>new Date(o&&o.end||o&&o.start||0).getTime()>=Date.now()-3600000)
                ||new Date(series.laterSeries&&series.laterSeries.start||0).getTime()>Date.now();
            });
            // V315: official city-scoped municipal events have deliberately no fake
            // point coordinate. The backend only returns them for their selected
            // city, so they remain eligible without displaying a made-up distance.
            items=items.filter(x=>Number.isFinite(x.distanceKm)||x.cityScope===true);
            items=RPG.dedupeEventsForListing(items);
            if(mode!=='halloween'&&mode!=='weihnachten')items=eventNearTermCards(items,new Date());
            // V296: radius remains the eligibility boundary. Within that radius,
            // current/later-today appointments come before long-running events;
            // long-running events still remain ahead of tomorrow/later dates.
            // Distance remains only the tie-breaker inside the same urgency/time tier.
            // V329: selected Home time or one-shot Home→Events priority controls
            // presentation order only. The full category remains available.
            const priorityEventView=eventWindow&&['now','today','tomorrow'].includes(eventWindow);
            items.sort(priorityEventView?eventPriorityCompare(items,eventWindow,location,new Date()):eventUrgencyCompare);
            // Event eligibility never depends on the image source. Original ET4/ODF
            // artwork, approved symbolic/context images and events without an image all
            // remain in the same listing pool; cards fall back to the standard ticket
            // placeholder when no image can be resolved.
            let effective=radius, visible=items.filter(x=>x.cityScope===true||x.distanceKm<=radius);
            // V299: seasonal specials must filter from the complete radius-eligible
            // event pool before presentation limits (the full category now paginates).
            // Otherwise late-October Halloween events disappear behind hundreds of
            // earlier September/October events even though they are in the database.
            if(mode==='halloween') visible=visible.filter(isHalloweenEvent);
            if(mode==='weihnachten') visible=visible.filter(x=>christmasCategories(x).length>0);
            if(home&&visible.length<4&&radius<10){effective=10;visible=items.filter(x=>x.cityScope===true||x.distanceKm<=10);}
            // Rank the final radius-admitted pool, never farther-away candidates.
            if(!home&&priorityEventView)visible.sort(eventPriorityCompare(visible,eventWindow,location,new Date()));
            // Only the Home Event card shortlist gains a time selection.
            if(home&&eventWindow){
              const now=new Date();
              visible=visible.filter(x=>homeEventMatchesTime(x,eventWindow,now));
              visible.sort(eventPriorityCompare(visible,eventWindow,location,now));
            }
            visible=home?visible.slice(0,4):visible;
            const baseItems=visible.slice();
            const mediaHead=home?baseItems:baseItems.slice(0,300);
            const mediaTail=home?[]:baseItems.slice(300);
            let localItems=baseItems;
            if(typeof RPG.diversifyEventMediaLocal==='function')localItems=RPG.diversifyEventMediaLocal(mediaHead).concat(mediaTail);

return {items:localItems,baseItems,effectiveRadius:effective};};
window.rpgRouteItem=function(x,location){if(x.element){
        const normalized=RPG.normalizePlace(x.element,'highlights',location);
        const apiDistance=Number(x.distanceKm);
        if(Number.isFinite(apiDistance)) normalized.distanceKm=apiDistance;
        if(x.fallbackImage&&(x.forceFallbackImage||!normalized.imageUrl)){
          normalized.imageUrl=String(x.fallbackImage);
          const fallbackGallery=[{url:String(x.fallbackImage),credit:String(x.fallbackCredit||''),source:'Wikimedia Commons',license:String(x.fallbackLicense||'')}];
          normalized.galleryImages=x.forceFallbackImage?fallbackGallery:fallbackGallery.concat(Array.isArray(normalized.galleryImages)?normalized.galleryImages.filter(g=>g&&g.url!==String(x.fallbackImage)):[]);
        }
        Object.assign(normalized,{title:x.title,subtitle:'',city:x.city,routeIndustrial:true,routeType:x.type,routeTitle:x.title,routeBadge:x.typeLabel||'Primärstandort',routeOfficialUrl:String(x.officialUrl||'')});

if(x.distanceKm==null)normalized.distanceKm=RPG.normalizePlace(x.element,'highlights',location).distanceKm;normalized._rpgNearTermKey="route:"+x.slug;normalized._nativeRoute=x;return normalized;}const item=x,image=String(x.fallbackImage||""),distance=Number(x.distanceKm),lat=Number(x.fallbackLat),lng=Number(x.fallbackLng);
    const detailItem={
      kind:'place',id:'rdi:'+item.slug,category:'highlights',title:item.title,subtitle:'',city:item.city||'',address:'',
      coords:Number.isFinite(lat)&&Number.isFinite(lng)?{lat,lng}:null,distanceKm:Number.isFinite(distance)?distance:null,
      tags:{},labels:[],description:'',website:'',menuUrl:'',reservationUrl:'',openingHours:'',phone:'',
      imageUrl:image,galleryImages:image?[{url:image,credit:String(item.fallbackCredit||''),artist:'',source:image===String(item.fallbackImage||'')?'Wikimedia Commons':'RuhrpottGuru Medienresolver',license:String(item.fallbackLicense||'')}]:[],
      routeIndustrial:true,routeType:item.type||'',routeTitle:item.title,routeBadge:item.typeLabel||'Primärstandort',routeOfficialUrl:String(item.officialUrl||'')
    };

if(x.fallbackLat==null||x.fallbackLng==null)detailItem.coords=null;if(x.distanceKm==null)detailItem.distanceKm=null;detailItem._rpgNearTermKey="route:"+x.slug;detailItem._nativeRoute=x;return detailItem;};
window.rpgSpecialQuery=function(items,mode,filter,city){
 if(mode==='route'){
  const cities=Array.from(new Set(items.map(x=>x.city).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'de'));
  const filters=[['all','Alle'],['anchor','Ankerpunkte'],['panorama','Panoramen'],['settlement','Siedlungen']];
  return {items:items.filter(x=>(filter==='all'||x.routeType===filter)&&(!city||x.city===city)),filters:filters.map(([key,label])=>({key,label,count:items.filter(x=>key==='all'||x.routeType===key).length})),cities,count:items.length,kicker:'Offizielle Primärstandorte im Ruhrgebiet'};
 }
 if(mode==='halloween'){
  const matches=dedupeHalloweenSeries(items.filter(isHalloweenEvent)).map(item=>Object.assign({},item,{halloweenKind:halloweenEventKind(item)}));
  const filters=[['all','Alle'],['family','Familie'],['party','Party & Nacht'],['horror','Grusel & Horror']];
  return {items:filter==='all'?matches:matches.filter(item=>item.halloweenKind===filter),filters:filters.map(([key,label])=>({key,label,count:matches.filter(x=>key==='all'||x.halloweenKind===key).length})),cities:[],count:matches.length,kicker:halloweenCountdown(new Date())};
 }
 const matches=items.map(item=>({item,categories:christmasCategories(item)})).filter(x=>x.categories.length);
 return {items:matches.filter(x=>x.categories.includes(filter)).map(x=>x.item),filters:CHRISTMAS_CATEGORIES.map(([key,label])=>({key,label,count:matches.filter(x=>x.categories.includes(key)).length})),cities:[],count:matches.length,kicker:'Advent & Weihnachten im Ruhrgebiet'};
};
window.rpgSpecialDefault=mode=>mode==='weihnachten'?'weihnachtsmaerkte':'all';
window.rpgSpecialQA={isHalloweenEvent,halloweenEventKind,dedupeHalloweenSeries,halloweenSpecialCompare,christmasCategories,christmasSeasonYear};
})();
