(function(){const R=window.RPGReact;
  function normalizeKey(value){
    return String(value||'').trim().toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/ß/g,'ss').replace(/[^a-z0-9]+/g,'');
  }

  var shareYears=[
    '1934','1952','1990','2024','2009','1982','1970','1955','1980','1969','current','1926'
  ];
window.rpgTimeShare=function(state){const currentYear=state.year,map={getCenter:()=>({lat:state.lat,lng:state.lng}),getZoom:()=>state.zoom},marker={getLatLng:()=>({lat:state.markerLat,lng:state.markerLng})};
    function encodeShareToken(){
      var center=map.getCenter();
      var markerPoint=marker.getLatLng();
      var yi=Math.max(0,shareYears.indexOf(currentYear));
      var buf=new ArrayBuffer(18);
      var view=new DataView(buf);

      view.setInt32(0,Math.round(Number(center.lat)*100000),false);
      view.setInt32(4,Math.round(Number(center.lng)*100000),false);
      view.setInt32(8,Math.round(Number(markerPoint.lat)*100000),false);
      view.setInt32(12,Math.round(Number(markerPoint.lng)*100000),false);
      view.setUint8(16,Math.max(9,Math.min(20,Number(map.getZoom())||17)));
      view.setUint8(17,yi);

      var bytes=new Uint8Array(buf),bin='';
      for(var i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);
      return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    }


return "https://www.ruhrpottguru.de/z/"+encodeShareToken()+"/";};
window.rpgTimeSearch=function(input){let result={kind:"message",status:""};const inputs={street:{value:input.street||""},number:{value:input.number||""},zip:{value:input.zip||""},city:{value:input.city||""}};const form={querySelector:selector=>inputs[(selector.match(/name="([^"]+)"/)||[])[1]]||null};class FormData{get(k){return inputs[k]&&inputs[k].value;}};const e={preventDefault:()=>{}},setStatus=msg=>{result.status=msg||"";},moveTo=(lat,lng,label)=>{result.kind="move";result.lat=lat;result.lng=lng;result.label=label;};const window={RPGReact:{...R,settings:{...R.settings,addressLocationToken:"native-transport"},api:{...R.api,post:(url,body)=>{result.kind="postcode";result.url=url;result.body=body;return new Promise(()=>{});}}}};const fetch=(url,options)=>{result.kind="address";result.url=url;result.body=JSON.parse(options.body);return new Promise(()=>{});};
    function findCityCenter(city){
      var centers=window.RPGReact&&window.RPGReact.CITY_CENTERS?window.RPGReact.CITY_CENTERS:{};
      var wanted=normalizeKey(city);
      var hit=Object.keys(centers).find(function(name){return normalizeKey(name)===wanted;});
      if(!hit)return null;
      var pair=centers[hit];
      if(!pair)return null;
      return {city:hit,lat:Number(pair[0]),lng:Number(pair[1])};
    }


(function(){

      e.preventDefault();
      var fd=new FormData(form);
      var street=String(fd.get('street')||'').trim();
      var house=String(fd.get('number')||'').trim();
      var postcode=String(fd.get('zip')||'').replace(/\s+/g,'').trim();
      var city=String(fd.get('city')||'').trim();

      /*
       * Tolerante Eingabe: Wenn versehentlich eine 5-stellige PLZ
       * im Feld "Ort" steht und das PLZ-Feld leer ist, behandeln wir
       * sie als PLZ. Das veraendert nur die lokale Zeitreise-Suche.
       */
      if(!postcode && /^\d{5}$/.test(city)){
        postcode=city;
        city='';

        var zipInput=form.querySelector('[name="zip"]');
        var cityInput=form.querySelector('[name="city"]');

        if(zipInput)zipInput.value=postcode;
        if(cityInput)cityInput.value='';
      }

      if(!street && !postcode && !city){
        setStatus('Du kannst die Karte einfach am aktuellen Standort nutzen oder optional PLZ, Ort oder Adresse eingeben.');
        return;
      }

      if(!street && postcode && !city){
        if(!/^\d{5}$/.test(postcode)){
          setStatus('Bitte gib eine gültige 5-stellige PLZ ein.');
          return;
        }
        if(window.RPGReact&&window.RPGReact.api&&typeof window.RPGReact.api.postcodeLocation==='function'){
          setStatus('PLZ wird gesucht …');
          window.RPGReact.api.postcodeLocation(postcode)
            .then(function(data){
              if(!data||!Number.isFinite(Number(data.lat))||!Number.isFinite(Number(data.lng)))throw new Error('Für diese PLZ wurde kein Mittelpunkt gefunden.');
              moveTo(Number(data.lat),Number(data.lng),'PLZ '+postcode);
            })
            .catch(function(err){setStatus(err&&err.message?err.message:'Die PLZ konnte gerade nicht aufgelöst werden.');});
          return;
        }
      }

      if(!street && city){
        var center=findCityCenter(city);
        if(center){
          moveTo(center.lat,center.lng,center.city);
          return;
        }
        if(!postcode){
          setStatus('Diesen Ort konnte ich im RuhrpottGuru-Gebiet nicht eindeutig finden.');
          return;
        }
      }

      if(street && !postcode && !city){
        setStatus('Bitte ergänze zur Straße eine PLZ oder einen Ort.');
        return;
      }

      if(postcode&&!/^\d{5}$/.test(postcode)){
        setStatus('Bitte gib eine gültige 5-stellige PLZ ein.');
        return;
      }

      var settings=window.RPGReact&&window.RPGReact.settings?window.RPGReact.settings:{};
      var endpoint=settings.addressLocationUrl||'/wp-json/ruhrpottguru/v1/address-location';
      var token=settings.addressLocationToken||'';
      if(!token){setStatus('Die Adresssuche ist gerade nicht verfügbar. Bitte lade die Seite neu.');return;}

      setStatus(street?'Adresse wird gesucht …':'Ort wird gesucht …');
      fetch(endpoint,{
        method:'POST',
        credentials:'same-origin',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-RPG-Address-Token':token},
        body:JSON.stringify({street:street,housenumber:house,postcode:postcode,city:city})
      })
      .then(function(r){
        return r.json().then(function(data){
          if(!r.ok||!data||data.ok===false)throw new Error(data&&data.message?data.message:'Ort nicht gefunden.');
          return data;
        });
      })
      .then(function(data){
        moveTo(data.lat,data.lng,data.label||[street,house,postcode,city].filter(Boolean).join(' · '));
      })
      .catch(function(err){
        setStatus(err&&err.message?err.message:'Der gewünschte Ort konnte gerade nicht aufgelöst werden.');
      });

})();result.fields={street:inputs.street.value,number:inputs.number.value,zip:inputs.zip.value,city:inputs.city.value};return result;};})();
