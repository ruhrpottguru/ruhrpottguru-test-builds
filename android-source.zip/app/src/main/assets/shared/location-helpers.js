(function(){const RPG=window.RPGReact;
  function normalizePlaceKey(value){
    return String(value||'').trim().toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/ß/g,'ss')
      .replace(/[^a-z0-9]+/g,'');
  }
  function rpgMatchRuhrCity(value) {
    const key=normalizePlaceKey(value);
    if(!key)return '';
    const direct=Object.keys(RPG.CITY_CENTERS||{}).find(name=>normalizePlaceKey(name)===key);
    if(direct)return direct;
    const aliases={
      froendenberg:'Fröndenberg/Ruhr',froendenbergruhr:'Fröndenberg/Ruhr',
      voerde:'Voerde (Niederrhein)',voerdeniederrhein:'Voerde (Niederrhein)',
      wetter:'Wetter (Ruhr)',wetterruhr:'Wetter (Ruhr)',
      muelheimruhr:'Mülheim an der Ruhr',muelheimanderruhr:'Mülheim an der Ruhr'
    };
    return aliases[key]||'';
  }

window.rpgNativeMatchCity=rpgMatchRuhrCity;})();
