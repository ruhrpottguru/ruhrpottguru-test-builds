(function(){
const RPG=window.RPGReact;
  function sortDistance(items){
    return items.slice().sort((a,b)=>{
      const ad=Number.isFinite(a&&a.distanceKm)?a.distanceKm:Number.POSITIVE_INFINITY;
      const bd=Number.isFinite(b&&b.distanceKm)?b.distanceKm:Number.POSITIVE_INFINITY;
      if(ad!==bd)return ad-bd;
      const at=a&&a.start instanceof Date&&!isNaN(a.start)?a.start.getTime():Number.POSITIVE_INFINITY;
      const bt=b&&b.start instanceof Date&&!isNaN(b.start)?b.start.getTime():Number.POSITIVE_INFINITY;
      if(at!==bt)return at-bt;
      return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
    });
  }
window.rpgSourceSort=sortDistance;
window.rpgSourceFilter=function(items,query,tagFilter,sub){
const category="food",s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";
    const filtered=s.items.filter(x=>{
      const facet=category==='events'?x.eventType:x.subtitle;
      const textOk=!q||[x.title,x.subtitle,x.eventType,x.city,x.address].concat(Array.isArray(x.labels)?x.labels:[]).join(' ').toLowerCase().includes(q);
      const tagOk=!tagFilter||RPG.categoryFilterTags(x).some(label=>RPG.tagSlug(label)===tagFilter);
      const dateOk=category!=='events'||!dateFrom||eventOverlapsDateRange(x,dateFrom,dateTo);
      return (!sub||facet===sub)&&textOk&&tagOk&&dateOk;
    });
return filtered;
};})();
