(function(){const RPG=window.RPGReact;
  function homeEventDayAccess(item,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const dayCodes=['SO','MO','DI','MI','DO','FR','SA'];
    const day=dayCodes[now.getDay()];
    const minute=now.getHours()*60+now.getMinutes();
    const texts=[String(item&&item.dayHours||''),String(item&&item.visitorHours||'')];
    const description=String(item&&item.description||'').replace(/<[^>]*>/g,' ').replace(/&(?:nbsp|#160);/gi,' ');
    const heading=description.search(/Öffnungszeiten|Besuchszeiten/i);
    if(heading>=0)texts.push(description.slice(heading,heading+320));
    const codes=['MO','DI','MI','DO','FR','SA','SO'];
    for(const original of texts){
      const text=original.replace(/[–—−]/g,'-').replace(/\s+/g,' ').trim();
      if(!text)continue;
      // Free admission / free access alone is not proof of 24-hour access.
      if(/^(?:24\s*\/\s*7|täglich\s+rund\s+um\s+die\s+uhr)\s*$/i.test(text)||
        /(?:jederzeit|rund\s+um\s+die\s+uhr|24\s*\/\s*7).{0,55}(?:frei\s+zugänglich|öffentlich\s+zugänglich)/i.test(text)||
        /(?:frei\s+zugänglich|öffentlich\s+zugänglich).{0,55}(?:jederzeit|rund\s+um\s+die\s+uhr|24\s*\/\s*7)/i.test(text))
        return {state:'confirmed',openNow:true,availableToday:true,until:'',access:'24h'};
      const re=/(?:^|[^A-ZÄÖÜ])(MO|DI|MI|DO|FR|SA|SO)(?:\s*-\s*(MO|DI|MI|DO|FR|SA|SO))?\s*(?:\||:|\s)\s*(\d{1,2})(?::(\d{2}))?\s*-\s*(\d{1,2})(?::(\d{2}))?\s*(?:Uhr)?/gi;
      const windows=[];
      let m,valid=0;
      while((m=re.exec(text))){
        const a=codes.indexOf(m[1].toUpperCase()),b=m[2]?codes.indexOf(m[2].toUpperCase()):a;
        const from=Number(m[3])*60+Number(m[4]||0),to=Number(m[5])*60+Number(m[6]||0);
        if(a<0||b<0||from>=to||to>1440||Number(m[4]||0)>59||Number(m[6]||0)>59)continue;
        valid++;
        for(let d=a,guard=0;guard<7;guard++){
          if(codes[d]===day)windows.push({from,to});
          if(d===b)break;
          d=(d+1)%7;
        }
      }
      if(!valid)continue;
      const openNow=windows.some(w=>minute>=w.from&&minute<w.to);
      const remaining=windows.filter(w=>minute<w.to).sort((a,b)=>a.to-b.to);
      const until=remaining.length?String(Math.floor(remaining[0].to/60)).padStart(2,'0')+':'+String(remaining[0].to%60).padStart(2,'0'):'';
      return {state:remaining.length?'confirmed':'closed',openNow,availableToday:!!remaining.length,until,access:'regular'};
    }
    return {state:'unknown',openNow:false,availableToday:false,until:'',access:''};
  }

  function homeEventMatchesTime(item,windowMode,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    const end=item&&item.end instanceof Date?item.end:(item&&item.end?new Date(item.end):null);
    if(isNaN(start.getTime()))return false;
    const st=start.getTime(),nt=now.getTime();
    const en=end instanceof Date&&!isNaN(end.getTime())?end.getTime():NaN;
    const nextDay=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1).getTime();
    const dayAfter=new Date(now.getFullYear(),now.getMonth(),now.getDate()+2).getTime();
    const spans=eventIsLongRunning(item);
    const hasEnd=Number.isFinite(en)&&en>=st;
    if(windowMode==='now'){
      const concrete=!spans&&st>=nt-5*60000&&st<=nt+30*60000&&(!hasEnd||en>nt);
      const access=spans?homeEventDayAccess(item,now):null;
      const longActive=spans&&st<=nt&&hasEnd&&en>nt&&(!access||access.state==='unknown'||access.openNow);
      return concrete||longActive;
    }
    if(windowMode==='today'){
      const futureConcrete=!spans&&st>nt&&st<nextDay;
      const access=spans?homeEventDayAccess(item,now):null;
      const longVisit=spans&&st<nextDay&&hasEnd&&en>nt&&(!access||access.state==='unknown'||access.availableToday);
      return futureConcrete||longVisit;
    }
    if(windowMode==='tomorrow'){
      const tomorrowConcrete=!spans&&st>=nextDay&&st<dayAfter;
      const overnight=!spans&&st<nextDay&&hasEnd&&en>nextDay;
      const longVisit=spans&&st<dayAfter&&hasEnd&&en>nextDay;
      return tomorrowConcrete||overnight||longVisit;
    }
    return false;
  }

  function homeEventTimeHint(item,windowMode,nowDate){
    if(!homeEventMatchesTime(item,windowMode,nowDate))return '';
    const now=nowDate instanceof Date?nowDate:new Date();
    const start=item.start instanceof Date?item.start:new Date(item.start);
    const hhmm=d=>String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
    if(eventIsLongRunning(item)){
      if(windowMode==='tomorrow')return 'Morgen besuchbar · Zeiten prüfen';
      const access=homeEventDayAccess(item,now);
      if(access.state==='confirmed')return access.access==='24h'?'Laut Angaben jederzeit zugänglich':
        (windowMode==='now'?'Reguläre Besuchszeit':'Heute noch Besuchszeit')+(access.until?' · bis '+access.until:'');
      return 'Laufende Veranstaltung · Öffnungszeiten unbekannt';
    }
    if(windowMode==='tomorrow'&&start.getTime()<new Date(now.getFullYear(),now.getMonth(),now.getDate()+1).getTime())return 'Läuft bis morgen';
    if(windowMode==='now')return start<=now?'Gerade gestartet':'Beginnt in '+Math.ceil((start.getTime()-now.getTime())/60000)+' Min.';
    if(item.allDay)return windowMode==='tomorrow'?'Morgen · ganztägig':'Heute · ganztägig';
    return (windowMode==='tomorrow'?'Morgen ':'Heute ')+hhmm(start);
  }

  // Recreate only source-proven today/tomorrow occurrences.  Preserve the
  // canonical event identity, rights/media and details of the series owner.
  // No daily fan-out of any later date (no duplicate multi-day result flood).
  function eventNearTermCards(items,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const today=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    const after=new Date(now.getFullYear(),now.getMonth(),now.getDate()+2);
    const result=[];
    items.forEach(item=>{
      const series=item&&item.series||{};
      const near=Array.isArray(series.nearTerm)?series.nearTerm:[];
      const unique=new Set(),selected=[];
      near.forEach(occ=>{
        const st=new Date(occ&&occ.start||'');
        const en=occ&&occ.end?new Date(occ.end):null;
        if(isNaN(st.getTime())||st>=after)return;
        if(st<today&&(!en||isNaN(en.getTime())||en<=today))return;
        if(en instanceof Date&&!isNaN(en.getTime())&&en.getTime()<now.getTime()-3600000)return;
        const key=st.toISOString()+'|'+(en&&!isNaN(en.getTime())?en.toISOString():'');
        if(unique.has(key))return;unique.add(key);
        selected.push({start:st,end:en&&!isNaN(en.getTime())?en:null,key,
          eventId:Number(occ.eventId)||0,canonicalUrl:String(occ.canonicalUrl||'')});
      });
      const later=series.laterSeries;
      const laterStart=new Date(later&&later.start||'');
      const hasLater=!isNaN(laterStart.getTime())&&laterStart>=after;
      const laterEnd=later&&later.end?new Date(later.end):null;
      const cloneFor=(source,properties)=>{
        const eventId=Number(source&&source.eventId)||0;
        const canonicalUrl=String(source&&source.canonicalUrl||'').trim();
        const raw=item.raw&&typeof item.raw==='object'?item.raw:{};
        const originalDb=raw.rpg_event_db&&typeof raw.rpg_event_db==='object'?raw.rpg_event_db:{};
        return Object.assign({},item,properties,canonicalUrl?{canonicalUrl}:{},
          eventId?{raw:Object.assign({},raw,{rpg_event_db:Object.assign({},originalDb,{eventId})})}:{});
      };
      const laterItem=()=>cloneFor(later,{start:laterStart,
        end:laterEnd&&!isNaN(laterEnd.getTime())?laterEnd:null,
        _rpgCollapsedFutureSeries:true,
        _rpgNearTermKey:String(item.id)+'@future-series'});
      if(!selected.length){result.push(hasLater?laterItem():item);return;}
      selected.forEach(occ=>result.push(cloneFor(occ,{start:occ.start,end:occ.end,
        _rpgNearTermKey:String(item.id)+'@'+occ.key})));
      // Keep one collapsed future-series card after tomorrow. The full catalog
      // must remain reachable without one card for every distant day.
      if(hasLater)result.push(laterItem());
    });
    return result;
  }

  // V332: In the handoff time tiers, exact coordinates keep exact precedence.
  // Only source-verified city-scoped events without a point coordinate receive
  // an INTERNAL proximity proxy: median of already-geocoded event distances
  // in that same explicitly selected city. This is not an event's real km,
  // is never displayed, and does not form city groups or change radius rules.
  // If there are no reliable same-city samples, these events remain unsorted
  // by geography (Infinity), as in v331; do not invent a point/centroid.
  const HOME_EVENT_PRIORITY_KEY='rpg-home-events-priority-v1';
  function eventIsLongRunning(item){
    if(item&&item.allDay)return true;
    const start=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    const end=item&&item.end instanceof Date?item.end:new Date(item&&item.end||0);
    return !isNaN(start.getTime())&&!isNaN(end.getTime())&&end.getTime()-start.getTime()>=20*3600000;
  }
  function eventPriorityCompare(items,mode,location,nowDate){
    const now=nowDate instanceof Date?nowDate:new Date();
    const todayStart=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
    const cityKey=value=>String(value||'').normalize('NFKC').trim().toLocaleLowerCase('de');
    const selectedCity=cityKey(location&&location.city);
    const localSamples=selectedCity?(Array.isArray(items)?items:[])
      .filter(x=>cityKey(x&&x.city)===selectedCity&&Number.isFinite(x&&x.distanceKm)&&x.distanceKm>=0)
      .map(x=>x.distanceKm).sort((a,b)=>a-b):[];
    // Use only real existing coordinates as evidence for a sort-only local
    // proxy. It is not a geocode, real event distance, or a displayed km.
    const mid=Math.floor(localSamples.length/2);
    const localProxy=localSamples.length
      ?(localSamples.length%2?localSamples[mid]:(localSamples[mid-1]+localSamples[mid])/2)
      :Infinity;
    const distance=x=>{
      if(x&&Number.isFinite(x.distanceKm)&&x.distanceKm>=0)return x.distanceKm;
      if(x&&x.cityScope===true&&selectedCity&&cityKey(x.city)===selectedCity)return localProxy;
      return Infinity;
    };
    const startTime=x=>{
      const d=x&&x.start instanceof Date?x.start:new Date(x&&x.start||0);
      return isNaN(d.getTime())?Infinity:d.getTime();
    };
    const calendarDay=x=>{
      const d=x&&x.start instanceof Date?x.start:new Date(x&&x.start||0);
      if(isNaN(d.getTime()))return Infinity;
      // An already-running multi-day event has no new occurrence on its
      // original start date: place it in today's remaining catalogue, not in
      // a historical day. This affects only the priority-enabled view.
      const day=new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime();
      return eventIsLongRunning(x)&&day<todayStart?todayStart:day;
    };
    const rankCache=new WeakMap();
    const group=x=>{
      if(rankCache.has(x))return rankCache.get(x);
      const match=homeEventMatchesTime(x,mode,now);
      let rank=2;
      if(match){
        if(!eventIsLongRunning(x))rank=0;
        else rank=(mode==='now'||mode==='today')&&homeEventDayAccess(x,now).state==='unknown'?1.5:1;
      }
      rankCache.set(x,rank);
      return rank;
    };
    return (a,b)=>{
      const ga=group(a),gb=group(b);
      if(ga!==gb)return ga-gb;
      // The selected Home window has already been grouped above. Only the
      // remaining catalogue uses day-first sorting, then exact proximity.
      if(ga===2){
        const ad=calendarDay(a),bd=calendarDay(b);
        if(ad!==bd)return ad-bd;
      }
      const ad=distance(a),bd=distance(b);
      if(ad!==bd)return ad-bd;
      const at=startTime(a),bt=startTime(b);
      if(at!==bt)return at-bt;
      const ai=String(a&&a._rpgNearTermKey||a&&a.id||'');
      const bi=String(b&&b._rpgNearTermKey||b&&b.id||'');
      if(ai!==bi)return ai.localeCompare(bi,'de');
      return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
    };
  }
  function storeHomeEventPriority(mode,location,radius){
    if(!['now','today','tomorrow'].includes(mode))return;
    try{
      window.sessionStorage.setItem(HOME_EVENT_PRIORITY_KEY,JSON.stringify({mode,at:Date.now(),lat:location&&location.lat,lng:location&&location.lng,radius}));
    }catch(_){}
  }
  function consumeHomeEventPriority(location,radius){
    try{
      const raw=window.sessionStorage.getItem(HOME_EVENT_PRIORITY_KEY);
      window.sessionStorage.removeItem(HOME_EVENT_PRIORITY_KEY);
      const d=JSON.parse(raw||'null');
      if(!d||!['now','today','tomorrow'].includes(d.mode)||Date.now()-d.at>300000||Date.now()<d.at)return '';
      if(Number(d.radius)!==Number(radius))return '';
      if(location&&Number.isFinite(Number(d.lat))&&Number.isFinite(Number(d.lng))&&
        (Math.abs(Number(d.lat)-Number(location.lat))>0.001||Math.abs(Number(d.lng)-Number(location.lng))>0.001))return '';
      return d.mode;
    }catch(_){return '';}
  }

  function eventUrgencyCompare(a,b){
    const now=Date.now();
    const dayKey=d=>{const x=d instanceof Date?d:new Date(d||0);return isNaN(x)?'':x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0');};
    const today=dayKey(new Date(now));
    const rank=item=>{
      const startValue=item&&item.start;
      const endValue=item&&item.end;
      const start=startValue instanceof Date?startValue:(startValue?new Date(startValue):null);
      const end=endValue instanceof Date?endValue:(endValue?new Date(endValue):null);
      const st=!start||isNaN(start)?Number.POSITIVE_INFINITY:start.getTime();
      const et=!end||isNaN(end)?Number.NaN:end.getTime();
      const startDay=dayKey(start);
      const endDay=dayKey(end);
      const running=st<=now&&(!Number.isFinite(et)||et>=now);
      const multiDay=Boolean(startDay&&endDay&&startDay!==endDay);

      // V296: today's concrete appointments must not disappear behind exhibitions,
      // fairs or other long-running events that merely remain active today.
      // Keep the established radius boundary and date-first principle; only split
      // the former "running" bucket into current same-day appointments and true
      // multi-day/older running events.
      if(running&&!multiDay&&startDay===today)return {bucket:0,time:st};
      if(st>now&&startDay===today)return {bucket:1,time:st};
      if(running)return {bucket:2,time:Number.isFinite(et)?et:st};
      return {bucket:3,time:st};
    };
    const ar=rank(a),br=rank(b);
    if(ar.bucket!==br.bucket)return ar.bucket-br.bucket;
    if(ar.time!==br.time)return ar.time-br.time;
    const ad=Number.isFinite(a&&a.distanceKm)?a.distanceKm:Number.POSITIVE_INFINITY;
    const bd=Number.isFinite(b&&b.distanceKm)?b.distanceKm:Number.POSITIVE_INFINITY;
    if(ad!==bd)return ad-bd;
    return String(a&&a.title||'').localeCompare(String(b&&b.title||''),'de');
  }

  function localIsoDate(date){
    const d=date instanceof Date?date:new Date(date);
    const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
    return y+'-'+m+'-'+day;
  }
  function isoDayBoundary(iso,end){
    const p=String(iso||'').split('-').map(Number);
    if(p.length!==3||!p[0]||!p[1]||!p[2])return null;
    return new Date(p[0],p[1]-1,p[2],end?23:0,end?59:0,end?59:0,end?999:0);
  }
  function eventOverlapsDateRange(item,fromIso,toIso){
    if(!fromIso)return true;
    const rangeStart=isoDayBoundary(fromIso,false),rangeEnd=isoDayBoundary(toIso||fromIso,true);
    const eventStart=item&&item.start instanceof Date?item.start:new Date(item&&item.start||0);
    let eventEnd=item&&item.end instanceof Date?item.end:new Date(item&&item.end||0);
    if(!rangeStart||!rangeEnd||isNaN(eventStart.getTime()))return false;
    if(isNaN(eventEnd.getTime())||eventEnd.getTime()<eventStart.getTime())eventEnd=eventStart;
    return eventStart.getTime()<=rangeEnd.getTime()&&eventEnd.getTime()>=rangeStart.getTime();
  }
  function eventDatePreset(mode){
    const now=new Date();
    if(mode==='today'){
      const d=localIsoDate(now); return {from:d,to:d,label:'Heute'};
    }
    if(mode==='tomorrow'){
      const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1); const iso=localIsoDate(d);
      return {from:iso,to:iso,label:'Morgen'};
    }
    if(mode==='weekend'){
      const day=now.getDay();
      let delta;
      if(day===5)delta=0; else if(day===6)delta=-1; else if(day===0)delta=-2; else delta=5-day;
      const fri=new Date(now.getFullYear(),now.getMonth(),now.getDate()+delta);
      const sun=new Date(fri.getFullYear(),fri.getMonth(),fri.getDate()+2);
      return {from:localIsoDate(fri),to:localIsoDate(sun),label:'Am Wochenende'};
    }
    return {from:'',to:'',label:''};
  }
  function formatEventRangeLabel(fromIso,toIso){
    if(!fromIso)return '';
    const a=isoDayBoundary(fromIso,false),b=isoDayBoundary(toIso||fromIso,false);
    if(!a||!b)return '';
    const fmt=d=>d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric'});
    return fromIso===(toIso||fromIso)?fmt(a):(fmt(a)+' – '+fmt(b));
  }
  function calendarDateOnly(value){
    const date=value instanceof Date?value:new Date(value);
    if(isNaN(date.getTime()))return '';
    const pad=n=>String(n).padStart(2,'0');
    return String(date.getFullYear())+pad(date.getMonth()+1)+pad(date.getDate());
  }

  function eventDateIsMidnight(value){
    const date=value instanceof Date?value:new Date(value);
    return !isNaN(date.getTime())&&date.getHours()===0&&date.getMinutes()===0&&date.getSeconds()===0;
  }

  function eventAllDayValue(item,start,end){
    if(item&&item.allDayKnown)return !!item.allDay;
    if(item&&item.allDay===true)return true;
    const a=start instanceof Date?start:new Date(start||0),b=end instanceof Date?end:new Date(end||0);
    const validA=!isNaN(a.getTime())&&a.getTime()>0,validB=!isNaN(b.getTime())&&b.getTime()>a.getTime();
    return validA&&eventDateIsMidnight(a)&&(!validB||eventDateIsMidnight(b));
  }

  function eventCardDate(item){
    if(!item||!item.start)return '';
    const start=item.start instanceof Date?item.start:new Date(item.start);if(isNaN(start.getTime()))return '';
    const end=item.end instanceof Date?item.end:new Date(item.end||0);
    const hasEnd=!isNaN(end.getTime())&&end.getTime()>start.getTime();
    const allDay=eventAllDayValue(item,start,end);

    // Running multi-day events must not look expired just because their original
    // start date is in the past. For date-only feeds that encode the end as the
    // exclusive midnight of the following day, subtract one second for display
    // purposes only so a one-day event remains a one-day card.
    if(hasEnd&&start.getTime()<=Date.now()&&end.getTime()>=Date.now()){
      let displayEnd=end;
      if(allDay&&eventDateIsMidnight(end))displayEnd=new Date(end.getTime()-1000);
      const differentDay=start.getFullYear()!==displayEnd.getFullYear()||start.getMonth()!==displayEnd.getMonth()||start.getDate()!==displayEnd.getDate();
      const genuinelyMultiDay=allDay||(end.getTime()-start.getTime())>=24*60*60*1000;
      if(differentDay&&genuinelyMultiDay){
        return 'bis '+new Intl.DateTimeFormat('de-DE',{day:'2-digit',month:'2-digit'}).format(displayEnd);
      }
    }

    return new Intl.DateTimeFormat('de-DE',allDay?{day:'2-digit',month:'2-digit'}:{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(start);
  }

  function eventCalendarData(item){
    if(!item||item.category!=='events')return null;
    const start=item.start instanceof Date?item.start:new Date(item.start||0);
    if(isNaN(start.getTime())||start.getTime()<=0)return null;
    let end=item.end instanceof Date?item.end:new Date(item.end||0);
    const hasValidEnd=!isNaN(end.getTime())&&end.getTime()>start.getTime();
    // ET4 often uses 00:00 -> 00:00 next day for date-only occurrences.
    // Treat those values as day boundaries, never as evidence of a midnight start.
    const allDay=eventAllDayValue(item,start,end);
    if(allDay){
      if(!hasValidEnd){end=new Date(start);end.setDate(end.getDate()+1);}
    }else if(!hasValidEnd){
      // No invented duration for timed ET4 events without an explicit end.
      end=null;
    }
    const location=String(item.address||item.city||'').trim();
    const description=String(item.description||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
    const officialWebsite=String(item.website||'').trim();
    const canonicalWebsite=String(item.canonicalUrl||RPG.buildShareUrl(item)||'').trim();
    const details=[description,officialWebsite?'Offizielle Event-Seite: '+officialWebsite:'',canonicalWebsite?'RuhrpottGuru: '+canonicalWebsite:''].filter(Boolean).join('\n\n');
    return {title:String(item.title||'Veranstaltung').trim(),start,end,allDay,location,description:details,website:canonicalWebsite||officialWebsite};
  }


window.rpgEventListing=function(raw,location,radius){const home=false,mode="",eventWindow="";
            let items=raw.map(x=>RPG.normalizeEvent(x,location)).filter(x=>{
              if(!x.start)return false;
              if(!x.end||x.end.getTime()>=Date.now()-3600000)return true;
              const series=x.series||{};
              const near=Array.isArray(series.nearTerm)?series.nearTerm:[];
              return near.some(o=>new Date(o&&o.end||o&&o.start||0).getTime()>=Date.now()-3600000)
                ||new Date(series.laterSeries&&series.laterSeries.start||0).getTime()>Date.now();
            });
            // V315: official city-scoped municipal events have deliberately no fake
            // point coordinate. The backend only returns them for their selected
            // city, so they remain eligible without displaying a made-up distance.
            items=items.filter(x=>Number.isFinite(x.distanceKm)||x.cityScope===true);
            items=RPG.dedupeEventsForListing(items);
            if(mode!=='halloween'&&mode!=='weihnachten')items=eventNearTermCards(items,new Date());
            // V296: radius remains the eligibility boundary. Within that radius,
            // current/later-today appointments come before long-running events;
            // long-running events still remain ahead of tomorrow/later dates.
            // Distance remains only the tie-breaker inside the same urgency/time tier.
            // V329: selected Home time or one-shot Home→Events priority controls
            // presentation order only. The full category remains available.
            const priorityEventView=eventWindow&&['now','today','tomorrow'].includes(eventWindow);
            items.sort(priorityEventView?eventPriorityCompare(items,eventWindow,location,new Date()):eventUrgencyCompare);
            // Event eligibility never depends on the image source. Original ET4/ODF
            // artwork, approved symbolic/context images and events without an image all
            // remain in the same listing pool; cards fall back to the standard ticket
            // placeholder when no image can be resolved.
            let effective=radius, visible=items.filter(x=>x.cityScope===true||x.distanceKm<=radius);
            // V299: seasonal specials must filter from the complete radius-eligible
            // event pool before presentation limits (the full category now paginates).
            // Otherwise late-October Halloween events disappear behind hundreds of
            // earlier September/October events even though they are in the database.
            if(mode==='halloween') visible=visible.filter(isHalloweenEvent);
            if(mode==='weihnachten') visible=visible.filter(x=>christmasCategories(x).length>0);
            if(home&&visible.length<4&&radius<10){effective=10;visible=items.filter(x=>x.cityScope===true||x.distanceKm<=10);}
            // Rank the final radius-admitted pool, never farther-away candidates.
            if(!home&&priorityEventView)visible.sort(eventPriorityCompare(visible,eventWindow,location,new Date()));
            // Only the Home Event card shortlist gains a time selection.
            if(home&&eventWindow){
              const now=new Date();
              visible=visible.filter(x=>homeEventMatchesTime(x,eventWindow,now));
              visible.sort(eventPriorityCompare(visible,eventWindow,location,now));
            }
            visible=home?visible.slice(0,4):visible;
            const baseItems=visible.slice();
            const mediaHead=home?baseItems:baseItems.slice(0,300);
            const mediaTail=home?[]:baseItems.slice(300);
            let localItems=baseItems;
            if(typeof RPG.diversifyEventMediaLocal==='function')localItems=RPG.diversifyEventMediaLocal(mediaHead).concat(mediaTail);

return {items:localItems,baseItems,effectiveRadius:effective};};
window.rpgEventFilter=function(items,query,tagFilter,sub,dateFrom,dateTo){const category="events",s={items},q=query.trim().toLowerCase();
    const filtered=s.items.filter(x=>{
      const facet=category==='events'?x.eventType:x.subtitle;
      const textOk=!q||[x.title,x.subtitle,x.eventType,x.city,x.address].concat(Array.isArray(x.labels)?x.labels:[]).join(' ').toLowerCase().includes(q);
      const tagOk=!tagFilter||RPG.categoryFilterTags(x).some(label=>RPG.tagSlug(label)===tagFilter);
      const dateOk=category!=='events'||!dateFrom||eventOverlapsDateRange(x,dateFrom,dateTo);
      return (!sub||facet===sub)&&textOk&&tagOk&&dateOk;
    });
return filtered;};
window.rpgEventAllDayValue=eventAllDayValue;window.rpgEventPreset=eventDatePreset;window.rpgEventRangeLabel=formatEventRangeLabel;
window.rpgEventFacts=function(item){
    const parseEventLocalDate=value=>{if(value instanceof Date)return isNaN(value)?null:value;const text=String(value||'').trim();if(!text)return null;const m=text.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);if(m){const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),Number(m[4]||0),Number(m[5]||0),Number(m[6]||0));return isNaN(d)?null:d;}const d=new Date(text);return isNaN(d)?null:d;};
    const formatEventTiming=(start,end,allDayFlag=false)=>{const a=parseEventLocalDate(start),b=parseEventLocalDate(end);if(!a)return '';const dateLong=new Intl.DateTimeFormat('de-DE',{weekday:'long',day:'numeric',month:'long',year:'numeric'});const dateShort=new Intl.DateTimeFormat('de-DE',{day:'numeric',month:'long',year:'numeric'});const time=new Intl.DateTimeFormat('de-DE',{hour:'2-digit',minute:'2-digit'});const midnight=d=>!!d&&d.getHours()===0&&d.getMinutes()===0&&d.getSeconds()===0;const sameDay=(x,y)=>x.getFullYear()===y.getFullYear()&&x.getMonth()===y.getMonth()&&x.getDate()===y.getDate();const allDay=!!allDayFlag||(midnight(a)&&(!b||!(b>a)||midnight(b)));if(allDay){if(b&&b>a&&midnight(b)){const last=new Date(b);last.setDate(last.getDate()-1);if(!sameDay(a,last))return dateShort.format(a)+' – '+dateShort.format(last);}return dateLong.format(a);}if(b&&b>a){if(sameDay(a,b))return dateLong.format(a)+' · '+time.format(a)+'–'+time.format(b)+' Uhr';return dateLong.format(a)+' · '+time.format(a)+' – '+dateLong.format(b)+' · '+time.format(b)+' Uhr';}return dateLong.format(a)+' · '+time.format(a)+' Uhr';};
    const eventDate=item.start?formatEventTiming(item.start,item.end,eventAllDayValue(item,item.start,item.end)):'';
    const eventDocuments=item.category==='events'?(Array.isArray(item.documents)?item.documents:[]).filter(d=>d&&String(d.url||'').trim()).slice(0,8):[];
    const eventVisitorHours=item.category==='events'?String(item.visitorHours||'').trim():'';
    const eventDayHours=item.category==='events'?String(item.dayHours||'').trim():'';
    const collapseExactRepeat=value=>{let text=String(value==null?'':value).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();for(let pass=0;pass<3;pass++){const words=text.split(/\s+/);if(words.length<2||words.length%2)break;const half=words.length/2;const a=words.slice(0,half).join(' '),b=words.slice(half).join(' ');const norm=v=>v.toLocaleLowerCase('de').replace(/[.,;:!?]+$/g,'').trim();if(norm(a)!==norm(b))break;text=a;}return text;};
    const foodPriceTier=item.category==='food'?String(item.priceTier||''):'';
    // V317: canonical Wesel prices can arrive compact as e.g. `45.00EUR`.
    // Normalize currency notation for visitors before deciding whether a usable
    // price signal exists. This keeps the source value authoritative while
    // presenting it in German notation.
    const formatEventPrice=value=>{let text=collapseExactRepeat(value||'');if(!text)return '';text=text.replace(/(\d+(?:[.,]\d{1,2})?)\s*EUR\b/ig,(_,raw)=>{const n=Number(String(raw).replace(',','.'));if(!Number.isFinite(n))return raw+' €';const hasCents=Math.abs(n-Math.round(n))>0.0001;return n.toLocaleString('de-DE',{minimumFractionDigits:hasCents?2:0,maximumFractionDigits:2})+' €';});return text;};
    const price=item.category==='events'?formatEventPrice(item.priceText||''):(item.category==='food'?foodPriceTier:((item.tags&&(item.tags['charge']||item.tags['fee']))||''));
    const eventFacts=item.category==='events'&&item.eventInfo&&typeof item.eventInfo==='object'?item.eventInfo:{};
    const cleanEventInfoList=values=>{const seen=new Set();return (Array.isArray(values)?values:[]).map(v=>String(v||'').trim()).filter(v=>{const k=v.toLocaleLowerCase('de');if(!v||/^(?:divers|sonstiges?|weitere events?)$/i.test(v)||seen.has(k))return false;seen.add(k);return true;});};
    const eventFeatures=cleanEventInfoList(eventFacts.features).slice(0,12);
    const eventCategories=cleanEventInfoList(eventFacts.categories).slice(0,10);
    const eventKeywords=cleanEventInfoList(eventFacts.keywords).slice(0,20);
    const eventAttributes=Array.isArray(eventFacts.attributes)?eventFacts.attributes:[];
    const eventNumbers=Array.isArray(eventFacts.numbers)?eventFacts.numbers:[];
    const isRichEvent=item.category==='events';
    const cleanRepeatedText=collapseExactRepeat;
    const cleanPriceLabel=value=>String(value||'').replace(/[_-]+/g,' ').replace(/\b(price|preis|admission|eintritt|fee|cost|charge)\b/ig,'').replace(/\s+/g,' ').trim();
    const structuredPrices=isRichEvent&&item.prices&&Array.isArray(item.prices.items)?(()=>{const seen=new Set();return item.prices.items.map(row=>row&&typeof row==='object'?Object.assign({},row,{value:cleanRepeatedText(row.value)}):row).filter(row=>{if(!row||!String(row.value||'').trim())return false;const key=(String(row.label||'')+'|'+String(row.value||'')).toLocaleLowerCase('de');if(seen.has(key))return false;seen.add(key);return true;}).slice(0,14);})():[];
    const priceHasSignal=value=>/(?:€|EUR\b|\beuro\b|kostenlos|eintritt\s+frei|freier\s+eintritt|ermäß|ermaess|familienkarte|\bpreis\b|\bgebühr\b|\bgebuehr\b|\d+[,.]\d{1,2}\s*(?:€|EUR|euro))/i.test(String(value||''));
    const displayPrice=structuredPrices.length||priceHasSignal(price)?price:'';
    // V319: ticket URLs sometimes arrive embedded in free-form price text (e.g.
    // "Tickets - Ticketlink: https://…; 15 € An der Abendkasse … 20 €").
    // Pull the URL out into its own action and keep only visitor-readable price facts.
    const embeddedTicketUrl=(()=>{const m=String(displayPrice||'').match(/https?:\/\/[^\s;|•]+/i);return m?m[0].replace(/[),.]+$/,''):'';})();
    const eventTicketUrl=item.category==='events'?(String(item.ticketUrl||embeddedTicketUrl||'').trim()):'';
    const cleanFreePriceText=value=>{let text=String(value||'');if(embeddedTicketUrl)text=text.replace(embeddedTicketUrl,' ');text=text.replace(/\bTickets?\s*-?\s*Ticketlink\s*:?/ig,' ').replace(/\bTicketlink\s*:?/ig,' ').replace(/\s+/g,' ').trim();return text.replace(/^[;|•,:\-\s]+|[;|•,:\-\s]+$/g,'').trim();};
    const fallbackPriceRows=(()=>{if(!displayPrice||structuredPrices.length)return [];const cleaned=cleanFreePriceText(displayPrice);if(!cleaned)return [];let rows=cleaned.split(/\s*(?:;|•|\|)\s*/).filter(Boolean);rows=rows.flatMap(v=>String(v).split(/\s+(?=An der Abendkasse\b|Abendkasse\b)/i)).filter(Boolean);if(rows.length<2&&cleaned.length>90)rows=cleaned.split(/,\s+(?=[A-ZÄÖÜ0-9])/).filter(Boolean);const seen=new Set();return rows.map(cleanRepeatedText).map(v=>v.replace(/^An der Abendkasse kostet (?:der )?Einlass\s*/i,'Abendkasse: ').replace(/^An der Abendkasse\s*/i,'Abendkasse: ')).filter(v=>{const k=v.toLocaleLowerCase('de');if(!v||seen.has(k))return false;seen.add(k);return true;}).slice(0,14).map(v=>({label:'',value:v}));})();
    const priceRows=structuredPrices.length?structuredPrices:fallbackPriceRows;

const calendar=eventCalendarData(item);return {date:eventDate,cardDate:eventCardDate(item),priceText:cleanFreePriceText(displayPrice),priceRows,ticketUrl:eventTicketUrl,documents:eventDocuments,visitorHours:eventVisitorHours,dayHours:eventDayHours,organizers:item.organizers||[],participants:item.participants||[],calendar:calendar?{...calendar,start:calendar.start.getTime(),end:calendar.end?calendar.end.getTime():null,startDay:calendarDateOnly(calendar.start),endDay:calendar.end?calendarDateOnly(calendar.end):""}:null};};
})();
