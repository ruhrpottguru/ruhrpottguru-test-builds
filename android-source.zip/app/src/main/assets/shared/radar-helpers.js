(function(){const RPG=window.RPGReact;
  const BUDE_FEATURES=[
    ['mixed_candy','🍬','Gemischte Tüte'],
    ['coffee','☕','Kaffee'],
    ['sandwiches','🥪','Belegte Brötchen'],
    ['seating','🪑','Sitzplätze'],
    ['lottery','🎟️','Lotto'],
    ['parcel_shop','📦','Paketshop'],
    ['tobacco','◼','Tabak'],
    ['late_night','🌙','Spät geöffnet']
  ];

  function budeFeature(item,key){
    const tags=item.tags||{};
    if(tags['rg:buedchen_feature_'+key]==='yes')return true;
    if(tags['rg:buedchen_feature_'+key]==='no')return false;
    if(key==='coffee')return tags['drink:coffee']==='yes'||tags.coffee==='yes';
    if(key==='seating')return tags.seating==='yes'||tags.outdoor_seating==='yes';
    if(key==='lottery')return tags.lottery==='yes';
    if(key==='tobacco')return tags.tobacco==='yes';
    if(key==='parcel_shop')return tags.parcel_pickup==='yes'||tags.post_office==='yes'||!!tags.parcel_mail_in;
    if(key==='late_night'){
      const oh=String(item.openingHours||'');
      return /(?:23|24):\d{2}|(?:00|01|02):\d{2}/.test(oh);
    }
    return false;
  }

  function budeTier(item){return String((item.tags||{})['rg:buedchen_tier']||'');}
  function budeVerified(item){return String((item.tags||{})['rg:buedchen_review_status']||'')==='verified';}

  function openingState(raw){
    const text=String(raw||'').trim();
    if(!text)return {state:'unknown',label:'Öffnungszeiten nicht bekannt'};
    if(/^24\/7$/i.test(text))return {state:'open',label:'Jetzt geöffnet · '+RPG.formatOpeningHours(text)};
    const days=['Su','Mo','Tu','We','Th','Fr','Sa'];
    const now=new Date(),day=days[now.getDay()],mins=now.getHours()*60+now.getMinutes();
    const dayAliases={Mo:'Mo',Tu:'Tu',We:'We',Th:'Th',Fr:'Fr',Sa:'Sa',Su:'Su'};
    const order=['Mo','Tu','We','Th','Fr','Sa','Su'];
    function dayMatches(spec){
      spec=spec.trim();
      if(!spec)return false;
      for(const part of spec.split(',')){
        const p=part.trim();
        if(p===day)return true;
        const m=p.match(/^(Mo|Tu|We|Th|Fr|Sa|Su)-(Mo|Tu|We|Th|Fr|Sa|Su)$/);
        if(m){
          const a=order.indexOf(m[1]),b=order.indexOf(m[2]),d=order.indexOf(day);
          if(a<=b&&d>=a&&d<=b)return true;
          if(a>b&&(d>=a||d<=b))return true;
        }
      }
      return false;
    }
    for(const segment of text.split(';')){
      const m=segment.trim().match(/^((?:(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?(?:,\s*)?)+)\s+(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})/);
      if(!m||!dayMatches(m[1]))continue;
      const start=Number(m[2])*60+Number(m[3]),end=Number(m[4])*60+Number(m[5]);
      const open=end<start?(mins>=start||mins<=end):(mins>=start&&mins<=end);
      return {state:open?'open':'closed',label:(open?'Jetzt geöffnet':'Aktuell geschlossen')+' · '+RPG.formatOpeningHours(text)};
    }
    return {state:'known',label:'Öffnungszeiten: '+RPG.formatOpeningHours(text)};
  }

  const WURST_FILTERS=[
    ['currywurst','🌭','Currywurst'],['pommes','🍟','Pommes-Schmiede'],['schnitzel','🍳','Aus der Pfanne'],
    ['frikadelle','●','Wie bei Omma'],['schaschlik','◆','Schaschlik'],['bratwurst','♨','Bratwurst']
  ];
  function wurstMenuItems(item){return String((item.tags||{})['rg:wurst_menu_items']||'').split('|').map(x=>x.trim()).filter(Boolean);}
    const qualitySelect=(normalized)=>{
      const a=normalized.filter(x=>budeVerified(x)||budeTier(x)==='A');
      const b=normalized.filter(x=>!budeVerified(x)&&budeTier(x)==='B');
      return a.length>=12?a:a.concat(b.slice(0,Math.max(0,12-a.length)));
    };
    const timeKeys=['open'],featureKeys=['mixed_candy','coffee','seating','parcel_shop','lottery'];
    const toggle=(current,key)=>{
      const next=Object.assign({},current);
      const activating=!next[key];
      // Time filters and assortment filters are independent modes. Choosing
      // coffee/seating/etc. clears an old "opened" constraint, and vice versa.
      if(activating&&featureKeys.includes(key))timeKeys.forEach(k=>{next[k]=false;});
      if(activating&&timeKeys.includes(key))featureKeys.forEach(k=>{next[k]=false;});
      next[key]=activating;
      return next;
    };

window.RadarRules={
select(raw,point,category){
 if(category==='buedchen')return qualitySelect(raw.map(x=>RPG.normalizePlace(x,'buedchen',point)).sort((a,b)=>(a.distanceKm??999)-(b.distanceKm??999)));
 return raw.map(x=>{const item=RPG.normalizePlace(x,'wurst',point);item.labels=wurstMenuItems(item).map(v=>v.charAt(0).toUpperCase()+v.slice(1));item.subtitle='Imbissbude';return item;});
},
buedchen(activeItems,filters){
return activeItems.filter(item=>{
      const opening=openingState(item.openingHours);
      if(filters.open&&opening.state!=='open')return false;
      if(filters.lottery&&!budeFeature(item,'lottery'))return false;
      for(const key of ['mixed_candy','coffee','seating','parcel_shop']){
        if(filters[key]&&!budeFeature(item,key))return false;
      }
      return true;
});
},
wurst(items,filter,query,sort){const state={items};
      let out=state.items.filter(x=>filter==='all'||wurstMenuItems(x).includes(filter));
      const q=query.trim().toLocaleLowerCase('de');
      if(q)out=out.filter(x=>[x.title,x.city,x.address].concat(wurstMenuItems(x)).filter(Boolean).join(' ').toLocaleLowerCase('de').includes(q));
      if(sort==='new'){
        out=out.slice().sort((a,b)=>String((b.tags||{})['rg:wurst_first_seen']||'').localeCompare(String((a.tags||{})['rg:wurst_first_seen']||''))||((a.distanceKm??999)-(b.distanceKm??999)));
      }else{
        out=out.slice().sort((a,b)=>(a.distanceKm??999)-(b.distanceKm??999));
      }
      return out;

},
toggle,
features:BUDE_FEATURES,
filters:WURST_FILTERS,
facts(item){return item.category==='buedchen'?{features:BUDE_FEATURES.filter(x=>budeFeature(item,x[0])).map(x=>({key:x[0],label:x[2]})),opening:openingState(item.openingHours),formatted:RPG.formatOpeningHours(item.openingHours)}:{menu:wurstMenuItems(item),tier:((item.tags||{})['rg:wurst_tier']==='B'&&(item.tags||{})['rg:wurst_review_status']!=='confirmed')?'Im Radar':'Geprüft'};}
};})();
