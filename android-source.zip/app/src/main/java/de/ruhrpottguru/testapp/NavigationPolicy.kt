package de.ruhrpottguru.testapp

/** Explicit outbound actions only; app categories never navigate to a web page. */
internal fun allowedExternalUrl(value: String): Boolean {
    if(value.startsWith("tel:",ignoreCase=true))return value.substringAfter(':').matches(Regex("[+0-9() /.-]+"))
    if(value.startsWith("mailto:",ignoreCase=true))return value.substringAfter(':').matches(Regex("[^\\s@?%#,:;<>\\r\\n]+@[^\\s@?%#,:;<>\\r\\n]+\\.[^\\s@?%#,:;<>\\r\\n]+"))
    return try {
        val uri=java.net.URI(value)
        uri.scheme?.lowercase() in listOf("https","http") && !uri.host.isNullOrBlank() && uri.userInfo==null
    } catch (_:Exception) {false}
}
