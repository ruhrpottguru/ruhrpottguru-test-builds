package de.ruhrpottguru.testapp

/** Main-thread-owned resolver jobs. IDs are isolated by the existing data generation. */
class MediaAttemptGate(private val clock:()->Long={System.nanoTime()/1_000_000}) {
    companion object {const val RETRY_DELAY_MS=1500L}
    enum class Outcome { APPLIED, NO_IMAGE, TRANSIENT_FAILURE }
    data class Ticket(val id:String,val serial:Long)
    private data class Entry(var attempts:Int=0,var pending:Long?=null,var settled:Boolean=false,var retryAt:Long=0)
    private val entries=mutableMapOf<String,Entry>()
    private var serial=0L
    fun begin(id:String,failedImage:Boolean=false):Ticket? {
        val e=entries.getOrPut(id){Entry()}
        if(e.pending!=null || clock()<e.retryAt || e.attempts>=2 || (e.settled&&!failedImage))return null
        e.attempts++;val next=++serial;e.pending=next;e.settled=false
        return Ticket(id,next)
    }
    fun finish(ticket:Ticket,outcome:Outcome):Boolean {
        val e=entries[ticket.id] ?: return false
        if(e.pending!=ticket.serial)return false
        e.pending=null;e.retryAt=if(outcome==Outcome.TRANSIENT_FAILURE)clock()+RETRY_DELAY_MS else 0;e.settled=outcome!=Outcome.TRANSIENT_FAILURE||e.attempts>=2
        return outcome==Outcome.TRANSIENT_FAILURE&&e.attempts<2
    }
    fun clear(){entries.clear()}
}
