package de.ruhrpottguru.testapp

import kotlin.math.*

/** Existing BudeMap defaults, viewport bounds, marker collision and proxy contract. */
object RadarGeometry {
    fun initialZoom(radius:Double)=if(radius<=1)16.0 else if(radius<=2.5)15.0 else 14.0
    fun radiusKm(lat:Double,zoom:Double,width:Double,height:Double):Double {
        val metersPerPx=cos(lat*PI/180)*156543.03392/2.0.pow(zoom)
        return (hypot(width/2,height/2)*metersPerPx/1000).coerceIn(.5,50.0)
    }
    fun tileUrl(zoom:Int,x:Int,y:Int):String {
        require(zoom in 10..18);val n=1 shl zoom;require(y in 0 until n);val wrapped=((x%n)+n)%n
        return "https://www.ruhrpottguru.de/wp-admin/admin-ajax.php?action=rg_places_map_tile&z=$zoom&x=$wrapped&y=$y"
    }
    fun overlaps(points:List<TravelPixel>,index:Int)=points.indices.any {it!=index&&hypot(points[it].x-points[index].x,points[it].y-points[index].y)<24}
}
