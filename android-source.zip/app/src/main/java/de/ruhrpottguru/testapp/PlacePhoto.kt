package de.ruhrpottguru.testapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.CachePolicy
import coil3.network.HttpException
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.io.IOException
import org.json.JSONObject

/** Uses the existing Places media, gallery, crop and attribution metadata. */
@Composable
fun PlacePhoto(item:JSONObject,detail:Boolean=false,onFailure:(String)->Unit={},external:((String)->Unit)?=null) {
    val primary=item.optJSONObject("media") ?: JSONObject()
    val gallery=buildList<JSONObject> {
        item.optJSONArray("gallery")?.objects()?.filter {it.text("url").isNotBlank()}?.forEach { e->if(none {it.text("url")==e.text("url")})add(e)}
        if(primary.text("url").isNotBlank() && none {it.text("url")==primary.text("url")})add(0,primary)
    }
    var index by remember(item.text("id")) {mutableIntStateOf(0)}
    val media=if(detail && gallery.isNotEmpty())gallery[index.coerceAtMost(gallery.lastIndex)] else primary
    val url=media.text("url")
    val context=LocalContext.current
    var retrySerial by remember(url) {mutableIntStateOf(0)}
    var automaticRetryUsed by remember(url) {mutableStateOf(false)}
    var retryPending by remember(url) {mutableStateOf(false)}
    LaunchedEffect(url,retryPending) {
        if(retryPending){delay(1500);retryPending=false;retrySerial++}
    }
    val request=remember(url,retrySerial,context) {
        ImageRequest.Builder(context).data(url).apply {
            if(retrySerial>0){memoryCachePolicy(CachePolicy.DISABLED);diskCachePolicy(CachePolicy.DISABLED);networkCachePolicy(CachePolicy.DISABLED)}
        }.build()
    }
    var loaded by remember(url,retrySerial) {mutableStateOf(false)}
    var failed by remember(url,retrySerial) {mutableStateOf(false)}
    var ratio by remember(url) {mutableFloatStateOf(1f)}
    var box by remember {mutableStateOf(IntSize.Zero)}
    val crop=media.optJSONObject(if(detail)"cropDetail" else "cropCard")
    val x=(crop?.optDouble("x",50.0) ?: 50.0).toFloat()
    val y=(crop?.optDouble("y",50.0) ?: 50.0).toFloat()
    val zoom=(crop?.optDouble("zoom",1.0) ?: 1.0).toFloat()
    val contain=crop!=null && zoom<.999f
    val boxRatio=if(box.height>0)box.width.toFloat()/box.height else 1f
    val scale=if(!loaded)1f else if(contain)1f+(maxOf(ratio/boxRatio,boxRatio/ratio)-1f)*zoom else zoom.coerceAtLeast(1f)
    Column {
        Box(Modifier.fillMaxWidth().height(if(detail)244.dp else 178.dp).clip(RoundedCornerShape(if(detail)18.dp else 0.dp)).background(Color(0xFF122034)).onSizeChanged {box=it}) {
            if(url.isNotBlank() && !failed) {
                key(url,retrySerial){AsyncImage(model=request,contentDescription=if(media.text("credit").contains("Symbol",true)||media.text("source")=="pexels")"Symbolbild" else "Bild zu ${item.text("title")}",
                    contentScale=if(contain)ContentScale.Fit else ContentScale.Crop,
                    alignment=BiasAlignment(x/50f-1f,y/50f-1f),
                    modifier=Modifier.matchParentSize().graphicsLayer {scaleX=scale;scaleY=scale;transformOrigin=TransformOrigin(x/100f,y/100f)},
                    onSuccess={state->loaded=true;failed=false;retryPending=false;val size=state.painter.intrinsicSize;if(size.width.isFinite() && size.height>0)ratio=size.width/size.height},
                    onError={state->
                        loaded=false;failed=true
                        val error=state.result.throwable
                        val transient=if(error is HttpException)ImageTransportPolicy.transientStatus(error.response.code) else error is IOException
                        if(transient&&!automaticRetryUsed){automaticRetryUsed=true;retryPending=true}
                        else onFailure(url)
                    })}
            }
            if(!loaded)Column(Modifier.align(Alignment.Center),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)) {
                if(url.isNotBlank() && !failed)CircularProgressIndicator(Modifier.size(24.dp),strokeWidth=2.dp)
                else {
                    Text("♧",fontSize=30.sp,color=Color(0xFFF59E0B))
                    Text(if(retryPending)"Bild wird erneut geladen …" else if(failed)"Bild gerade nicht verfügbar" else "Kein Bild verfügbar",fontSize=12.sp,color=Color(0xFFB6C2D3))
                    if(failed&&url.isNotBlank()&&!retryPending)TextButton(onClick={loaded=false;retrySerial++}){Text("Bild erneut laden")}
                }
            }
            if(detail && gallery.size>1)Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color.Black.copy(alpha=.6f)),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={index=(index-1+gallery.size)%gallery.size},modifier=Modifier.semantics {contentDescription="Vorheriges Bild"}){Text("‹",color=Color.White,fontSize=30.sp)}
                Text("${index+1} / ${gallery.size}",color=Color.White)
                IconButton(onClick={index=(index+1)%gallery.size},modifier=Modifier.semantics {contentDescription="Nächstes Bild"}){Text("›",color=Color.White,fontSize=30.sp)}
            }
        }
        if(loaded) {
            val artist=media.text("artist")
            val caption=listOf(media.text("credit"),artist.takeIf {it.isNotBlank() && !media.text("credit").contains(it,true)}.orEmpty(),media.text("license")).filter {it.isNotBlank()}.joinToString(" · ")
            if(caption.isNotBlank())Text(caption,Modifier.padding(horizontal=if(detail)0.dp else 18.dp,vertical=8.dp),fontSize=11.sp,color=Color(0xFFB6C2D3))
            if(detail && external!=null && media.text("licenseUrl").isNotBlank())TextButton(onClick={external(media.text("licenseUrl"))}){Text("Lizenz: ${media.text("license")}")}
            if(detail && external!=null && media.text("sourceUrl").isNotBlank())TextButton(onClick={external(media.text("sourceUrl"))}){Text("Bildquelle & Nachweis ↗")}
        }
    }
}
