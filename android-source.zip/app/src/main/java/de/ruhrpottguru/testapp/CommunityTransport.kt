package de.ruhrpottguru.testapp

import android.content.Context
import android.net.Uri
import android.graphics.*
import android.media.ExifInterface
import android.os.Build
import android.provider.OpenableColumns
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Native codec/transport for the existing web submission contracts. No background uploads. */
data class UploadPhoto(val name:String,val bytes:ByteArray,val sourceUri:String,val copyright:String="",val sourceUrl:String="")
object CommunityTransport {
    fun optimize(context:Context,uri:Uri):UploadPhoto {
        val resolver=context.contentResolver
        val name=resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use {if(it.moveToFirst())it.getString(0) else null} ?: "foto"
        val type=resolver.getType(uri).orEmpty().lowercase().ifBlank {when(name.substringAfterLast('.',"").lowercase()){ "jpg","jpeg"->"image/jpeg";"png"->"image/png";"webp"->"image/webp";"heic"->"image/heic";"heif"->"image/heif";else->"" }}
        require(type in listOf("image/jpeg","image/png","image/webp","image/heic","image/heif")) {"Erlaubt sind JPG, PNG, WebP und unterstützte HEIC/HEIF-Dateien."}
        val source=resolver.openInputStream(uri)?.use {input->val out=ByteArrayOutputStream();val buffer=ByteArray(8192);while(true){val n=input.read(buffer);if(n<0)break;require(out.size()+n<=20*1024*1024){"Ausgangsdatei größer als 20 MB."};out.write(buffer,0,n)};out.toByteArray()} ?: error("Bild konnte nicht gelesen werden.")
        require(source.isNotEmpty()) {"Die Bilddatei ist leer."}
        var bitmap:Bitmap
        if(Build.VERSION.SDK_INT>=28) {
            bitmap=ImageDecoder.decodeBitmap(ImageDecoder.createSource(java.nio.ByteBuffer.wrap(source))) {decoder,info,_->
                decoder.allocator=ImageDecoder.ALLOCATOR_SOFTWARE
                val scale=minOf(1.0,2400.0/maxOf(info.size.width,info.size.height));decoder.setTargetSize(maxOf(1,(info.size.width*scale).toInt()),maxOf(1,(info.size.height*scale).toInt()))
            }
        } else {
            val bounds=BitmapFactory.Options().apply {inJustDecodeBounds=true};BitmapFactory.decodeByteArray(source,0,source.size,bounds)
            val options=BitmapFactory.Options().apply {inSampleSize=1};while(maxOf(bounds.outWidth,bounds.outHeight)/options.inSampleSize>4800)options.inSampleSize*=2
            bitmap=BitmapFactory.decodeByteArray(source,0,source.size,options) ?: error("Bild konnte nicht gelesen werden.")
            val orientation=source.inputStream().use {ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL)}
            val matrix=Matrix();when(orientation){2->matrix.setScale(-1f,1f);3->matrix.setRotate(180f);4->matrix.setScale(1f,-1f);5->{matrix.setRotate(90f);matrix.postScale(-1f,1f)};6->matrix.setRotate(90f);7->{matrix.setRotate(-90f);matrix.postScale(-1f,1f)};8->matrix.setRotate(-90f)}
            if(!matrix.isIdentity){val rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.width,bitmap.height,matrix,true);if(rotated!==bitmap)bitmap.recycle();bitmap=rotated}
        }
        try {
            val scale=minOf(1.0,2400.0/maxOf(bitmap.width,bitmap.height));var width=maxOf(1,(bitmap.width*scale).toInt());var height=maxOf(1,(bitmap.height*scale).toInt())
            repeat(4) {
                val canvasBitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
                try {
                    val canvas=Canvas(canvasBitmap);canvas.drawColor(Color.WHITE);canvas.drawBitmap(bitmap,null,Rect(0,0,width,height),Paint(Paint.FILTER_BITMAP_FLAG))
                    for(quality in listOf(82,76,70,64)) {
                        val out=ByteArrayOutputStream()
                        @Suppress("DEPRECATION") val format=if(Build.VERSION.SDK_INT>=30)Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                        val encoded=canvasBitmap.compress(format,quality,out)
                        if(encoded&&out.size()>0&&out.size()<=2*1024*1024) {
                            val base=name.substringBeforeLast('.',name).replace(Regex("[^a-zA-Z0-9._-]+"),"-").trim('-').take(90).ifBlank {"foto"}
                            return UploadPhoto("$base.webp",out.toByteArray(),uri.toString())
                        }
                    }
                } finally {canvasBitmap.recycle()}
                if(maxOf(width,height)<=1400)error("Das Foto konnte nicht sicher unter 2 MB optimiert werden.")
                val shrink=maxOf(1400.0/maxOf(width,height),.82);width=maxOf(1,(width*shrink).toInt());height=maxOf(1,(height*shrink).toInt())
            }
            error("Das Foto konnte nicht sicher unter 2 MB optimiert werden.")
        } finally {bitmap.recycle()}
    }
    fun readMedia(postId:Long):Any {
        require(postId>0)
        val url="https://www.ruhrpottguru.de/wp-json/wp/v2/media?parent=$postId&per_page=5&media_type=image&orderby=id&order=asc&_fields=id,source_url,media_details,alt_text"
        val conn=URL(url).openConnection() as HttpURLConnection
        try {conn.connectTimeout=15000;conn.readTimeout=25000;conn.instanceFollowRedirects=false;conn.setRequestProperty("Accept","application/json");check(conn.responseCode in 200..299){"Galerie konnte nicht geladen werden."};return JSONTokener(conn.inputStream.bufferedReader().use {it.readText()}).nextValue()} finally {conn.disconnect()}
    }
    fun submit(path:String,fields:JSONObject,photos:List<UploadPhoto>):JSONObject {
        require(path in listOf("places/contribute","places/community-story"));require(photos.size<=5);require(photos.all {it.bytes.isNotEmpty()&&it.bytes.size<=2*1024*1024})
        val boundary="RPG-"+UUID.randomUUID();val conn=URL(API_ROOT+path).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout=15000;conn.readTimeout=45000;conn.instanceFollowRedirects=false;conn.useCaches=false;conn.requestMethod="POST";conn.doOutput=true;conn.setChunkedStreamingMode(8192);conn.setRequestProperty("Content-Type","multipart/form-data; boundary=$boundary");conn.setRequestProperty("Accept","application/json")
            conn.outputStream.use {out->
                fun write(s:String)=out.write(s.toByteArray(Charsets.UTF_8))
                fields.keys().forEach {key->require(key.matches(Regex("[a-zA-Z0-9_]+")));write("--$boundary\r\nContent-Disposition: form-data; name=\"$key\"\r\n\r\n${fields.getString(key)}\r\n")}
                photos.forEachIndexed {i,photo->require(photo.name.matches(Regex("[a-zA-Z0-9._-]+")));write("--$boundary\r\nContent-Disposition: form-data; name=\"image_$i\"; filename=\"${photo.name}\"\r\nContent-Type: image/webp\r\n\r\n");out.write(photo.bytes);write("\r\n")}
                write("--$boundary--\r\n")
            }
            val code=conn.responseCode;val stream=if(code in 200..299)conn.inputStream else conn.errorStream;val result=JSONObject(stream?.bufferedReader()?.use {it.readText()} ?: "{}");check(code in 200..299&&(!result.has("ok")||result.optBoolean("ok"))){result.text("message").ifBlank {"Senden fehlgeschlagen (HTTP $code)."}};return result
        } finally {conn.disconnect()}
    }
}
