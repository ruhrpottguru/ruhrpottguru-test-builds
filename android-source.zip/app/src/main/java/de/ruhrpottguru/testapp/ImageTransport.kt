package de.ruhrpottguru.testapp

import java.io.IOException
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Interceptor
import okhttp3.Response
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Transport only: same source/path/query, without changing selection or attribution. */
object ImageTransportPolicy {
    const val USER_AGENT="RuhrpottGuru/0.9.0 (+https://www.ruhrpottguru.de/)"
    fun secureUrl(value:String):String {
        val url=value.toHttpUrl()
        require(url.username.isEmpty()&&url.password.isEmpty()) {"Bildadresse enthält Zugangsdaten."}
        if(url.isHttps)return url.toString()
        require(url.port==80) {"Unsichere Bildadresse mit Sonderport."}
        return url.newBuilder().scheme("https").port(443).build().toString()
    }
    fun transientStatus(code:Int)=code==408||code==429||code in 500..599
}
class ImageTransportInterceptor:Interceptor {
    override fun intercept(chain:Interceptor.Chain):Response {
        val request=chain.request()
        val url=try {ImageTransportPolicy.secureUrl(request.url.toString())}catch(e:IllegalArgumentException){throw IOException("Die Bildadresse kann nicht sicher geladen werden.",e)}
        return chain.proceed(request.newBuilder().url(url).header("User-Agent",ImageTransportPolicy.USER_AGENT).build())
    }
}

object ImageTransportClient {
    fun create():OkHttpClient=OkHttpClient.Builder()
        .addInterceptor(ImageTransportInterceptor())
        .followSslRedirects(false)
        .connectTimeout(15,TimeUnit.SECONDS)
        .readTimeout(25,TimeUnit.SECONDS)
        .callTimeout(45,TimeUnit.SECONDS)
        .build()
}
