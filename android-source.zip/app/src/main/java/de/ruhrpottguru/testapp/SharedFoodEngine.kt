package de.ruhrpottguru.testapp

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.*
import org.json.JSONTokener
import java.io.ByteArrayInputStream

/** Local computation only. No remote page, script, navigation or Java bridge. */
@SuppressLint("SetJavaScriptEnabled")
class SharedFoodEngine(context: Context, onReady: (Result<Unit>) -> Unit) {
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { complete(Result.failure(IllegalStateException("Die lokale Datenlogik konnte nicht starten.")), onReady) }
    val view = WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.domStorageEnabled = false
        settings.blockNetworkLoads = true
        settings.cacheMode = WebSettings.LOAD_NO_CACHE
        importantForAccessibility = android.view.View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = true
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
            override fun onPageFinished(view: WebView, url: String) {
                if (finished) return
                val source = "window.wp={element:{}};window.ruhrpottSettings={root:'https://www.ruhrpottguru.de/wp-json/',homeUrl:'https://www.ruhrpottguru.de/',foodMediaUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/food-media',placeInfoUrl:'https://www.ruhrpottguru.de/wp-json/ruhrpottguru/v1/place-info',eventMediaDiversityEnabled:true};window.fetch=function(){return Promise.reject(new Error('Network disabled'));};\n" +
                    listOf("runtime", "api", "media-layout", "location-helpers", "category-food", "category-highlights", "category-places", "category-events", "detail-helpers", "place-events-native", "time-travel-helpers", "radar-helpers", "special-helpers", "native-adapter").joinToString("\n") {
                        context.assets.open("shared/$it.js").bufferedReader().use { r -> r.readText() }
                    }
                evaluateJavascript("(function(){try{$source\nreturn !!window.NativeFood;}catch(e){return false;}})()") { result ->
                    complete(if (result == "true") Result.success(Unit) else Result.failure(IllegalStateException("Die Datenlogik ist nicht verfügbar.")), onReady)
                }
            }
        }
    }
    init {
        handler.postDelayed(timeout, 15000)
        view.loadDataWithBaseURL("https://appassets.androidplatform.net/engine/", "<!doctype html><html><body></body></html>", "text/html", "UTF-8", null)
    }
    private fun complete(result: Result<Unit>, cb: (Result<Unit>) -> Unit) {
        if (finished) return
        finished = true; handler.removeCallbacks(timeout); cb(result)
    }
    fun call(expression: String, cb: (Result<Any?>) -> Unit) {
        view.evaluateJavascript("(function(){try{return JSON.stringify({value:($expression)});}catch(e){return JSON.stringify({error:String(e.message||e)});}})()") { raw ->
            cb(runCatching {
                val decoded = JSONTokener(raw).nextValue() as? String ?: error("Ungültige Antwort der Datenlogik")
                val obj = org.json.JSONObject(decoded)
                if (obj.has("error")) error("Die Daten konnten nicht verarbeitet werden.")
                obj.opt("value")
            })
        }
    }
    fun destroy() { handler.removeCallbacksAndMessages(null); view.stopLoading(); view.destroy() }
}
