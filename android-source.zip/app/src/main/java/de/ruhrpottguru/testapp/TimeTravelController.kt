package de.ruhrpottguru.testapp

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.*

data class TravelYear(val key:String,val label:String,val title:String,val subtitle:String,val stack:List<WmsSpec>)
data class TravelTile(val key:String,val z:Int,val x:Int,val y:Int,val level:Int,val bitmap:ImageBitmap)
class TimeTravelController(context:Context) {
    private val handler=Handler(Looper.getMainLooper())
    private val network=Executors.newFixedThreadPool(4)
    private val canceler=Executors.newSingleThreadExecutor()
    private val connections=java.util.concurrent.ConcurrentHashMap<HttpURLConnection,Int>()
    private var lastSignature:List<String>?=null
    private fun abortOldTiles(token:Int) {val old=connections.entries.filter {it.value!=token}.map {it.key};if(old.isNotEmpty())canceler.execute {old.forEach {runCatching {it.disconnect()}}}}
    private val lookup=Executors.newFixedThreadPool(2)
    private val config=JSONObject(context.assets.open("shared/time-travel.json").bufferedReader().use {it.readText()})
    val shareYears=config.getJSONArray("shareYears").let {a->(0 until a.length()).map {a.getString(it)}}
    val years:Map<String,TravelYear> = config.getJSONObject("layers").let {all->all.keys().asSequence().associateWith {key->val y=all.getJSONObject(key);TravelYear(key,key,y.text("title"),y.text("sub"),y.getJSONArray("stack").objects().map {s->val o=s.getJSONObject("opts");WmsSpec(s.getString("url"),s.getString("layer"),o.getString("version"),o.getString("format"),o.optBoolean("transparent"),o.text("time"),o.text("attribution"))})}}
    val visible=config.getJSONArray("visible").objects().map {it.text("key")to it.text("label")}
    var fullscreen by mutableStateOf(false)
    var openSerial by mutableStateOf(0);private set
    var openRequested by mutableStateOf(false);private set
    var camera by mutableStateOf(TravelCamera(51.4556,7.0116));private set
    var marker by mutableStateOf(TravelPoint(51.4556,7.0116));private set
    var year by mutableStateOf("current");private set
    var status by mutableStateOf("Start: Ruhrgebiet");private set
    var street by mutableStateOf("");private set
    var house by mutableStateOf("");private set
    var postcode by mutableStateOf("");private set
    var city by mutableStateOf("");private set
    var resolving by mutableStateOf(false);private set
    var gesturing by mutableStateOf(false);private set
    var tiles by mutableStateOf(emptyList<TravelTile>());private set
    var loading by mutableStateOf(0);private set
    var tileErrors by mutableStateOf(0);private set
    private var waitingInitialLocation=false
    private var initialized=false
    private var active=false
    @Volatile private var tileGeneration=0
    @Volatile private var searchGeneration=0
    private var disposed=false
    private val cache=object:LinkedHashMap<String,ImageBitmap>(80,.75f,true){override fun removeEldestEntry(eldest:MutableMap.MutableEntry<String,ImageBitmap>?)=size>80}
    val selected get()=years.getValue(year)
    fun open(point:GuruLocation?) {active=true;if(!initialized){initialized=true;waitingInitialLocation=point==null;if(point!=null)move(point.lat,point.lng,"Start: "+point.label)}}
    fun pause() {fullscreen=false;active=false;tileGeneration++;lastSignature=null;abortOldTiles(tileGeneration);searchGeneration++;resolving=false;loading=0;gesturing=false}
    fun acceptRestoredLocation(point:GuruLocation?) {if(waitingInitialLocation&&point!=null){waitingInitialLocation=false;move(point.lat,point.lng,"Start: "+point.label)}}
    fun setFields(st:String=street,number:String=house,zip:String=postcode,place:String=city) {waitingInitialLocation=false;searchGeneration++;resolving=false;street=st;house=number;postcode=zip;city=place;status=""}
    fun clear() {waitingInitialLocation=false;searchGeneration++;resolving=false;street="";house="";postcode="";city="";status="Suchfelder geleert. Die Karte bleibt an der aktuellen Position."}
    fun useGlobal(point:GuruLocation?) {if(point!=null){clear();move(point.lat,point.lng,point.label)}}
    private fun move(lat:Double,lng:Double,label:String) {if(!TravelGeometry.valid(lat,lng))return;camera=TravelCamera(lat,lng,17.0);marker=TravelPoint(lat,lng);status=label}
    fun chooseYear(key:String) {if(key in years&&key!=year){tileGeneration++;lastSignature=null;abortOldTiles(tileGeneration);tiles=emptyList();year=key;tileErrors=0}}
    fun beginGesture() {waitingInitialLocation=false;searchGeneration++;resolving=false;gesturing=true}
    fun transform(width:Double,height:Double,cx:Double,cy:Double,panX:Double,panY:Double,scale:Double) {camera=TravelGeometry.transform(camera,width,height,cx,cy,panX,panY,scale)}
    fun endGesture() {camera=camera.copy(zoom=round(camera.zoom).coerceIn(9.0,20.0));gesturing=false}
    fun zoom(delta:Int) {searchGeneration++;resolving=false;camera=camera.copy(zoom=(round(camera.zoom)+delta).coerceIn(9.0,20.0))}
    fun applyLink(value:String):Boolean {val s=TravelGeometry.parseLink(value,shareYears);if(s==null){status="Das ist kein gültiger RuhrpottGuru-Zeitreise-Link.";return false};waitingInitialLocation=false;searchGeneration++;resolving=false;initialized=true;street="";house="";postcode="";city="";camera=TravelCamera(s.lat,s.lng,s.zoom.toDouble());marker=TravelPoint(s.markerLat,s.markerLng);tiles=emptyList();tileGeneration++;lastSignature=null;abortOldTiles(tileGeneration);year=s.year;status="Geteilte Ansicht";return true}
    fun shareState()=JSONObject().put("lat",camera.lat).put("lng",camera.lng).put("zoom",round(camera.zoom).toInt()).put("year",year).put("markerLat",marker.lat).put("markerLng",marker.lng)
    fun cancelSearch() {searchGeneration++;resolving=false}
    fun consumeOpenRequest() {openRequested=false}
    fun receiveLink(value:String) {applyLink(value);openRequested=true;openSerial++}
    fun search(engine:SharedFoodEngine,onMove:()->Unit={}) {
        waitingInitialLocation=false;val token=++searchGeneration
        val input=JSONObject().put("street",street).put("number",house).put("zip",postcode).put("city",city)
        engine.call("rpgTimeSearch($input)") {result->
            if(token!=searchGeneration||!active||disposed)return@call
            val action=result.getOrNull() as? JSONObject ?: run {status="Die Zeitreise-Suche konnte nicht vorbereitet werden.";return@call}
            action.optJSONObject("fields")?.let {street=it.text("street");house=it.text("number");postcode=it.text("zip");city=it.text("city")}
            status=action.text("status")
            when(action.text("kind")) {
                "move"->{move(action.optDouble("lat"),action.optDouble("lng"),action.text("label"));onMove()}
                "postcode","address"->{
                    val address=action.text("kind")=="address";val path=if(address)"address-location" else "postcode-location"
                    if(action.text("url").let {it!=API_ROOT+path&&it!="/wp-json/ruhrpottguru/v1/$path"}){status="Die Zeitreise-Suche ist nicht verfügbar.";return@call}
                    val body=action.optJSONObject("body") ?: return@call;resolving=true
                    lookup.execute {
                        val response=runCatching {val nonce=if(address)http("address-location-token",null).text("token").also {check(it.isNotBlank()){"Adresssuche konnte nicht gestartet werden."}} else null;http(path,body,nonce)}
                        handler.post {
                            if(token!=searchGeneration||!active||disposed)return@post
                            resolving=false
                            response.onSuccess {data->val lat=data.optDouble("lat");val lng=data.optDouble("lng");if(TravelGeometry.valid(lat,lng)){move(lat,lng,if(address)data.text("label").ifBlank {listOf(street,house,postcode,city).filter {it.isNotBlank()}.joinToString(" · ")} else "PLZ "+body.text("postcode"));onMove()} else status="Für diese Eingabe wurde kein Standort gefunden."}.onFailure {status=it.message ?: "Der gewünschte Ort konnte gerade nicht aufgelöst werden."}
                        }
                    }
                }
            }
        }
    }
    fun loadTiles(width:Double,height:Double) {
        if(!active||disposed||gesturing||width<=0||height<=0)return
        val z=floor(camera.zoom).toInt().coerceIn(9,20);val factor=2.0.pow(camera.zoom-z);val center=TravelGeometry.world(camera.lat,camera.lng,z.toDouble());val n=1 shl z
        val left=floor((center.x-width/2/factor)/256).toInt();val right=floor((center.x+width/2/factor)/256).toInt();val top=floor((center.y-height/2/factor)/256).toInt().coerceIn(0,n-1);val bottom=floor((center.y+height/2/factor)/256).toInt().coerceIn(0,n-1)
        data class Request(val url:String,val x:Int,val y:Int,val level:Int)
        val requests=selected.stack.flatMapIndexed {level,spec->(top..bottom).flatMap {y->(left..right).map {x->val wrapped=((x%n)+n)%n;Request(TravelGeometry.tileUrl(spec,z,wrapped,y),wrapped,y,level)}}}.distinctBy {it.url}
        val signature=requests.map {it.url}.sorted()
        if(lastSignature==signature&&(loading>0||(tileErrors==0&&tiles.isNotEmpty())))return
        lastSignature=signature;val token=++tileGeneration;abortOldTiles(token)
        tileErrors=0
        tiles=requests.mapNotNull {r->synchronized(cache){cache[r.url]}?.let {TravelTile(r.url,z,r.x,r.y,r.level,it)}}
        val missing=requests.filter {r->synchronized(cache){!cache.containsKey(r.url)}};loading=missing.size
        missing.forEach {r->network.execute {
            if(token!=tileGeneration||disposed)return@execute
            val image=runCatching {val conn=URL(r.url).openConnection() as HttpURLConnection;connections[conn]=token;try {check(token==tileGeneration&&!disposed);conn.connectTimeout=12000;conn.readTimeout=20000;conn.instanceFollowRedirects=false;conn.setRequestProperty("Accept","image/jpeg,image/png");check(conn.responseCode in 200..299);check(conn.contentType.orEmpty().startsWith("image/"));val bytes=conn.inputStream.use {input->val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192);while(true){val read=input.read(buffer);if(read<0)break;check(out.size()+read<=2*1024*1024);out.write(buffer,0,read)};out.toByteArray()};val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size) ?: error("Kachel nicht lesbar");check(bitmap.width==256&&bitmap.height==256);bitmap.asImageBitmap()}finally{connections.remove(conn);conn.disconnect()}}
            image.onSuccess {bitmap->synchronized(cache){cache[r.url]=bitmap}}
            handler.post {if(token==tileGeneration&&!disposed){loading=(loading-1).coerceAtLeast(0);image.onSuccess {tiles=(tiles+TravelTile(r.url,z,r.x,r.y,r.level,it)).sortedBy {t->t.level}}.onFailure {tileErrors++}}}
        }}
    }
    private fun http(path:String,body:JSONObject?,token:String?=null):JSONObject {
        val conn=URL(API_ROOT+path).openConnection() as HttpURLConnection
        try {conn.connectTimeout=15000;conn.readTimeout=25000;conn.useCaches=false;conn.instanceFollowRedirects=false;conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("Cache-Control","no-store");token?.let {conn.setRequestProperty("X-RPG-Address-Token",it)};if(body!=null){conn.requestMethod="POST";conn.doOutput=true;conn.setRequestProperty("Content-Type","application/json; charset=utf-8");conn.outputStream.use {it.write(body.toString().toByteArray(Charsets.UTF_8))}};val code=conn.responseCode;val stream=if(code in 200..299)conn.inputStream else conn.errorStream;val data=JSONObject(stream?.bufferedReader()?.use {it.readText()} ?: "{}");check(code in 200..299&&(!data.has("ok")||data.optBoolean("ok"))){data.text("message").ifBlank {"Ort konnte gerade nicht aufgelöst werden (HTTP $code)."}};return data}finally{conn.disconnect()}
    }
    fun close() {disposed=true;pause();network.shutdownNow();lookup.shutdownNow();canceler.shutdown();handler.removeCallbacksAndMessages(null);synchronized(cache){cache.clear()}}
}
