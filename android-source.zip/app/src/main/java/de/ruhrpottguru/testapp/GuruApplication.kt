package de.ruhrpottguru.testapp

import android.app.Application
import android.content.Context
import coil3.ImageLoader
import coil3.SingletonImageLoader
import coil3.network.okhttp.OkHttpNetworkFetcherFactory

/** Shared by every AsyncImage: lists, galleries, saved places and radar tiles. */
class GuruApplication:Application(),SingletonImageLoader.Factory {
    override fun newImageLoader(context:Context):ImageLoader {
        val client=ImageTransportClient.create()
        return ImageLoader.Builder(context).components {add(OkHttpNetworkFetcherFactory(callFactory=client))}.build()
    }
}
