package de.ruhrpottguru.testapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/** A one-shot fresh fix; never reads lastKnownLocation. */
class FreshGps(private val context: Context) {
    private val manager=context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val handler=Handler(Looper.getMainLooper())
    private var listener: LocationListener?=null
    private var sequence=0
    var active=false;private set
    fun cancel() { sequence++;active=false;listener?.let { manager.removeUpdates(it) };listener=null;handler.removeCallbacksAndMessages(null) }
    fun request(onFix: (Double,Double)->Unit, onError: (String)->Unit) {
        cancel();val token=sequence;val started=SystemClock.elapsedRealtimeNanos()
        val fine=context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        val coarse=context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        if(!fine && !coarse) {onError("Standortfreigabe fehlt. Du kannst auch Stadt, PLZ oder Adresse auswählen.");return}
        val providers=listOfNotNull(LocationManager.NETWORK_PROVIDER.takeIf { manager.isProviderEnabled(it) },LocationManager.GPS_PROVIDER.takeIf { fine && manager.isProviderEnabled(it) })
        if(providers.isEmpty()) {onError("Bitte die Standortdienste einschalten oder einen Standort eingeben.");return}
        active=true
        val observer=object:LocationListener {
            override fun onLocationChanged(fix: Location) {
                if(!active || sequence!=token || fix.elapsedRealtimeNanos<started || !fix.latitude.isFinite() || !fix.longitude.isFinite())return
                cancel();onFix(fix.latitude,fix.longitude)
            }
            @Deprecated("Legacy callback") override fun onStatusChanged(provider: String?,status: Int,extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        listener=observer
        try {
            providers.forEach { manager.requestLocationUpdates(it,0L,0f,observer,Looper.getMainLooper()) }
            handler.postDelayed({if(active && sequence==token){cancel();onError("Noch kein frischer GPS-Standort. Bitte erneut versuchen oder Stadt/PLZ nutzen.")}},10000)
        } catch(_:SecurityException) {cancel();onError("Die Standortfreigabe wurde entzogen. Bitte erneut auswählen.")}
    }
}
