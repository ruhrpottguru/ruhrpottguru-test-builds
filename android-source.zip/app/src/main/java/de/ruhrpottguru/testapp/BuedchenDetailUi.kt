package de.ruhrpottguru.testapp

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

@OptIn(ExperimentalLayoutApi::class)
@Composable fun BuedchenDetailScreen(item:JSONObject,c:FoodController,onPhotoFailure:(String)->Unit,external:(String)->Unit) {
    val special=item.optJSONObject("special") ?: JSONObject()
    var share by remember(item.text("id")){mutableStateOf<String?>(null)}
    var form by remember(item.text("id")){mutableStateOf(false)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        PlacePhoto(item,detail=true,onFailure=onPhotoFailure,external=external)
        Text(item.text("title"),fontSize=28.sp,fontWeight=FontWeight.Bold)
        Text(item.text("address").ifBlank {item.text("city")})
        Text(item.text("distance"))
        Text(special.optJSONObject("opening")?.text("label").orEmpty().ifBlank {"Öffnungszeiten nicht bekannt"})
        FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {special.optJSONArray("features")?.objects().orEmpty().forEach {Text(it.text("label"),Modifier.padding(6.dp))}}
        val origin=c.location;val coords=item.optJSONObject("coords")
        val route=if(origin!=null&&coords!=null)"https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${origin.lat},${origin.lng}%3B${coords.optDouble("lat")},${coords.optDouble("lng")}" else ""
        FlowRow(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Action(route,"Route öffnen",external);Action(item.text("website"),"Website",external)
            OutlinedButton(onClick={share="share"}){Text("Teilen")}
            OutlinedButton(onClick={share="invite"}){Text("🍻 Komm rum, ich bin hier!")}
            OutlinedButton(onClick={c.toggleSaved(item)}){Text(if(c.isSaved(item))"♥ Gemerkt" else "♡ Merken")}
        }
        DetailBlock("Öffnungszeiten") {Text(special.text("formatted").ifBlank {"Öffnungszeiten nicht bekannt. Weißt du mehr? Hilf mit, den Radar besser zu machen."})}
        if(item.text("description").isNotBlank())DetailBlock("Über dieses Büdchen") {Text(item.text("description"))}
        Text("Gemeinsam fürs Revier",fontWeight=FontWeight.Bold)
        OutlinedButton(onClick={form=true}){Text("Daten ergänzen oder Bild hochladen")}
    }
    share?.let {DetailShareDialog(item,c,it){share=null}}
    if(form)DetailContributionDialog(item,c,"contribution"){form=false}
}
