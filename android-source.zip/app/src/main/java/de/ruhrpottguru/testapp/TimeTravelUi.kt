package de.ruhrpottguru.testapp

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.math.*

@Composable
fun TimeTravelScreen(c:FoodController,onLocation:()->Unit,external:(String)->Unit) {
    val t=c.timeTravel;val context=LocalContext.current;val density=LocalDensity.current.density
    var mapSize by remember {mutableStateOf(IntSize.Zero)}
    var linkError by remember {mutableStateOf("")}
    var search by remember {mutableStateOf(false)};var paste by remember {mutableStateOf(false)};var link by remember {mutableStateOf("")};var credits by remember {mutableStateOf(false)}
    var retry by remember {mutableIntStateOf(0)}
    DisposableEffect(Unit) {t.open(c.location);onDispose {t.pause()}}
    val initialSerial=remember {c.contextSerial}
    LaunchedEffect(c.location) {t.acceptRestoredLocation(c.location)}
    LaunchedEffect(c.contextSerial) {if(c.contextSerial!=initialSerial)t.useGlobal(c.location)}
    LaunchedEffect(t.camera,t.year,mapSize,t.gesturing,retry) {if(!t.gesturing)t.loadTiles(mapSize.width/density.toDouble(),mapSize.height/density.toDouble())}
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text("Zeitreise von oben",fontSize=23.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),maxLines=1,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            IconButton(onClick={t.fullscreen=!t.fullscreen},modifier=Modifier.semantics {contentDescription=if(t.fullscreen)"Vollbild beenden" else "Karte im Vollbild anzeigen"}){Text("⛶",fontSize=25.sp,color=Color(0xFFF59E0B))}
            IconButton(enabled=c.ready,onClick={c.engine.call("rpgTimeShare(${t.shareState()})") {result->(result.getOrNull() as? String)?.let {url->context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"RuhrpottGuru · Zeitreise von oben");putExtra(Intent.EXTRA_TEXT,url)},"Aktuellen Kartenausschnitt teilen"))}}},modifier=Modifier.semantics {contentDescription="Aktuellen Kartenausschnitt teilen"}){Text("↗",fontSize=25.sp,color=Color(0xFFF59E0B))}
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            t.visible.forEach {(key,label)->FilterChip(selected=t.year==key,onClick={t.chooseYear(key)},label={Text(label)})}
            if(t.visible.none {it.first==t.year})FilterChip(selected=true,onClick={},label={Text(t.year+" · geteilter Stand")})
        }
        Text(t.selected.title,fontWeight=FontWeight.Bold,fontSize=14.sp)
        if(!t.fullscreen)Text(t.selected.subtitle,fontSize=12.sp,color=Color(0xFFB6C2D3))
        if(!t.fullscreen)Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            OutlinedButton(onClick={search=true}){Text("Ort / PLZ / Adresse")}
            TextButton(onClick={if(c.location!=null)t.useGlobal(c.location) else onLocation()}){Text(if(c.location!=null)"App-Standort" else "GPS / Standort")}
        }
        if(!t.fullscreen&&t.status.isNotBlank())Text(t.status,fontSize=12.sp)
        Box(Modifier.fillMaxWidth().weight(1f).clipToBounds().background(Color(0xFF122034)).onSizeChanged {mapSize=it}) {
            val width=mapSize.width/density.toDouble();val height=mapSize.height/density.toDouble()
            fun pan(x:Double,y:Double):Boolean {t.beginGesture();t.transform(width,height,width/2,height/2,x,y,1.0);t.endGesture();return true}
            Canvas(Modifier.fillMaxSize().semantics {
                contentDescription="Luftbildkarte, ${t.selected.title}. Verschieben mit einem Finger, Zoomen mit zwei Fingern oder den Zoomtasten."
                customActions=listOf(CustomAccessibilityAction("Nach Norden verschieben"){pan(0.0,80.0)},CustomAccessibilityAction("Nach Süden verschieben"){pan(0.0,-80.0)},CustomAccessibilityAction("Nach Osten verschieben"){pan(-80.0,0.0)},CustomAccessibilityAction("Nach Westen verschieben"){pan(80.0,0.0)})
            }.pointerInput(t,density) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed=false);t.beginGesture()
                    do {
                        val event=awaitPointerEvent();val centroid=event.calculateCentroid(useCurrent=true);val delta=event.calculatePan();val zoom=event.calculateZoom()
                        if(centroid.isSpecified)t.transform(size.width/density.toDouble(),size.height/density.toDouble(),centroid.x/density.toDouble(),centroid.y/density.toDouble(),delta.x/density.toDouble(),delta.y/density.toDouble(),zoom.toDouble())
                        event.changes.forEach {if(it.positionChanged())it.consume()}
                    }while(event.changes.any {it.pressed})
                    t.endGesture()
                }
            }) {
                for(tile in t.tiles) {
                    val center=TravelGeometry.world(t.camera.lat,t.camera.lng,tile.z.toDouble());val scale=2.0.pow(t.camera.zoom-tile.z);val world=256*2.0.pow(tile.z)
                    var dx=tile.x*256-center.x;if(dx>world/2)dx-=world;if(dx< -world/2)dx+=world
                    val px=dx*scale*density+size.width/2;val py=(tile.y*256-center.y)*scale*density+size.height/2;val edge=ceil(256*scale*density).toInt()+1
                    drawImage(tile.bitmap,srcOffset=IntOffset.Zero,srcSize=IntSize(tile.bitmap.width,tile.bitmap.height),dstOffset=IntOffset(px.roundToInt(),py.roundToInt()),dstSize=IntSize(edge,edge))
                }
                val center=TravelGeometry.world(t.camera.lat,t.camera.lng,t.camera.zoom);val mark=TravelGeometry.world(t.marker.lat,t.marker.lng,t.camera.zoom);val world=256*2.0.pow(t.camera.zoom)
                var dx=mark.x-center.x;if(dx>world/2)dx-=world;if(dx< -world/2)dx+=world
                val position=Offset((size.width/2+dx*density).toFloat(),(size.height/2+(mark.y-center.y)*density).toFloat())
                drawCircle(Color(0xFFF59E0B),7*density,position);drawCircle(Color(0xFF111111),7*density,position,style=Stroke(3*density))
            }
            Column(Modifier.align(Alignment.TopEnd).padding(8.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                FilledIconButton(onClick={t.zoom(1)},enabled=t.camera.zoom<20,modifier=Modifier.semantics {contentDescription="Luftbild vergrößern"}){Text("+",fontSize=25.sp)}
                FilledIconButton(onClick={t.zoom(-1)},enabled=t.camera.zoom>9,modifier=Modifier.semantics {contentDescription="Luftbild verkleinern"}){Text("−",fontSize=25.sp)}
            }
            if(t.loading>0)LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            if(t.tiles.isEmpty()&&t.loading==0&&t.tileErrors==0)Text("Luftbilder werden vorbereitet …",Modifier.align(Alignment.Center).padding(18.dp))
            Surface(color=Color(0xDD07111F),modifier=Modifier.align(Alignment.BottomStart)) {Text(t.selected.stack.map {it.attribution}.distinct().joinToString(" · "),Modifier.padding(5.dp),fontSize=10.sp)}
        }
        if(t.tileErrors>0)Row(verticalAlignment=Alignment.CenterVertically) {Text("Luftbild für diesen Ausschnitt nicht vollständig geladen.",Modifier.weight(1f),fontSize=12.sp);TextButton(onClick={retry++}){Text("Erneut laden")}}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {Text("Historische Abdeckung kann Lücken haben.",fontSize=11.sp,color=Color(0xFFB6C2D3));TextButton(onClick={credits=true}){Text("Quellen")}}
    }
    if(search)AlertDialog(onDismissRequest={t.cancelSearch();search=false},title={Text("Ort für die Zeitreise")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Diese Suche ändert deinen globalen App-Standort nicht.")
        OutlinedTextField(t.street,{t.setFields(st=it)},label={Text("Straße (optional)")},singleLine=true)
        OutlinedTextField(t.house,{t.setFields(number=it)},label={Text("Hausnummer (optional)")},singleLine=true)
        OutlinedTextField(t.postcode,{t.setFields(zip=it.filter {ch->ch.isDigit()}.take(5))},label={Text("PLZ (optional)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        OutlinedTextField(t.city,{t.setFields(place=it)},label={Text("Ort (optional)")},singleLine=true)
        if(t.resolving)LinearProgressIndicator(Modifier.fillMaxWidth());if(t.status.isNotBlank())Text(t.status,fontSize=12.sp)
        TextButton(onClick=t::clear){Text("Felder leeren")}
    }},dismissButton={TextButton(onClick={t.cancelSearch();search=false}){Text("Schließen")}},confirmButton={TextButton(enabled=c.ready&&!t.resolving,onClick={t.search(c.engine){search=false}}){Text("Suchen")}})
    if(paste)AlertDialog(onDismissRequest={paste=false},title={Text("Geteilten Zeitreise-Link öffnen")},text={Column {OutlinedTextField(link,{link=it},label={Text("RuhrpottGuru-Link")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Uri));Text("Unterstützt /z/-Links und bisherige Zeitreise-Links.",fontSize=12.sp);if(linkError.isNotBlank())Text(linkError,color=MaterialTheme.colorScheme.error)}},dismissButton={TextButton(onClick={paste=false}){Text("Abbrechen")}},confirmButton={TextButton(onClick={if(t.applyLink(link)){paste=false;link=""}else linkError=t.status}){Text("Öffnen")}})
    if(credits)AlertDialog(onDismissRequest={credits=false},title={Text("Luftbilder & Nachweise")},text={Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(t.selected.title);Text(t.selected.subtitle)
        t.selected.stack.forEach {spec->Text(spec.attribution);Action(spec.url,"WMS-Datenquelle öffnen",external)}
        if(t.selected.stack.any {it.url.contains("geodaten.metropoleruhr.de")}) {Text("Regionalverband Ruhr · Datenlizenz Deutschland – Namensnennung 2.0");Action("https://www.govdata.de/dl-de/by-2-0","RVR-Lizenzbedingungen",external)}
        if(t.selected.stack.any {it.attribution.contains("Zero 2.0")})Action("https://www.govdata.de/dl-de/zero-2-0","NRW-Lizenzbedingungen",external)
        Text("Kartentechnik nach Leaflet 1.9.4 · BSD 2-Clause",fontWeight=FontWeight.Bold)
        Text(remember {context.assets.open("third-party/Leaflet-LICENSE.txt").bufferedReader().use {it.readText()}},fontSize=11.sp)
        TextButton(onClick={credits=false;linkError="";paste=true}){Text("Geteilten Zeitreise-Link öffnen")}
        Action("https://www.ruhrpottguru.de/zeitreise-von-oben/","Zeitreise im Browser öffnen",external)
    }},confirmButton={TextButton(onClick={credits=false}){Text("Schließen")}})
}
