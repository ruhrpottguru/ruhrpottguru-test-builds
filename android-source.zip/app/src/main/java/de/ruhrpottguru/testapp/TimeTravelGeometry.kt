package de.ruhrpottguru.testapp

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.util.Base64
import kotlin.math.*

data class TravelPoint(val lat:Double,val lng:Double)
data class TravelCamera(val lat:Double,val lng:Double,val zoom:Double=17.0)
data class TravelPixel(val x:Double,val y:Double)
data class TravelShare(val lat:Double,val lng:Double,val zoom:Int,val year:String,val markerLat:Double,val markerLng:Double)
data class WmsSpec(val url:String,val layer:String,val version:String,val format:String,val transparent:Boolean,val time:String="",val attribution:String="")

/** Leaflet1.9.4 EPSG:3857, 256 CSS-pixel tile grid, unchanged WMS axis order. */
object TravelGeometry {
    const val MAX_LAT=85.0511287798
    const val R=6378137.0
    fun project(lat:Double,lng:Double):TravelPixel {val s=sin(lat.coerceIn(-MAX_LAT,MAX_LAT)*PI/180);return TravelPixel(R*lng*PI/180,R*ln((1+s)/(1-s))/2)}
    fun world(lat:Double,lng:Double,zoom:Double):TravelPixel {val p=project(lat,lng);val size=256*2.0.pow(zoom);return TravelPixel((p.x/(2*PI*R)+.5)*size,(.5-p.y/(2*PI*R))*size)}
    fun point(x:Double,y:Double,zoom:Double):TravelPoint {val size=256*2.0.pow(zoom);val mx=(x/size-.5)*2*PI*R;val my=(.5-y.coerceIn(0.0,size)/size)*2*PI*R;return TravelPoint((2*atan(exp(my/R))-PI/2)*180/PI,((mx*180/PI/R+180)%360+360)%360-180)}
    fun transform(camera:TravelCamera,width:Double,height:Double,cx:Double,cy:Double,panX:Double,panY:Double,scale:Double):TravelCamera {
        if(!scale.isFinite()||scale<=0)return camera
        val z=(camera.zoom+ln(scale)/ln(2.0)).coerceIn(9.0,20.0);val factor=2.0.pow(z-camera.zoom);val old=world(camera.lat,camera.lng,camera.zoom)
        val p=point((old.x+cx-panX-width/2)*factor-(cx-width/2),(old.y+cy-panY-height/2)*factor-(cy-height/2),z)
        return TravelCamera(p.lat,p.lng,z)
    }
    fun bounds(z:Int,x:Int,y:Int):List<Double> {require(z in 9..20);val n=1 shl z;require(x in 0 until n&&y in 0 until n);val span=2*PI*R/n;return listOf(-PI*R+x*span,PI*R-(y+1)*span,-PI*R+(x+1)*span,PI*R-y*span)}
    fun tileUrl(spec:WmsSpec,z:Int,x:Int,y:Int):String {
        require(spec.url.startsWith("https://geodaten.metropoleruhr.de/")||spec.url.startsWith("https://www.wms.nrw.de/geobasis/"))
        val values=linkedMapOf("service" to "WMS","request" to "GetMap","layers" to spec.layer,"styles" to "","format" to spec.format,"transparent" to spec.transparent.toString(),"version" to spec.version,"width" to "256","height" to "256",(if(spec.version.startsWith("1.3"))"crs" else "srs") to "EPSG:3857")
        if(spec.time.isNotBlank())values["time"]=spec.time
        fun enc(s:String)=URLEncoder.encode(s,"UTF-8").replace("+","%20")
        return spec.url+(if(spec.url.contains('?'))"&" else "?")+values.entries.joinToString("&"){enc(it.key)+"="+enc(it.value)}+"&bbox="+bounds(z,x,y).joinToString(",")
    }
    fun parseLink(value:String,years:List<String>):TravelShare?=runCatching {
        val uri=URI(value.trim());require(uri.scheme?.lowercase()in listOf("https","http"));require(uri.host?.lowercase()in listOf("www.ruhrpottguru.de","ruhrpottguru.de"));require(uri.userInfo==null&&uri.port in listOf(-1,80,443))
        val short=Regex("^/z/([A-Za-z0-9_-]{24})/?$").matchEntire(uri.path.orEmpty())
        if(short!=null) {
            val bytes=Base64.getUrlDecoder().decode(short.groupValues[1]);require(bytes.size==18);val b=ByteBuffer.wrap(bytes);val lat=b.int/100000.0;val lng=b.int/100000.0;val ml=b.int/100000.0;val mn=b.int/100000.0;val zoom=b.get().toInt() and 255;val index=b.get().toInt() and 255
            require(zoom in 9..20&&index in years.indices&&valid(lat,lng)&&valid(ml,mn));TravelShare(lat,lng,zoom,years[index],ml,mn)
        } else {
            require(uri.path.orEmpty().trimEnd('/')=="/zeitreise-von-oben")
            val params=uri.rawQuery.orEmpty().split('&').mapNotNull {val pair=it.split('=',limit=2);if(pair.size==2)URLDecoder.decode(pair[0],"UTF-8")to URLDecoder.decode(pair[1],"UTF-8")else null}.toMap()
            val lat=params["zvo_lat"]?.toDoubleOrNull() ?: error("Koordinate fehlt");val lng=params["zvo_lng"]?.toDoubleOrNull() ?: error("Koordinate fehlt");require(valid(lat,lng));val year=params["zvo_y"].takeIf {it in years} ?: "current"
            val zoom=params["zvo_z"]?.toIntOrNull()?.takeIf {it in 9..20} ?:17
            val ml=params["zvo_mlat"]?.toDoubleOrNull();val mn=params["zvo_mlng"]?.toDoubleOrNull();val marker=if(ml!=null&&mn!=null&&valid(ml,mn))TravelPoint(ml,mn)else TravelPoint(lat,lng)
            TravelShare(lat,lng,zoom,year,marker.lat,marker.lng)
        }
    }.getOrNull()
    fun valid(lat:Double,lng:Double)=lat.isFinite()&&lng.isFinite()&&abs(lat)<=90&&abs(lng)<=180
}
