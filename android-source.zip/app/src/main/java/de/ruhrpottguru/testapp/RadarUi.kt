package de.ruhrpottguru.testapp

import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.*
import coil3.compose.AsyncImage
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.math.*

val BudeFilterLabels=listOf("open" to "Jetzt geöffnet","lottery" to "Lotto","mixed_candy" to "Gemischte Tüte","coffee" to "Kaffee","seating" to "Sitzplätze","parcel_shop" to "Paketshop")
val WurstFilterLabels=listOf("currywurst" to "Currywurst","pommes" to "Pommes-Schmiede","schnitzel" to "Aus der Pfanne","frikadelle" to "Wie bei Omma","schaschlik" to "Schaschlik","bratwurst" to "Bratwurst")

@Composable fun RadarFilters(c:FoodController) {
    if(c.category=="buedchen") {
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {BudeFilterLabels.forEach {(id,label)->FilterChip(selected=c.radarFilters.optBoolean(id),onClick={c.toggleRadarFilter(id)},label={Text(label)},enabled=!c.loading)}}
        if(c.radarFilters.keys().asSequence().any {c.radarFilters.optBoolean(it)})TextButton(onClick=c::clearRadarFilters){Text("Filter zurücksetzen")}
        Text("Radar · Karte mit zwei Fingern bewegen und zoomen",fontSize=12.sp)
        BuedchenMap(c)
        if(c.radarMoved)Text("Kartenausschnitt · globaler Standort bleibt erhalten",fontSize=12.sp)
    } else {
        val available=c.tags.map {it.text("slug")}.toSet()
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            FilterChip(selected=c.tag.isBlank(),onClick={c.setFilters(selectedTag="")},label={Text("Alle")},enabled=!c.loading)
            WurstFilterLabels.filter {it.first in available}.forEach {(id,label)->FilterChip(selected=c.tag==id,onClick={c.setFilters(selectedTag=id)},label={Text(label)},enabled=!c.loading)}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {FilterChip(selected=c.radarSort=="distance",onClick={c.sortRadar("distance")},label={Text("Entfernung")},enabled=!c.loading);FilterChip(selected=c.radarSort=="new",onClick={c.sortRadar("new")},label={Text("Neu im Radar")},enabled=!c.loading)}
        if(c.radarStats.optInt("verifiedTotal")>0)Text("${c.radarStats.optInt("verifiedTotal")} redaktionell geprüft (gesamt)",fontSize=12.sp)
    }
}

@Composable fun BuedchenMap(c:FoodController) {
    val location=c.location ?: return
    val context=LocalContext.current
    val density=LocalDensity.current.density
    var size by remember {mutableStateOf(IntSize.Zero)}
    var gesture by remember {mutableStateOf(false)}
    var dirty by remember {mutableStateOf(false)}
    var request by remember {mutableIntStateOf(0)}
    var tileFailed by remember(c.contextSerial,c.radarCamera?.zoom) {mutableStateOf(false)}
    var retry by remember {mutableIntStateOf(0)}
    val camera=c.radarCamera ?: TravelCamera(location.lat,location.lng,RadarGeometry.initialZoom(c.radius))
    val width=size.width/density.toDouble();val height=size.height/density.toDouble()
    LaunchedEffect(request) {if(request>0){delay(350);if(!gesture)c.radarCamera?.let {c.loadRadarViewport(it,width,height)}}}
    fun change(next:TravelCamera,commit:Boolean) {c.radarCamera=next.copy(zoom=next.zoom.coerceIn(10.0,18.0));dirty=true;if(commit){request++;dirty=false}}
    Box(Modifier.fillMaxWidth().height(330.dp).clipToBounds().background(Color(0xFF152536)).onSizeChanged {size=it}) {
        val z=floor(camera.zoom).toInt();val scale=2.0.pow(camera.zoom-z);val tile=256*scale;val world=TravelGeometry.world(camera.lat,camera.lng,z.toDouble())
        val minX=floor((world.x-width/(2*scale))/256).toInt();val maxX=floor((world.x+width/(2*scale))/256).toInt()
        val minY=max(0,floor((world.y-height/(2*scale))/256).toInt());val maxY=min((1 shl z)-1,floor((world.y+height/(2*scale))/256).toInt())
        if(size.width>0)for(x in minX..maxX)for(y in minY..maxY)key(z,x,y,retry) {
            AsyncImage(model=RadarGeometry.tileUrl(z,x,y),contentDescription=null,contentScale=ContentScale.FillBounds,onError={tileFailed=true},modifier=Modifier.offset {IntOffset(((x*256-world.x)*scale*density+size.width/2).roundToInt(),((y*256-world.y)*scale*density+size.height/2).roundToInt())}.size(tile.toFloat().dp))
        }
        Canvas(Modifier.fillMaxSize().semantics {contentDescription="Büdchenkarte. Mit zwei Fingern verschieben und zoomen.";customActions=listOf(CustomAccessibilityAction("Nach Norden"){change(camera.copy(lat=TravelGeometry.point(world.x,world.y-120,z.toDouble()).lat),true);true},CustomAccessibilityAction("Nach Süden"){change(camera.copy(lat=TravelGeometry.point(world.x,world.y+120,z.toDouble()).lat),true);true},CustomAccessibilityAction("Nach Osten"){change(camera.copy(lng=TravelGeometry.point(world.x+120,world.y,z.toDouble()).lng),true);true},CustomAccessibilityAction("Nach Westen"){change(camera.copy(lng=TravelGeometry.point(world.x-120,world.y,z.toDouble()).lng),true);true})}.pointerInput(c,density) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed=false)
                do {
                    val e=awaitPointerEvent()
                    if(e.changes.count {it.pressed}>=2) {
                        gesture=true;val center=e.calculateCentroid();val pan=e.calculatePan();val zoom=e.calculateZoom()
                        val current=c.radarCamera ?: TravelCamera(location.lat,location.lng,RadarGeometry.initialZoom(c.radius))
                        c.radarCamera=TravelGeometry.transform(current,size.width/density.toDouble(),size.height/density.toDouble(),center.x/density.toDouble(),center.y/density.toDouble(),pan.x/density.toDouble(),pan.y/density.toDouble(),zoom.toDouble()).let {it.copy(zoom=it.zoom.coerceIn(10.0,18.0))};dirty=true
                        e.changes.forEach {if(it.positionChanged())it.consume()}
                    }
                }while(e.changes.any {it.pressed})
                if(gesture){gesture=false;c.radarCamera=c.radarCamera?.let {it.copy(zoom=it.zoom.roundToInt().toDouble())};if(dirty){request++;dirty=false}}
            }
        }) {
            val user=TravelGeometry.world(location.lat,location.lng,camera.zoom);val cam=TravelGeometry.world(camera.lat,camera.lng,camera.zoom)
            val center=Offset(((user.x-cam.x)*density+this.size.width/2).toFloat(),((user.y-cam.y)*density+this.size.height/2).toFloat())
            if(!c.radarMoved&&!dirty&&!gesture)drawCircle(Color(0xFFF59E0B).copy(alpha=.15f),(c.radius*1000/(cos(location.lat*PI/180)*156543.03392/2.0.pow(camera.zoom))*density).toFloat(),center)
            drawCircle(Color.White,7.dp.toPx(),center);drawCircle(Color(0xFF3898FF),5.dp.toPx(),center)
        }
        val coords=c.radarMapItems.mapNotNull {item->item.optJSONObject("coords")?.let {point->val p=TravelGeometry.world(point.optDouble("lat"),point.optDouble("lng"),camera.zoom);val center=TravelGeometry.world(camera.lat,camera.lng,camera.zoom);Triple(item,TravelPixel(p.x-center.x+width/2,p.y-center.y+height/2),true)}}.filter {(_,p,_)->p.x in -30.0..width+30&&p.y in -30.0..height+30}
        coords.forEachIndexed {i,(item,p,_)->val overlap=RadarGeometry.overlaps(coords.map {it.second},i)
            Box(Modifier.offset {IntOffset((p.x*density).roundToInt()-12.dp.roundToPx(),(p.y*density).roundToInt()-12.dp.roundToPx())}.size(24.dp).background(if(overlap)Color.Gray else Color(0xFFF59E0B),MaterialTheme.shapes.small).semantics {contentDescription=item.text("title")+(if(overlap)" · Zum Öffnen näher heranzoomen" else " · Details öffnen")}.clickable(enabled=!overlap&&!gesture&&!c.loading){c.openDetail(item.text("id"))},contentAlignment=Alignment.Center){Text("●",color=Color(0xFF07111F))}
        }
        Column(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
            Button(onClick={change(camera.copy(zoom=(camera.zoom+1).coerceAtMost(18.0)),true)},enabled=camera.zoom<18,contentPadding=PaddingValues(0.dp),modifier=Modifier.size(44.dp)){Text("+")}
            Button(onClick={change(camera.copy(zoom=(camera.zoom-1).coerceAtLeast(10.0)),true)},enabled=camera.zoom>10,contentPadding=PaddingValues(0.dp),modifier=Modifier.size(44.dp)){Text("−")}
            if(c.radarCamera!=null)Button(onClick={request=0;c.loadItems()},contentPadding=PaddingValues(0.dp),modifier=Modifier.size(44.dp)){Text("⌖")}
        }
        Text("© OpenStreetMap contributors",Modifier.align(Alignment.BottomEnd).background(Color(0xEE07111F)).clickable {context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.openstreetmap.org/copyright")))}.padding(5.dp),fontSize=10.sp,color=Color.White)
        if(tileFailed)Row(Modifier.align(Alignment.BottomStart).background(Color(0xEE07111F))){TextButton(onClick={tileFailed=false;retry++}){Text("Karte erneut laden",fontSize=11.sp)}}
    }
}

@Composable fun WurstSuggestion(c:FoodController) {
    var open by remember {mutableStateOf(false)};var sending by remember {mutableStateOf(false)};var sent by remember {mutableStateOf(false)};var error by remember {mutableStateOf("")}
    var name by remember {mutableStateOf("")};var city by remember {mutableStateOf("")};var address by remember {mutableStateOf("")};var website by remember {mutableStateOf("")};var note by remember {mutableStateOf("")}
    Card(Modifier.fillMaxWidth()) {Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("Deine Stammbude fehlt?")
        Text("Neue Vorschläge werden vor Veröffentlichung geprüft.")
        if(sent)Text("Danke, ist angekommen. Die Bude bleibt zunächst ungeprüft.") else if(!open)OutlinedButton(onClick={open=true}){Text("Stammbude vorschlagen")} else {
            OutlinedTextField(name,{name=it.take(190)},label={Text("Name der Bude *")},enabled=!sending)
            OutlinedTextField(city,{city=it.take(120)},label={Text("Stadt")},enabled=!sending)
            OutlinedTextField(address,{address=it.take(240)},label={Text("Adresse")},enabled=!sending)
            OutlinedTextField(website,{website=it.take(240)},label={Text("Website")},enabled=!sending)
            OutlinedTextField(note,{note=it.take(1000)},label={Text("Dein Hinweis")},enabled=!sending)
            if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
            Button(onClick={sending=true;error="";c.submitWurstSuggestion(JSONObject().put("name",name).put("city",city).put("address",address).put("website",website).put("note",note).put("company","")){result->sending=false;result.onSuccess {sent=true}.onFailure {error=it.message ?: "Bitte später erneut versuchen."}}},enabled=!sending&&name.isNotBlank()){Text(if(sending)"Wird gesendet …" else "Vorschlag senden")}
            TextButton(onClick={open=false},enabled=!sending){Text("Abbrechen")}
        }
    }}
}

@Composable fun BuedchenCard(item:JSONObject,onPhotoFailure:(String)->Unit,click:()->Unit) {
    val special=item.optJSONObject("special") ?: JSONObject()
    Card(onClick=click,modifier=Modifier.fillMaxWidth()) {
        PlacePhoto(item,onFailure=onPhotoFailure)
        Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text(item.text("title"),fontSize=20.sp,fontWeight=androidx.compose.ui.text.font.FontWeight.Bold)
            Text(item.text("address").ifBlank {item.text("city")})
            Text(special.optJSONObject("opening")?.text("label").orEmpty().ifBlank {"Öffnungszeiten nicht bekannt"},fontSize=13.sp)
            val features=special.optJSONArray("features")?.objects().orEmpty().take(3)
            if(features.isNotEmpty())Text(features.joinToString(" · "){it.text("label")},fontSize=12.sp)
            Text(item.text("distance"),color=Color(0xFFF59E0B))
            Text("Details ansehen →",fontSize=13.sp,color=Color(0xFFF59E0B))
        }
    }
}
