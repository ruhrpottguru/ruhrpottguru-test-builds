# Geräteabnahme 0.9.0 – noch offen
Build und Datenvergleich ersetzen keine Geräteprüfung.

1. Über die bisherige Testversion installieren. Dunkles Design bei hellem System, Original-Logo, Fotokacheln, orange Titel, große Schrift, verankertes Burger-Menü und vier aufklappbare Gruppen prüfen.
2. Food ohne Website-Header/Footer. Stadt Wesel wählen, Radius5/25 km. Standortzeile und Ergebnisse im selben Kontext.
3. PLZ45888 → Gelsenkirchen, ungültige PLZ und Netzfehler. Kein neuer Name mit alten Ergebnissen.
4. Eigene gewünschte Adresse, fehlende Felder, ungültige Adresse, erneute Eingabe prüfen. Keine Testadresse als Nutzerstandort ausgeben.
5. GPS auf echtem Gerät: erlauben, ungefähr erlauben, ablehnen, Dienste aus, kein Fix. Frischer Fix bei jedem Start; keine simulierten Koordinaten als echte Position. GPS→Stadt: verspätetes GPS darf Stadt nicht überschreiben.
6. Food am selben Standort/Radius mit Web vergleichen: Reihenfolge, Entfernung, Text, Art/Thema, weitere Ergebnisse; auch Orte ohne Bild.
7. Details: Name, Typ, Entfernung, Adresse, Tags, Zeiten, unbekannte Preise. Tag→gefilterte Liste. Zurück→Liste/Scrollposition. Externe Links, Routen, Dialer, System-Teilen.
8. Standortwechsel während Anfrage, Internet aus, Fehler/Neuladen. Keine Mischung alter/neuer Daten oder andere Stadt bei leeren Ergebnissen.
9. Rotation in Liste, Detail, Standort-/Berechtigungsdialog, Hintergrund/Vordergrund und Prozessneustart. Manuelle Auswahl erhalten, GPS frisch, keine hängende Suche.
10. Weitere unfertige Specials: Hinweis statt Webseite. Zeitreise ist ab0.7 eine native Karte.

Erst nach Durchführung Gerät, Android-Version, Datum, Beobachtung und Ergebnis ergänzen. Zeitreise-Geräteabnahme ist in34–38 beschrieben.

11. Weseler Wirtshaus: DB-Foto in Liste und Detail vergleichen. Vorhandene Mehrbild-Galerien durchblättern, gespeicherte Ausschnitte und vollständige Credits/Quelle prüfen. Langsames Netz/defekte URL: Textkarte bleibt sichtbar, Bildresolver verändert weder Reihenfolge noch Trefferzahl.
12. Detail öffnen, lang scrollen: orange X bleibt oben rechts erreichbar. X schließen und Zurück-Geste kehren zur gleichen Liste mit erhaltenen Filtern und Scrollposition zurück.

13. Events in derselben App öffnen. Food→Events→Food, gemeinsame Stadt/Radius, kein Website-Header/-Footer. Mit Web bei Wesel5/25km und Essen5km vergleichen: Terminreihenfolge, Anzahl, originale Bilder, keine falsche Entfernung für reine Stadtbezüge.
14. Eventfilter gemeinsam testen: Art/Thema + Suche + Heute/Morgen/Wochenende/eigener Zeitraum, einschließlich Wochenende mit Zeitumstellung. Zurücksetzen entfernt alle Filter. Keine leeren Ergebnisse durch einen künstlichen anderen Ort ersetzen.
15. Event-Details: Zeiten, mehrtägige/Ganztagsereignisse, unbekanntes Ende, Preise, Mitwirkende, Veranstalter, Tickets und Dokumente. Keine unbekannten Preise als kostenlos oder Besuchszeiten als aktuell geöffnet behaupten.
16. Weitere Termine aufklappen und im Detail öffnen. X/Zurück kehrt zur unveränderten ursprünglichen Ergebnisliste mit Filtern/Scrollposition zurück. Während Reihenabruf X schließen oder Standort wechseln: keine veraltete Detailansicht öffnen.
17. Kalenderbutton: zeitgebundener Termin, Ganztag mit exklusivem Enddatum, Termin ohne Ende, fehlende Kalender-App. Datum, Titel, Beginn/Ende, Ort im Kalenderformular prüfen und erst dort speichern/abbrechen. Keine Kalenderberechtigung angefordert.
18. App/Prozess neu starten und rotieren, während Events gewählt ist: Kategorie, Standort und Datenkontext korrekt. Langsames/fehlendes Netz bei Medien, Reihe und Datenabfrage, Aktualisieren-Button und keine versteckten Einträge prüfen.

19. Highlights von Startkachel und Burger öffnen. Food/Events/Highlights wechseln: dieselbe Stadt und derselbe Radius, korrekte Kategorie auch nach Rotation/Neustart. Wesel5/25km und Essen5km am selben Ort mit Web vergleichen: Reihenfolge, Typ-/Thema-/Textfilter, weitere Ergebnisse.
20. Highlights mit DB-Bild, Galerie und ohne Bild öffnen. Crop, Credits, Quellen, feste X-Taste, Scrollposition, Zeiten, unbekannter Preis, Route/Website/Teilen prüfen. Kein Food-Symbolfoto für Highlights nachladen. Bei fehlender Website/Bild und langsamem Netz: vorhandener Resolver, keine falschen Bilder nach Standort-/Kategoriewechsel.

21. Kultur und Aktivitäten jeweils von Startkachel/Burger öffnen. Alle fünf Kategorien nacheinander wechseln, auch während laufender Bild-/Datenanfragen. Standort/Radius bleiben gleich, neue Kategorie und Titel korrekt; keine alten Karten/Bilder/Details anzeigen. Neustart/Rotation in beiden neuen Kategorien prüfen.
22. Kultur/Aktivitäten in Wesel5/25km, Essen5km und Dortmund5km mit derselben Web-Kategorie vergleichen: Entfernung/Reihenfolge, Bildausschnitte/Galerie/Nachweise, Text/Art/Thema kombiniert, mehr Ergebnisse und leere Treffer. Keine Home-Kurzliste in der vollen Kategorie.
23. Aktivitäten: öffentlicher Skatepark/Pumptrack/Tischtennisplatz mit und ohne Nutzungszeiten. Überschrift „Zugang & Nutzungszeiten“, keine erfundenen 24/7-Angaben. Private/Indoor-/gebührenpflichtige Orte nach vorhandenen Feldern behandeln. Generischen Titel mit vorhandener Straße/Stadtteil vergleichen. Preis unbekannt bleibt unbekannt.
24. Beide neuen Details: dauerhaftes oranges X, Android-Zurück, anklickbare Tags, Rückkehr zur Liste mit Filtern/Scrollposition, externe Website/Route/Anruf/Teilen. Langsames/fehlendes Netz und Standortwechsel während zweistufigem Medienresolver prüfen. Keine veralteten Medien in neuer Kategorie, auch bei derselben kanonischen Place-ID.

25. Detail-Reihenfolge je Kategorie mit Webseite vergleichen: obere Aktionen, Adresse/Zeiten vor Beschreibung, Event-Downloads/Kalender/Kontakte/Reihe/Glance/Quelle, Orts-Events/Community/Mitmachen, Chips zuletzt. Galerie/Crops/Quellen und dauerhaftes X prüfen.
26. Weseler Wirtshaus: food-info vervollständigt Website/Menü/Reservierung/Zeiten/Tags. Detail schließen oder Ort wechseln während Lookup: kein falsches Ergebnis im neuen Detail. Gleiche Listen-ID/Reihenfolge darunter. Industriekulturhinweis/offizieller Standortlink nur bei vorhandenen Feldern.
27. Event-Veranstalter mit Adresse/Telefon/E-Mail/Website; Mitwirkendenlink, Programm und Kalender testen. „Auf einen Blick“ rein informativ, keine erfundenen Gratis-/Indoor-/Barrierefrei-Fakten.
28. Orts-Events: echter Veranstaltungsort mit passenden Events, benachbarte andere Location bleibt ausgeschlossen. Alle Events aufklappen, nativ öffnen, X zurück. Während Abruf schließen/gleich wieder öffnen, Kategorie/Standort wechseln. Keine hängenden Resultate oder späten falschen Events.
29. Merken/Entmerken, Mein Pott, Neustart, Entfernen, maximal100 Einträge. Frisches share-item bei gespeicherten kanonischen IDs, Netzfehler und fehlender Standort. Gespeicherter Place mit derselben ID in anderer Kategorie darf aktuelle Liste nicht überschreiben. Tags im gespeicherten/Event-aus-Ort-Detail wechseln in die passende Kategorie.
30. Standard-Teilen und „Komm rum“: Nachricht,30/60/120Minuten/keine Angabe, korrekter RuhrpottGuru-Link. Abbrechen und tatsächliches Android-Teilen bewusst manuell testen. Keine automatische öffentliche GPS-/Treffenfreigabe.
31. Community lesen, Galerie/Instagram, leere Beiträge, Lesefehler/Wiederholen. Formularfoto mit Hoch-/Querformat/EXIF-Rotation/PNG-Alpha/WebP/HEIC auf unterstütztem Gerät, Quelle über20MB, defektes Foto, fünf Bilder; <=2400px und2MB WebP ohne Ausschnitt, kein Metadaten-/GPS-Upload.
32. Ortsdaten-/Fotoeinsendung: pro Foto Copyright, optionaler Quellenlink, Name/E-Mail und Rechte, Betreiber/Besucher. Nur Daten ohne Foto möglich; Foto ohne Nachweis blockiert. Community-Beitrag: Foto zwingend, Titel>=4/Text>=20, Name/E-Mail, alle drei Zustimmungen. Erst nach bewusstem Senden (keine Testspam-Einsendungen) Backendannahme, E-Mail-Bestätigung/Freigabe und spätere Anzeige durch Redaktion prüfen. Dieser echte End-to-End-Versand ist noch NICHT abgenommen.
33. Feedbacktoken frisch,1200Zeichen-Limit, leere Eingabe, bewusstes Senden/Abbrechen, Serverfehler/429. Keine automatische Wiederholung. Rotation/Hintergrund/Zurück in Formular und Datei-Picker prüfen; Entwürfe sind aktuell nicht über Prozessneustarts gesichert.

34. Zeitreise von Kachel/Burger öffnen; sieben Jahre in Web-Reihenfolge, echte WMS-Luftbilder, Attribution immer lesbar. Aufnahmezeiträume vergleichen. 1980: Original-Zusatzlayer prüfen, bei Ausfall regionale1969-Ergänzung und Fehlerhinweis statt falscher1980-Zusage.
35. Ziehen, Pinch/Plus/Minus, Zoom9–20, Vollbild/Android-Zurück, große Schrift/Rotation, leere oder weiße Randkacheln, langsames/fehlendes Netz/Wiederholen prüfen. Keine alten Jahresbilder nach Wechsel und keine blockierte UI bei laufendem Abbruch.
36. Eigene Stadt/PLZ/Adresse, numerische Stadteingabe, ungültig/leere Felder, Löschen während Anfrage, Standortübernahme. Suche setzt Marker; Pan verschiebt nur Kamera. Danach Food prüfen: globaler Standort/Radius unverändert. Verzögertes GPS darf eigene Zeitreisesuche nicht überschreiben.
37. Link teilen: Karte vom Marker wegbewegen, Jahr wechseln, bewusst Android-Teilen auslösen. Auf anderem Gerät/Web Zentrum/Marker/Zoom/Jahr und Vorschau vergleichen. /z/- und alte Querylinks einfügen; ungültige ablehnen. OS-Linkauswahl prüfen (unverifizierte App-Links), Kaltstart/Rotation/zweiter Intent, Zurück und erneuter Kategorienwechsel ohne unerwartetes Wiederöffnen.
38. Quellen-/Lizenzdialog für RVR/NRW und alte1955-Links prüfen; korrekte Quellen je Stack. Hintergrund/Vordergrund und Prozessneustart: keine dauerhafte Speicherung des Zeitreise-Suchverlaufs zugesagt. Alle fünf Kategorien und Detail-X/Fotos weiter testen.

39. Über0.7 installieren. Zeitreisekachel echtes Schwarzweiß-Luftbild mitRVR-Nachweis, „Link laden“-Pfeil fehlt; Vollbild/Teilen bleiben. Quellenmenü kann bestehende Links öffnen.
40. Büdchen von Start/Burger öffnen, GPS/Stadt/PLZ/Adresse und Radius wie bisher. Wesel5/25km und Essen5km mit Webseite vergleichen: feste Qualitätsmenge, Reihenfolge, unbekannte Zeiten, Lotto/GemischteTüte/Kaffee/Sitzplätze/Paketshop. „Jetzt geöffnet“ löscht Sortimentsfilter und umgekehrt. Kein zusätzliches ungeprüftes Büdchen durch Filter.
41. Karte mit zwei Fingern pan/zoomen, ein Finger scrollt Seite. Erst nach Loslassen neue Liste, Standortpunkt korrekt; Straßen lesbar. Marker öffnen, nahe/überlappende Marker erst nach Zoom. Plus/Minus/Rücksetzen; nur Kartenausschnitt-Abfrage, Food-Standort/Radius unverändert. Schnelle aufeinanderfolgende Gesten, Filter-/Standortwechsel, langsames/fehlendes Netz/Wiederholen und keine alten Marker/Resultate.
42. Büdchendetail: Galerie/Credits, Titel/Adresse/Öffnung/Ausstattung, OSM-Route/Website, Teilen/Kommrum/Merken und vorhandenes Beitragsformular. X/Android-Zurück zur selben Karte/Liste/Filtern. Rotation in Radar, Detail und Formular. Tatsächliche Einsendung nur bewusst und kein Testspam.
43. Imbiss: eigene Liste statt Food-Fullfeed, angebotabhängige sechs Spezialitätenfilter, Suche nach Stadt/Bude/Spezialität, SortierungEntfernung/Neu, leere Treffer. Geprüft/ImRadar und DB-Bilder/Galerie; fehlende Bilder verstecken nichts. Food→Imbiss→Büdchen→andereKategorie, auch während Anfragen.
44. Stammbudenvorschlag: NamePflicht, Feldgrenzen190/120/240/1000, Abbrechen, bewusster Versand und Fehlermeldung ohne automatischen Retry. Bestätigung bedeutet keine automatische Veröffentlichung. Kein echter Versand bei lokaler QA.

45. Über0.8 installieren, gespeicherterStandort/Merkliste unverändert. Commons-Bilder inHighlights/Kultur/Food prüfen: Unperfekthaus/Essen, DönerTime/Wesel, CaféamMarkt/Wesel. Bilder inListeundGalerie mitWeb vergleichen, Originalcredits/Lizenzen/Crops erhalten.
46. FrühereHTTP-Bilder Müller´sGrill-Ecke/Wesel, TempleBar/Essen undAdventureGolfPark prüfen. SichereHTTPS-Version oder klareFehleranzeige; keineFreigabeunsicherenVerkehrs/keinBildausfremderQuelle.
47. WLAN/Mobilfunk schwach/aus/wiederan währendBildabruf; höchstenseinautomatischerDatei-Retry progeöffneterKomponente, danachmanuellerButton. Nach„keinBild“ keineDauerschleife. URLwechsel/Galerievor/zurück undvieleKartenmitfehlendemFoto, keinFlackern/keinendlosesLaden.
48. Filter/Kategorie/Stadt/Radius wechseln,währendBild-/Resolverantwortenunterwegs; alteBildantwortendürfenkeineanderenOrteüberschreiben. AuchgleichePlace-ID inandererKategorie/Merkliste testen. Büdchen/Radar/Imbiss undZeitreiseweiterbedienbar; fehlendeQuellbilderbleibensichtbareKarten.
49. ManuellesBild-Neuladen inListe/Detail, Scrollen/Kartenneuaufbau/Rotation/Hintergrund; kein versehentlichesÖffnen derKarte beimRetrybutton, keineverlorenenCredits. AufälteremAndroid BildformateundSVG zusätzlichprüfen. Kein Emulator-/GerätetestbeiBuild-QA durchgeführt.

## Navigation 0.10
- Burger auf Start und jeder Kategorie: vier eingeklappte Gruppen, nur eine Gruppe gleichzeitig offen; Menü bleibt am Kopfbereich und lässt sich auf kleinem Display scrollen.
- Zurück und Tippen außerhalb schließen Menü; Auswahl öffnet die passende native Ansicht.
- Suche und fünf unfertige Specials dürfen keine falsche Food-/Webseite öffnen. „In Vorbereitung“ muss vor Klick sichtbar sein (insgesamt sechs gesperrte Ziele inklusive Suche).
- Informationen: App-Info, Bildnachweise, Impressum und Datenschutz öffnen native, scrollbar lesbare Texte; Links starten erst nach Klick die externe App.
- Standort/Radius und Merkliste bleiben nach Menüwechsel erhalten; GPS, manuelle Suche, Detail-X und Zeitreise separat weiterhin prüfen.

## Kompakte Kopfzeile 0.11
- Start/Kategorien/Details/Informationen/Merkliste/Zeitreise: kleines Logo, Ort und Radius ganz oben; keine zweite Standortkarte.
- Fadenkreuz direkt links vom Burger/Detail-X sowie Ortstext öffnen GPS/Stadt/PLZ/Adresse/Radius. Ohne Standort: „Ort wählen“. Standortdialog schließen und Änderung anwenden wie zuvor.
- Zurück und oranges Detail-X weiterhin erreichbar; Burger am Kopf verankert, Menü scrollt bei Bedarf. Zeitreise-Vollbild blendet Kopf weiter aus.
- Schmaler Bildschirm320dp, lange Ortsnamen und große Android-Schrift: Text darf gekürzt werden, Icons dürfen nicht verschwinden oder sich überlagern. Vollständigen Ort im Dialog prüfen. Nicht als bereits visuell geprüft behauptet.

## Logo 0.12
Größeres Logo bei gleicher kompakter Kopfzeile auf Start und Unterseiten prüfen; lange Ortsnamen/große Schrift/Zurück/Standort/Burger/Detail-X müssen erreichbar bleiben.

## Specials 0.13
- Start/Burger öffnen Route, Halloween, Weihnachten nativ; größeresLogo bleibt. Zurück/X/Burger und Ortsauswahl prüfen.
- Route:57Standorte, Typ/Stadtkombination, Pagination, echte Bilder/Credits und offizielle Detail-Links; Ziethenstraße ohne erfundeneEntfernung/Route. Ohne Standort muss57er-Bestand verfügbar bleiben. Merken/erneutöffnen und Quellen prüfen.
- Halloween: Anfang5km ohneechteTreffer muss ohneZwischen-0 auf10 undggf25 erweitern; Unterfilterleer ohneAutoerweiterung.
- Weihnachten: Weihnachtsmärkte alsStartfilter, sechsThemen inOriginalreihenfolge. Gespeicherten5km-Radius nicht durch25 ersetzen. Neuinstallation ohnePräferenz:25 nurlokal; AbbruchGPS/Adresse darfVorgabe nichtheimlich löschen.
- AusSpecial zuStart/Info/Events/Zeitreise wechseln, währendAbruf läuft: keinealtenAntworten/Radiusänderungen. Orts-/RadiuswechselinderThemenwelt erhältderenFilter.
- Neuesaison undfehlendeTreffer ehrlich; keineVorjahresereignisse alsaktuell. Kalender/Teilen/Community/UploadseparatamGerätprüfen.
