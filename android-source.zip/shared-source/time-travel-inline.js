
(function(){
  var tries=0,timer=null;

  function findVisibleRoot(){
    return document.querySelector('#ruhrpott-guru-root .rpg-zvo');
  }

  function normalizeKey(value){
    return String(value||'').trim().toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
      .replace(/ß/g,'ss').replace(/[^a-z0-9]+/g,'');
  }

  var shareYears=[
    '1934','1952','1990','2024','2009','1982','1970','1955','1980','1969','current','1926'
  ];

  function readShareState(){
    try{
      if(window.RPGZVO_SHARE_STATE && typeof window.RPGZVO_SHARE_STATE==='object'){
        var s=window.RPGZVO_SHARE_STATE;
        if(Number.isFinite(Number(s.lat))&&Number.isFinite(Number(s.lng))){
          return {
            lat:Number(s.lat),
            lng:Number(s.lng),
            zoom:Number(s.zoom)||17,
            year:String(s.year||'current'),
            markerLat:Number(s.markerLat),
            markerLng:Number(s.markerLng)
          };
        }
      }

      var p=new URLSearchParams(window.location.search||'');
      if(!p.has('zvo_lat')||!p.has('zvo_lng'))return null;

      var lat=Number(p.get('zvo_lat'));
      var lng=Number(p.get('zvo_lng'));
      var zoom=Number(p.get('zvo_z'));
      var year=String(p.get('zvo_y')||'current');
      var markerLat=Number(p.get('zvo_mlat'));
      var markerLng=Number(p.get('zvo_mlng'));

      if(!Number.isFinite(lat)||!Number.isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return null;
      if(!Number.isFinite(zoom)||zoom<9||zoom>20)zoom=17;
      if(shareYears.indexOf(year)===-1)year='current';

      if(!Number.isFinite(markerLat)||!Number.isFinite(markerLng)||Math.abs(markerLat)>90||Math.abs(markerLng)>180){
        markerLat=lat;
        markerLng=lng;
      }

      return {lat:lat,lng:lng,zoom:zoom,year:year,markerLat:markerLat,markerLng:markerLng};
    }catch(_){return null;}
  }

  function boot(){
    var root=findVisibleRoot();
    if(!root || typeof window.L==='undefined'){
      if(tries++<160){timer=setTimeout(boot,100);}
      return;
    }
    if(root.dataset.zvoBooted==='1')return;
    root.dataset.zvoBooted='1';

    var mapEl=root.querySelector('.rpg-zvo__map');
    var statusEl=root.querySelector('.rpg-zvo__status');
    var badgeTitle=root.querySelector('.rpg-zvo__badge-title');
    var badgeSub=root.querySelector('.rpg-zvo__badge-sub');
    var form=root.querySelector('.rpg-zvo__search');
    var yearButtons=root.querySelectorAll('.rpg-zvo__timeline button');
    var shareBtn=root.querySelector('.rpg-zvo__share');
    var clearBtn=root.querySelector('.rpg-zvo__clear');
    if(!mapEl||!statusEl||!form)return;

    var start={lat:51.4556,lng:7.0116,label:'Ruhrgebiet'};
    try{
      var saved=JSON.parse(localStorage.getItem('ruhrpottguru_location_snapshot_v2')||'null');
      if(saved&&Number.isFinite(Number(saved.lat))&&Number.isFinite(Number(saved.lng))){
        start={
          lat:Number(saved.lat),
          lng:Number(saved.lng),
          label:String(saved.name||saved.city||'Aktueller RuhrpottGuru-Standort')
        };
      }else{
        var cm=document.cookie.match(/(?:^|;\s*)rg_location_city_v1=([^;]+)/);
        if(cm&&window.RPGReact&&window.RPGReact.CITY_CENTERS){
          var c=decodeURIComponent(cm[1]);
          var pair=window.RPGReact.CITY_CENTERS[c];
          if(pair)start={lat:Number(pair[0]),lng:Number(pair[1]),label:c};
        }
      }
    }catch(_){}

    function clearForm(){
      form.reset();
      ['street','number','zip','city'].forEach(function(name){
        var input=form.querySelector('[name="'+name+'"]');
        if(input)input.value='';
      });
    }

    clearForm();

    var shareState=readShareState();
    var initialLat=shareState?shareState.lat:start.lat;
    var initialLng=shareState?shareState.lng:start.lng;
    var initialZoom=shareState?shareState.zoom:17;
    var markerLat=shareState?shareState.markerLat:start.lat;
    var markerLng=shareState?shareState.markerLng:start.lng;
    var currentYear=shareState?shareState.year:'current';

    var map=L.map(mapEl,{zoomControl:true,minZoom:9,maxZoom:20}).setView([initialLat,initialLng],initialZoom);
    var marker=L.circleMarker([markerLat,markerLng],{
      radius:7,weight:3,color:'#111',fillColor:'#ff9f00',fillOpacity:1
    }).addTo(map);

    var activeLayers=[];

    function rvrHistoric(year,title,sub){
      return {
        title:title,
        sub:sub,
        stack:[{
          url:'https://geodaten.metropoleruhr.de/lubi/lubi_'+year,
          layer:'lubi_'+year,
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.1.1',
            attribution:'© Regionalverband Ruhr'
          }
        }]
      };
    }

    function nrwHistoric(year,title,sub){
      return {
        title:title,
        sub:sub,
        stack:[{
          url:'https://www.wms.nrw.de/geobasis/wms_nw_hist_dop',
          layer:'nw_hist_dop_'+year,
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.3.0',
            attribution:'Geobasis NRW · Datenlizenz Deutschland – Zero 2.0'
          }
        }]
      };
    }

    var layers={
      '1926':rvrHistoric(
        '1926',
        'Historische Luftbilder 1925–1930',
        'RVR-Datensatz „LUBI 1926“ · konkrete Aufnahme kann aus 1925–1930 stammen'
      ),

      /* Alte / versteckte Jahre fuer bestehende Share-Links. */
      '1934':rvrHistoric(
        '1934',
        'Historische Luftbilder 1934–1939',
        'RVR-Datensatz „LUBI 1934“ · konkrete Aufnahme kann aus 1934–1939 stammen'
      ),

      '1952':rvrHistoric(
        '1952',
        'Historische Luftbilder 1951–1980',
        'RVR-Datensatz „LUBI 1952“ · überwiegend 1952'
      ),

      '1955':{
        title:'Luftbild 1955',
        sub:'Historisches Orthophoto NRW · alter Zwischenstand',
        stack:[{
          url:'https://www.wms.nrw.de/geobasis/wms_nw_hist_dop',
          layer:'nw_hist_dop_1955',
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.3.0',
            attribution:'Geobasis NRW · Hansa Luftbild AG · Landesarchiv NRW · Bestand RW 0230'
          }
        }]
      },

      '1969':rvrHistoric(
        '1969',
        'Historische Luftbilder 1957–1980',
        'RVR-Datensatz „LUBI 1969“ · überwiegend 1969'
      ),

      '1970':nrwHistoric(
        '1970',
        'Luftbild 1970',
        'Historisches Orthophoto NRW · alter Zwischenstand'
      ),

      /*
       * 1980 ist bewusst ein kombinierter Layer:
       * 1) RVR 1957–1980 / überwiegend 1969 als regionaler Untergrund.
       * 2) Exakter NRW-Jahrgang 1980 transparent darüber, wo vorhanden.
       * So bleiben Lücken nicht einfach weiss, ohne überall 1980 zu behaupten.
       */
      '1980':{
        title:'Luftbilder bis 1980',
        sub:'1980, wo verfügbar · regionale Ergänzung 1957–1980 (überwiegend 1969)',
        stack:[
          {
            url:'https://geodaten.metropoleruhr.de/lubi/lubi_1969',
            layer:'lubi_1969',
            opts:{
              format:'image/jpeg',
              transparent:false,
              version:'1.1.1',
              attribution:'© Regionalverband Ruhr'
            }
          },
          {
            url:'https://www.wms.nrw.de/geobasis/wms_nw_hist_dop',
            layer:'nw_hist_dop_1980',
            opts:{
              format:'image/png',
              transparent:true,
              version:'1.3.0',
              attribution:'Geobasis NRW · Datenlizenz Deutschland – Zero 2.0'
            }
          }
        ]
      },

      '1982':nrwHistoric(
        '1982',
        'Luftbild 1982',
        'Historisches Orthophoto NRW · alter Zwischenstand'
      ),

      '1990':rvrHistoric(
        '1990',
        'Historische Luftbilder 1983–1990',
        'RVR-Datensatz „LUBI 1990“ · überwiegend 1990'
      ),

      '2009':{
        title:'Luftbild 2009',
        sub:'RVR DOP 2009 · Farborthofoto',
        stack:[{
          url:'https://geodaten.metropoleruhr.de/dop/dop',
          layer:'DOP',
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.1.1',
            time:'2009',
            attribution:'© Regionalverband Ruhr'
          }
        }]
      },

      'current':{
        title:'Aktuelles Luftbild',
        sub:'Neuester verfügbarer RVR-Luftbildstand für diesen Ausschnitt',
        stack:[{
          url:'https://geodaten.metropoleruhr.de/dop/dop',
          layer:'DOP',
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.1.1',
            attribution:'© Regionalverband Ruhr'
          }
        }]
      },

      /* Versteckt nur für bestehende Share-Links mit festem Stand 2024. */
      '2024':{
        title:'Luftbild 2024',
        sub:'RVR DOP 2024 · bestehender Share-Stand',
        stack:[{
          url:'https://geodaten.metropoleruhr.de/dop/dop',
          layer:'DOP',
          opts:{
            format:'image/jpeg',
            transparent:false,
            version:'1.1.1',
            time:'2024',
            attribution:'© Regionalverband Ruhr'
          }
        }]
      }
    };

    function setStatus(msg){statusEl.textContent=msg||'';}

    function removeActiveLayers(){
      activeLayers.forEach(function(layer){
        try{map.removeLayer(layer);}catch(_){}
      });
      activeLayers=[];
    }

    function showYear(year){
      var cfg=layers[year];
      if(!cfg)return;

      currentYear=year;
      removeActiveLayers();

      (cfg.stack||[]).forEach(function(item){
        var layer=L.tileLayer.wms(
          item.url,
          Object.assign({},item.opts,{layers:item.layer})
        );

        layer.on('tileerror',function(){
          setStatus('Der gewählte Luftbild-Layer konnte für diesen Ausschnitt nicht vollständig geladen werden.');
        });

        layer.addTo(map);
        activeLayers.push(layer);
      });

      badgeTitle.textContent=cfg.title;
      badgeSub.textContent=cfg.sub;

      yearButtons.forEach(function(b){
        b.classList.toggle('is-active',b.getAttribute('data-year')===year);
      });
    }

    function moveTo(lat,lng,label){
      var p=[Number(lat),Number(lng)];
      if(!Number.isFinite(p[0])||!Number.isFinite(p[1]))return;
      map.setView(p,17);
      marker.setLatLng(p);
      if(label)setStatus(label);
      setTimeout(function(){map.invalidateSize();},100);
    }

    function findCityCenter(city){
      var centers=window.RPGReact&&window.RPGReact.CITY_CENTERS?window.RPGReact.CITY_CENTERS:{};
      var wanted=normalizeKey(city);
      var hit=Object.keys(centers).find(function(name){return normalizeKey(name)===wanted;});
      if(!hit)return null;
      var pair=centers[hit];
      if(!pair)return null;
      return {city:hit,lat:Number(pair[0]),lng:Number(pair[1])};
    }

    function onGlobalLocationChanged(e){
      var loc=e&&e.detail&&typeof e.detail==='object'?e.detail:null;
      if(!loc||!Number.isFinite(Number(loc.lat))||!Number.isFinite(Number(loc.lng)))return;
      clearForm();
      moveTo(Number(loc.lat),Number(loc.lng),String(loc.name||loc.city||'Standort geändert'));
    }
    window.addEventListener('rpg:location-changed',onGlobalLocationChanged);

    yearButtons.forEach(function(btn){
      btn.addEventListener('click',function(){showYear(btn.getAttribute('data-year'));});
    });

    if(clearBtn){
      clearBtn.addEventListener('click',function(){
        clearForm();
        setStatus('Suchfelder geleert. Die Karte bleibt an der aktuellen Position.');
        var first=form.querySelector('[name="street"]');
        if(first)first.focus();
      });
    }

    form.addEventListener('submit',function(e){
      e.preventDefault();
      var fd=new FormData(form);
      var street=String(fd.get('street')||'').trim();
      var house=String(fd.get('number')||'').trim();
      var postcode=String(fd.get('zip')||'').replace(/\s+/g,'').trim();
      var city=String(fd.get('city')||'').trim();

      /*
       * Tolerante Eingabe: Wenn versehentlich eine 5-stellige PLZ
       * im Feld "Ort" steht und das PLZ-Feld leer ist, behandeln wir
       * sie als PLZ. Das veraendert nur die lokale Zeitreise-Suche.
       */
      if(!postcode && /^\d{5}$/.test(city)){
        postcode=city;
        city='';

        var zipInput=form.querySelector('[name="zip"]');
        var cityInput=form.querySelector('[name="city"]');

        if(zipInput)zipInput.value=postcode;
        if(cityInput)cityInput.value='';
      }

      if(!street && !postcode && !city){
        setStatus('Du kannst die Karte einfach am aktuellen Standort nutzen oder optional PLZ, Ort oder Adresse eingeben.');
        return;
      }

      if(!street && postcode && !city){
        if(!/^\d{5}$/.test(postcode)){
          setStatus('Bitte gib eine gültige 5-stellige PLZ ein.');
          return;
        }
        if(window.RPGReact&&window.RPGReact.api&&typeof window.RPGReact.api.postcodeLocation==='function'){
          setStatus('PLZ wird gesucht …');
          window.RPGReact.api.postcodeLocation(postcode)
            .then(function(data){
              if(!data||!Number.isFinite(Number(data.lat))||!Number.isFinite(Number(data.lng)))throw new Error('Für diese PLZ wurde kein Mittelpunkt gefunden.');
              moveTo(Number(data.lat),Number(data.lng),'PLZ '+postcode);
            })
            .catch(function(err){setStatus(err&&err.message?err.message:'Die PLZ konnte gerade nicht aufgelöst werden.');});
          return;
        }
      }

      if(!street && city){
        var center=findCityCenter(city);
        if(center){
          moveTo(center.lat,center.lng,center.city);
          return;
        }
        if(!postcode){
          setStatus('Diesen Ort konnte ich im RuhrpottGuru-Gebiet nicht eindeutig finden.');
          return;
        }
      }

      if(street && !postcode && !city){
        setStatus('Bitte ergänze zur Straße eine PLZ oder einen Ort.');
        return;
      }

      if(postcode&&!/^\d{5}$/.test(postcode)){
        setStatus('Bitte gib eine gültige 5-stellige PLZ ein.');
        return;
      }

      var settings=window.RPGReact&&window.RPGReact.settings?window.RPGReact.settings:{};
      var endpoint=settings.addressLocationUrl||'/wp-json/ruhrpottguru/v1/address-location';
      var token=settings.addressLocationToken||'';
      if(!token){setStatus('Die Adresssuche ist gerade nicht verfügbar. Bitte lade die Seite neu.');return;}

      setStatus(street?'Adresse wird gesucht …':'Ort wird gesucht …');
      fetch(endpoint,{
        method:'POST',
        credentials:'same-origin',
        headers:{'Content-Type':'application/json','Accept':'application/json','X-RPG-Address-Token':token},
        body:JSON.stringify({street:street,housenumber:house,postcode:postcode,city:city})
      })
      .then(function(r){
        return r.json().then(function(data){
          if(!r.ok||!data||data.ok===false)throw new Error(data&&data.message?data.message:'Ort nicht gefunden.');
          return data;
        });
      })
      .then(function(data){
        moveTo(data.lat,data.lng,data.label||[street,house,postcode,city].filter(Boolean).join(' · '));
      })
      .catch(function(err){
        setStatus(err&&err.message?err.message:'Der gewünschte Ort konnte gerade nicht aufgelöst werden.');
      });
    });

    function encodeShareToken(){
      var center=map.getCenter();
      var markerPoint=marker.getLatLng();
      var yi=Math.max(0,shareYears.indexOf(currentYear));
      var buf=new ArrayBuffer(18);
      var view=new DataView(buf);

      view.setInt32(0,Math.round(Number(center.lat)*100000),false);
      view.setInt32(4,Math.round(Number(center.lng)*100000),false);
      view.setInt32(8,Math.round(Number(markerPoint.lat)*100000),false);
      view.setInt32(12,Math.round(Number(markerPoint.lng)*100000),false);
      view.setUint8(16,Math.max(9,Math.min(20,Number(map.getZoom())||17)));
      view.setUint8(17,yi);

      var bytes=new Uint8Array(buf),bin='';
      for(var i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);
      return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    }

    function shareUrl(){
      return new URL('/z/'+encodeShareToken()+'/',window.location.origin).toString();
    }

    if(shareBtn){
      shareBtn.addEventListener('click',function(){
        var url=shareUrl();
        var title='RuhrpottGuru · Zeitreise von oben';
        if(navigator.share){
          navigator.share({title:title,url:url}).then(function(){
            setStatus('Ansicht geteilt.');
          }).catch(function(err){
            if(err&&err.name==='AbortError')return;
            if(navigator.clipboard&&navigator.clipboard.writeText){
              navigator.clipboard.writeText(url).then(function(){setStatus('Link kopiert.');});
            }
          });
          return;
        }
        if(navigator.clipboard&&navigator.clipboard.writeText){
          navigator.clipboard.writeText(url).then(function(){setStatus('Link kopiert.');});
          return;
        }
        window.prompt('Diesen Link kopieren:',url);
      });
    }

    showYear(currentYear);
    setStatus(shareState?'Geteilte Ansicht':'Start: '+start.label);
    requestAnimationFrame(function(){
      map.invalidateSize();
      setTimeout(function(){map.invalidateSize();},250);
    });
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',boot,{once:true});
  }else{
    boot();
  }
})();
//# sourceURL=rpg-zvo-leaflet-js-after
