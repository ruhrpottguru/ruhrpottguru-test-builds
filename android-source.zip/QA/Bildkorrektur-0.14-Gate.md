# Bildkorrektur 0.14 — 20.10.2026

Nutzerfreigabe: gemeldetes falsches Bild am Peter-Behrens-Bau korrigieren.
Live-Read-only GET places/industrial-route bestätigt Place8407, OSMway37642158, Essener Straße80: Rheinisches Industriemuseum.jpg aus OSM-linked WikidataP18 ist als Primärbild hinterlegt. Keine Server-/DB-Änderung.
Identität und Abbildung gegengeprüft mit LVR https://www.lvr.de/industriemuseum/peter-behrens-bau/ und Commons https://commons.wikimedia.org/wiki/File:Peter-Behrens-Bau-Oberhausen-2025.jpg; tatsächliche Fassade visuell geprüft. Urheber Tuxyso, CC BY-SA4.0, eigenes Werk vom17.05.2025. Original unverändert mitliefern; UI-Zuschnitt nur Darstellung.

Reuse: native-adapter media/dto/gallery/snapshot/restore, PlacePhoto mit Coil-Asset-Lader und bestehender Quellenaktion. Exakt identitätsgebundene kuratierte Bildkorrektur, keine allgemeine Fotosuche. Korrigiertes Primärbild und Galerie auch bei Favoriten und nach Medienantworten. Kein Titelmatching.
Erlaubte Dateien: native-adapter.js, PlacePhoto.kt (optionaler Lizenzlink), InfoScreen.kt (Foto-/Lizenznachweis), FoodController.kt (bestehende Favoritenbilder beim Start aktualisieren), app/assets/media, Bildnachweise-Asset, BILDNACHWEISE.md, app/build.gradle (15/0.14), README, QA, targeted Tests und präzise Abweichungserwartung im Specials-Test.
Geschützt: sämtliche Originalquellen/Extraktionswerkzeuge, Normalisierung, Admission, Kategorien, Reihenfolge, Filter, Radius, Standort, SEO, API-Contracts, übrige Bilder/Orte. Gegen0.13 byteweise Diff.
Risiko: gezielte Bildkorrektur bleibt in dieser App-Version gebunden, selbst wenn Serverbilder später verbessert werden. OriginalDB bleibt falsch; separat korrigierbar. Identität niemals aus gleichem Museum-Wikidata erben.
Tests: Route/normalPlace/Favorit, falsche Resolverantworten, ähnliche andere Orte/Events, Galerie/Nachweise, bestehende acht Node-Suiten, Androidclean Build/JUnit/Lint, APKmanifest/Assets/Signatur. Physisches Gerät nicht verfügbar.
Rollback: 0.13-Baseline und bereits gesicherter Quellstand0.13; kein Backendrollback nötig.
