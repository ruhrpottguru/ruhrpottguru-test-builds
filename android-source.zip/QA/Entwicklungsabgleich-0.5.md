# Entwicklungsabgleich 0.5.0 · 19.10.2026

Auftrag: nächste gemeinsame APK mit allen fünf Hauptkategorien. Nutzerfreigabe in diesem Chat; Specials/Zeitreise bleiben gesonderte Module. Keine Veröffentlichung/Änderung an WordPress.

## Vor dem Codeeingriff
Projektvertrag v1.2 und Architekturregister v1.9 sowie operative Masterliste v1.9 lokal gelesen; Schutz der bestehenden Kategorie-/Themenregeln abgeglichen. Live runtime/api/views/components erneut gelesen und bytegleich zu den bisher verwendeten Snapshots bestätigt (SHA256 in source-manifest.json). Keine parallelen Worker oder Codeänderungen dieses Auftrags; vorheriger Build beendet. Aktueller Ausgangsstand: APK 0.4.0, versionCode5, Kotlin/Compose. Getrennte bisherige Buildkopie als Rücknahmebasis erhalten.

## Wiederverwendung / erlaubter Diff
| Wunsch | Bestehender Vertrag / Wiederverwendung | Betroffene App-Dateien |
|---|---|---|
| Kultur/Aktivitäten | api.places → POST places/home, category= culture/activities, limit1500, location+radius | FoodController.kt: zwei weitere Kategorien freischalten |
| Ergebnislogik | useCategoryItems(home=false), normalizePlace, sortDistance, unverändertes CategoryView-Prädikat | tools/sync-shared.py, neues category-places.js, native-adapter.js, SharedFoodEngine.kt |
| Bilder/Details | bestehender nativer Bild-/Galeriebaustein, DB-Crops/Credits, unverändertes resolveItemMedia inkl. place-info→food-media | vorhandene Highlights-Medientransportbindung für Kultur/Aktivitäten mitnutzen |
| Zugang/Zeiten | runtime.placeOpeningStatus inkl. activityPublicOutdoorMode, keine erfundenen 24/7 | DTO hoursHeading und vorhandene Detailüberschrift in MainActivity.kt |
| Navigation | bestehende Startkacheln und Burger-Einträge | MainActivity.kt: aktivieren, Kategoriebezeichnungen |
| APK | identisches applicationId/Testzertifikat | app/build.gradle: 0.5.0-test, versionCode6 |

Zusätzlich erlaubt: Kategorie-Regression/Fixtures, QA-/Buildnachweise und Dokumentation. Keine neue UI-Architektur, keine weitere untere Navigationsleiste. Medien-Resolver-Namen aus Highlights bleiben aus Kompatibilitätsgründen intern erhalten und bezeichnen nun den bereits vorhandenen Non-Food-Places-Transport.

## Schutzbereich / Grenzen
Originale shared-source/*, runtime.js/api.js, Backend-Zulassung/Activity Intelligence, Kategorien, Distanz, Quellenrechte, Filtersemantik, SEO/Deep-Links, Event-/Saisonregeln unverändert. Volle Kategorie hat home=false: keine Aktivitäten-Home-Kurzliste/Diversitätsauswahl und keine Highlights-Home-Radiusausweitung auf die gesamte Kategorie übertragen. Keine eigenen Fitness-/Zugangsfilter; vorhandene Backend-Kandidaten und Originalnormalisierung entscheiden. Bilder verändern nie Sichtbarkeit oder Reihenfolge. Kein unbekannter Zugang/Preis als rund um die Uhr/kostenlos dargestellt.

## Prüfplan / Freigabestatus
Live-Fixtures Wesel5/25km, Essen5km und Dortmund5km für beide neuen Kategorien; IDs/Reihenfolge, kombinierte Filter, Kategorienwechsel, Originalbilder/Galerien/Crops/Nachweise, Öffnungs-/Nutzungszeiten, fehlende Daten, Medienfortsetzung und veraltete Antworten. Vorhandene Food/Event/Highlights-Regression. Android-Build/Unit/Lint, gleiche Signatur, ZIP-Ausrichtung, Paketversion und gebündelte Quellen. Kein Gerät/Emulator verbunden: Installation, visuelle UI/Interaktion und echte GPS-/Kalenderabläufe bleiben manuelle Geräteabnahme. Ergebnis ist Test-APK, keine Store-/Produktionsfreigabe. Rollback: Quellstand/APK0.4.0 erhalten; Android-Downgrade kann Neuinstallation erfordern.
