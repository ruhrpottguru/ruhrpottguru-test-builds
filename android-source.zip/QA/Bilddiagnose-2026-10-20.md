# Bilddiagnose der Android-App0.8.0 – 20.10.2026

Die fehlenden Bilder haben mehrere nachgewiesene Ursachen. Ein wichtiger Appfehler ist der generische HTTP-Client-Name: Wikimedia lehnt ihn ab. Zusätzlich stehen Bildadressen teils nur als unsichere HTTP-Links oder Fotoseiten statt Bilddateien in den Daten. Bei vielen Orten liefert der initiale Feed gar keine Bildadresse; dafür ist der bestehende nachgelagerte Resolver zuständig. Ein leerer Feed beweist NICHT, dass nirgends in Datenbank/Mediencache ein Bild vorhanden ist.

## Umfang und Beweiskraft

21 aktuelle öffentliche Feeds aus Wesel, Essen und Dortmund, jeweils5km, über Food, Events, Highlights, Kultur, Aktivitäten, Büdchen und Imbiss. 3.597 ausgegebene Karten-/Terminvorkommen, keine globale Anzahl eindeutiger DB-Orte. Originalnormalisierung und Event-/Büdchenzulassung unverändert ausgeführt. Fünf maßgebliche aktuelle Web-JS-Dateien stimmen bytegleich mit dem App-Snapshot überein. In den Ausgangs-Bildadressen der geprüften DTOs keine Abweichung zum Webmodell gefunden.

Zusätzlich36 gezielte Bildabrufe,11 Beispiele des vorhandenen Medienresolvers und kontrollierte User-Agent-Vergleiche. Kein Android-Gerät/Emulator, keine Gerätestacktraces; Netzwerkfehler auf Jürgens Gerät können dadurch nicht vollständig zugeordnet werden. Alle Aufrufe waren normale Lese-/Lookup-Aufrufe, keine Uploads, Imports oder Backend-Patches.

## 1. Wikimedia weist den Standardclient ab – direkt reproduziert

Coil3.1.0 verwendet laut veröffentlichter Maven-POM (`https://repo.maven.apache.org/maven2/io/coil-kt/coil3/coil-network-okhttp-jvm/3.1.0/coil-network-okhttp-jvm-3.1.0.pom`) OkHttp4.12.0; die App konfiguriert weder eigenen ImageLoader noch User-Agent. Der generische Clientname lautet `okhttp/4.12.0`.

Identische Commons-/Thumbnail-Bildadressen wurden mit unveränderten übrigen Anfragebedingungen geprüft:

- `okhttp/4.12.0` → HTTP403. Antwort: „Please set a user-agent and respect our robot policy …“.
- `RuhrpottGuru/0.8.0 (+https://www.ruhrpottguru.de/)` → HTTP200, echte JPEG-Datei.
- Browser-Kennung → HTTP200, echte JPEG-Datei.

Beispiele: Unperfekthaus/Essen, Döner Time/Wesel. Die Daten enthalten312 Wikimedia-Bildverweise auf273 unterschiedlicheURLs über mehrere Kategorien; diese Zahl ist eine potenziell betroffene Quellenmenge, KEIN Nachweis312fehlender Bilder auf dem Gerät. Messwerte je Host in der JSON-Beilage. Maßnahme: einen ehrlich identifizierenden, regelkonformen App-User-Agent für den gemeinsamen Bildclient setzen, einschließlich Galerie und Radar. Nicht als Browser tarnen.

## 2. HTTP-Bilder werden von Android blockiert

AndroidManifest setzt `android:usesCleartextTraffic="false"`; die Bildkomponente übernimmt URL unverändert. 45Bildverweise/44unterschiedlicheURLs beginnen mitHTTP. Dadurch kann Android bereits den ersten unsicheren Abruf blockieren, auch wenn der Server anschließend nachHTTPS umleiten würde.

Bei Auszeit/Wesel, Müller´s Grill-Ecke/Wesel, Temple Bar/Essen und Adventure Golf Park/Dortmund wurden die entsprechendenHTTPS-Adressen als echte Bilddateien mit200 bestätigt. Nicht jede Adresse unterstütztHTTPS oder zeigt tatsächlich ein Bild. Daher nur nach bestätigtem Ziel/Medientyp sicher aufHTTPS umstellen; Cleartext nicht global freigeben und Rechte-/Quellenmetadaten beibehalten.

## 3. Ausgangsdaten sind oft leer; Nachladen ist ein eigener Schritt

| Kategorie | Karten-/Terminvorkommen | Initial mit Bildadresse | Initial ohne Bildadresse | HTTP-Verweise |
| --- | ---: | ---: | ---: | ---: |
| Food | 1885 | 505 | 1380 | 22 |
| Events / Terminvorkommen | 533 | 504 | 29 | 0 |
| Highlights | 98 | 97 | 1 | 1 |
| Kultur | 626 | 351 | 275 | 20 |
| Aktivitäten | 191 | 25 | 166 | 1 |
| Büdchen | 187 | 4 | 183 | 0 |
| Imbiss | 77 | 16 | 61 | 1 |

Die 2.095 leeren Ausgangsbilder dürfen nicht mit dauerhaft fehlenden Bildern gleichgesetzt werden. In11repräsentativen Lookupfällen lieferte der bestehende Resolver5Bilder nach, darunter Chikurin/Wesel und zwei Basketballplätze. Andere Antworten lauteten `not-found`: keine verlässlich belegte reale/kontextuelle Bildquelle, keine zulässige konfigurierte Symbolbildalternative. Beispiel Trinkhalle Aydin/Wesel: beide bestehenden Auflösungsstufen ohne freigegebene Bildantwort.

Die getesteten Einzelaufrufe dauerten etwa6–23Sekunden; Standort-/Identitätslookup und Medienlookup können nacheinander kommen. Drei native Resolver-Threads begrenzen Parallelität. Mehrere leere Karten können deshalb auch lange auf ihr Bild warten. Keine allgemeine Server-/Gerätelatenz aus diesem Abrufweg ableiten.

Imbisskarten nutzen wie ihre Webvorlage keinen zusätzlichen Kartenresolver; sie zeigen nur die gelieferten DB-Bilder. Ein separat geprüfter bestehender Lookup konnte für Böckels Beste/Essen trotzdem ein Bild liefern. Das ist eine gemeinsame Auslieferungs-/Anreicherungslücke, nicht automatisch ein App-Abweichungsfehler; eine Erweiterung muss kontrolliert den vorhandenen Rechte-/Identitätsregeln folgen.

## 4. Fehlgeschlagene Nachladeversuche bleiben gesperrt

FoodController.resolveMedia speichert dieID sofort in `requestedMedia`. Ein Fehler/Timeout/erfolgloses Ergebnis entfernt diese Sperre nicht; erst `loadAt` leert die Menge für einen neuen Datenabruf. PlacePhoto hält zusätzlich `failed` jeURL im lokalen Zustand. Ein späterer Callback mit derselbenURL löst keinen neuen Versuch aus. Das verstärkt vorübergehende Ladefehler. Beim Neuaufbau einer Kartenkomponente kann ein direkter Bildabruf erneut stattfinden; daher keine Aussage „bis App-Neustart grundsätzlich unmöglich“.

Maßnahme: laufend/erfolgreich/fehlgeschlagen getrennt behandeln, begrenzte Wiederholung bzw. sichtbares Wiederholen zulassen; gleichen Datenkontext und Schutz vor alten Antworten erhalten. Kein ungebremstes Nachladen und keine neue Bilderquelle.

## 5. Einzelne Adressen sind keine ladbaren Bilder

Keanaa und EIN•STAND verweisen auf Flickr-Fotoseiten: HTTP200 liefertHTML statt Bilddaten. Zuckersüss liefert beim geprüften Bild404. Bei Dortmund-Kunstbildern war derContent-Type teils `text/plain`, die Bytes waren jedoch echteWebP-Bilder: diese nicht fälschlich allein wegenHeader aussortieren. Teilweise403/503 sind Einzelmessungen und kein pauschaler Nachweis eines dauerhaften Dienst-Ausfalls. Originale Fallback-/Quellenprüfung gezielt für echte defekte Links nutzen, Bildrechte nicht umgehen.

## 6. Events gesondert betrachtet

504von533geprüften Terminvorkommen hatten direkt eine Bildadresse,29nicht. Alle13geprüften vorhandenen Eventbilder waren als Bilddateien mitHTTP200 erreichbar. Einige Antworten warenAVIF stattJPEG, daher Formatverhalten auf älterenAndroid-Versionen zusätzlich prüfen; daraus folgt kein nachgewiesener Formatfehler auf Jürgens Gerät.

Beispiele ohne Bild: „Das Kriminal Dinner“/Wesel (`mediaStatus=pending`, `enrichmentStatus=pending`), „Frühschicht“/Essen (`checked_no_media`) und „Von Ritter, Prinzessinnen und Drachen …“/Essen (`pending`). Der Feed liefert dort keine freigegebene Bilddatei. Die vorhandene Webregel unterbindet fürDB-Events bewusst einen zusätzlichen Live-Bildresolver proKarte; diesen Schutz nicht durch neue Einzelabfragen umgehen. Die Event-Anreicherung im Backend getrennt prüfen. Die übrigen13Eventbilder sind kein Beweis für alle Bilder oder für tatsächliches Rendering auf dem Gerät.

## Empfohlene Reihenfolge

1. App-Bildclient mit gültiger eigener Kennung; kontrollierteHTTPS-Ziele und begrenztes Wiederholen korrigieren. Regression: Commons/Thumb/Upload, Galerie, fehlgeschlagene Anfrage, Kategorie-/Ortswechsel; danach Geräteprüfung.
2. Defekte Fotoseiten-/Bildadressen über vorhandenen Medienresolver und bestehende Rechteprüfung behandeln; keine fachlichen Treffer ausblenden.
3. API-/Mediencache-/Backend-Anreicherung getrennt für fehlende Places- und Eventbilder prüfen. Erst dann gezielteDatenpflege, keine ungefragten Massenänderungen/Imports oder neuen Bildquellen.

Dies ist eine abgeschlossene Diagnose, keine neueAPK und keine behauptete Fehlerbehebung. App/WordPress/DB wurden nicht verändert. Technische Einzelbelege stehen in der gleichnamigenJSON-Datei.
