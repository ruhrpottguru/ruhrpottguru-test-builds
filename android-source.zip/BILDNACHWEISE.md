# Bildnachweise 0.8.0
Sieben neue Fotokacheln wurden am 19.10.2026 für diese App KI-generiert. Unveränderte PNGs in drawable-nodpi; Compose schneidet die Anzeige auf Kachelformat zu und setzt Titel/orange Fläche darüber.

| Datei | Symbolmotiv / Verwendung |
| --- | --- |
| tile_events.png | Industriegelände mit Bühne / Events |
| tile_food.png | Currywurst/Pommes / Food und Wurst |
| tile_highlights.png | Grüner Aussichtspunkt mit Industriepanorama |
| tile_kultur.png | Kleines Theater |
| tile_aktiv.png | Radweg am See |
| tile_buedchen.png | Generischer Backsteinkiosk |
| tile_industrial.png | Generisches Fördergerüst / Industriekultur, Zeitreise-Einstieg |

KI-Symbolmotive, keine Nachweise bestimmter Orte, Veranstaltungen oder historischer Zustände. Keine erfundenen Fotoquellen oder CC-Lizenzen. Prompts in ASSET_MANIFEST.json schließen Text, Logos, Marken, Wasserzeichen und erkennbare Personen aus. Sichtprüfung: passend, ohne offensichtliche Logos oder erkennbare Personen. Keine pauschale Garantie ausschließlicher Urheberrechte/rechtlicher Freigabe durch KI-Erzeugung.

Logo: unverändertes Nutzerprojektasset. Die sieben KI-Motive betreffen die Startseitenkacheln.

## Places-Fotos
Auf ausdrückliche Nutzeranweisung vom 19.10.2026 übernimmt die native Liste die vorhandenen Places-Bilder wie die Webseite. Grundlage sind die DB-Medienfelder, galleryImages, imageCropCard/Detail und vorhandene Credits, Künstler, Lizenztexte und Quellenlinks. Es gibt keine neue App-Quellenfilterung. Symboldarstellungen aus dem gemeinsamen Bestand bleiben durch deren vorhandenen Bildnachweis erkennbar.

Fehlende oder technisch nicht ladbare Bilder verwenden den vorhandenen food-media-Resolver einschließlich der bestehenden Antwortprüfung. Keine neuen Stockfotos oder Webseitenbilder recherchiert/hochgeladen. Verwendete Nachweise werden angezeigt, nicht durch erfundene Freigaben ersetzt. Fehlende Lizenzangaben werden nicht als neue Rechtsfreigabe ausgelegt. Bestehende Rechtepflichten des gemeinsamen Datenbestands bleiben erhalten.

Die vorhandenen Startmotive für Kultur und Aktivitäten sind jetzt anklickbare Kategorien. Es wurden für0.5 keine neuen Fotos generiert/beschafft. DB-Galerien/Quellen und der bereits vorhandene place-info→food-media-Medienpfad gelten auch für Kultur und Aktivitäten.

## Zeitreise-Luftbilder0.7
Keine neuen KI-Luftbilder. Die Karte lädt unveränderte RVR-/NRW-WMS-Layer der bestehenden Webseite. ©Regionalverband Ruhr stets sichtbar; RVR-Capabilities bestätigen Datenlizenz Deutschland Namensnennung2.0. NRW1980: Original-Web-Attribution mit Datenlizenz Deutschland Zero2.0, eigener Capability-/Tileabruf hier503; keine neue Lizenzfreigabe behauptet. Historische1955-Quellen behalten Hansa/Landesarchiv-Hinweis und erhalten keine pauschale Zero-Lizenz. Quellen und Diensteadressen sind im nativen Dialog verfügbar. Historische Jahresstände sind Zeitbereiche, keine garantierten Einzel-Aufnahmejahre. Belege QA/Time-Licenses.json.

Native Projektion/WMS-Berechnung anhand Leaflet1.9.4-Quelle; BSD2-Lizenz unter third-party/Leaflet-LICENSE.txt und in den App-Assets, im Quellen-Dialog lesbar. Kein Kartenbild wird für die Auslieferung neu erstellt oder als eigenes Foto ausgegeben.

## Historische Zeitreisekachel0.8
Datei tile_time_historical.jpg: unveränderte1024×512-JPEG-Antwort des RVR-WMS lubi_1952, Essen/Zollverein. ©Regionalverband Ruhr, Datenlizenz Deutschland Namensnennung2.0, https://www.govdata.de/dl-de/by-2-0. Quellenabruf und BBOX in QA/Radar-Live-0.8.json. Aufnahmezeitraum des Dienstbestands1951–1980 (überwiegend1952), keine Behauptung eines exakt datierten Einzelfotos. Native Kacheldarstellung schneidet nur die Anzeige auf das vorhandene Format zu. Nachweis direkt bei der Kachel sowie in Bildnachweisen/Quellstand. Live-Capabilities am20.10.2026 erneut200 und Lizenz bestätigt. Weitere sieben KI-Motive bleiben erhalten; Industriekultur nutzt weiterhin das generische Fördergerüst.

Büdchen-/Imbissfotos ausschließlich vorhandener DB-Bestand wie Web. Büdchen übernimmt originalen Medienresolver, Imbisskarte dessen bestehenden DB-/Platzhalterweg. Fehlende Fotos schließen keinen fachlich gültigen Eintrag aus. Radargrundkarte über vorhandenen WordPress-Proxy; ©OpenStreetMap contributors, https://www.openstreetmap.org/copyright immer sichtbar. Kein neues Stockfoto/keine KI-Historie.


## Geprüfte Bildkorrektur 0.14: Peter-Behrens-Bau
Foto: Peter-Behrens-Bau-Oberhausen-2025.jpg, Tuxyso, 17.05.2025, eigenes Werk.
Quelle: https://commons.wikimedia.org/wiki/File:Peter-Behrens-Bau-Oberhausen-2025.jpg
Lizenz: Creative Commons Namensnennung – Weitergabe unter gleichen Bedingungen 4.0 International, https://creativecommons.org/licenses/by-sa/4.0/
Datei app/src/main/assets/media/peter-behrens-bau-tuxyso-2025.jpg ist das unveränderte Original (6009×2118); eingepasste Anzeige, keine Bildbearbeitung. Die Lizenz gilt für dieses Foto. Attribution und anklickbare Quellen-/Lizenzlinks im nativen Detail.
Gezielte App-Korrektur ausschließlich Place8407 / OSMway37642158; der Datenbestand liefert weiterhin Rheinisches Industriemuseum.jpg. Kein pauschaler Ersatz aller Museumsbilder. Alle übrigen Galeriebilder bleiben erhalten; das nachgewiesen falsche Foto wird für diesen Ort entfernt.


## Optimierte interne Testversion0.15
Sieben generische KI-Fotokacheln sind WebP-Ableitungen der0.14-PNGs, Qualität88, unveränderte1536×1024Pixel. Motive, Ressourcennamen und Layout unverändert. Originale/Prompts im bisherigen Quellstand0.14 und ASSET_MANIFEST.json; reproduzierbare Kodierung tools/optimize-tiles.py. Logo, historisches RVR-Luftbild und Tuxyso-Foto bleiben unverändert. Alle bisherigen Quellen-/Lizenznachweise gelten weiter.
Release-Build mit R8 und Ressourcenoptimierung, nicht debuggable. Auslieferung weiterhin als interne Test-APK mit bisherigem Testschlüssel und Paketde.ruhrpottguru.testapp (updatefähig von0.14). Keine öffentliche/Play-Store-Freigabe oder neue Produktionsidentität. Laufzeitprüfung auf echtem Android-Gerät bleibt erforderlich, insbesondere lokale Datenengine und Bilddecoder nach Minifizierung.
