from pathlib import Path
import hashlib,json,shutil
project=Path(__file__).resolve().parents[1];src=project/'shared-source';dst=project/'app/src/main/assets/shared';dst.mkdir(parents=True,exist_ok=True)
for name in ['runtime','api']:shutil.copyfile(src/(name+'.js'),dst/(name+'.js'))
v=(src/'views.js').read_text();a=v.index('  function sortDistance(items){');b=v.index('\n\n  // V104:',a);sort=v[a:b]
a=v.index('    const filtered=s.items.filter(x=>{');b=v.index('\n    const visibleItems=',a);pred=v[a:b]
(dst/'category-food.js').write_text('(function(){\nconst RPG=window.RPGReact;\n'+sort+'\nwindow.rpgSourceSort=sortDistance;\nwindow.rpgSourceFilter=function(items,query,tagFilter,sub){\nconst category="food",s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";\n'+pred+'\nreturn filtered;\n};})();\n')
(dst/'category-highlights.js').write_text('(function(){\nconst RPG=window.RPGReact;\nwindow.rpgHighlightsFilter=function(items,query,tagFilter,sub){\nconst category="highlights",s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";\n'+pred+'\nreturn filtered;\n};})();\n')
(dst/'category-places.js').write_text('(function(){\nconst RPG=window.RPGReact;\nwindow.rpgPlaceFilter=function(category,items,query,tagFilter,sub){\nconst s={items},q=query.trim().toLowerCase(),dateFrom="",dateTo="";\n'+pred+'\nreturn filtered;\n};})();\n')
loc=(src/'location.js').read_text();a=loc.index('  function normalizePlaceKey(value){');b=loc.index('  function readUrlPlace()',a);norm=loc[a:b];a=loc.index('  function rpgMatchRuhrCity(value) {');b=loc.index('  function rpgAddressCity(',a);match=loc[a:b]
(dst/'location-helpers.js').write_text('(function(){const RPG=window.RPGReact;\n'+norm+match+'\nwindow.rpgNativeMatchCity=rpgMatchRuhrCity;})();\n')
components=(src/'components.js').read_text();a=components.index('  function mediaCropValues(crop){');b=components.index('  function mediaCropStyle(',a);c=components.index('  function cropForImage(',b);d=components.index('\n\n  function CameraGlyph',c)
api=(src/'api.js').read_text();e=api.rindex("      const image = data.imageUrl || '';");f=api.index('\n    } catch',e)
(dst/'media-layout.js').write_text('(function(){const RPG=window.RPGReact;\n'+components[a:b]+components[c:d]+'\nwindow.rpgMediaCropValues=mediaCropValues;window.rpgCropForImage=cropForImage;\nwindow.rpgNativeMediaResponse=function(item,data){\n'+api[e:f]+'\n};})();\n')
manifest={'retrieved':'2026-10-19','source':'https://www.ruhrpottguru.de/wp-content/themes/ruhrpott-guru/src/react-app/','versionQuery':'1792430876','files':{n+'.js':hashlib.sha256((src/(n+'.js')).read_bytes()).hexdigest() for n in ['runtime','api','views','location','components','main','place-events']},'extraction':'Unchanged Food/Highlights/Culture/Activities/Event predicates, event eligibility/series/order, date presets, timing/prices/calendar and media crop/response, original detail facts/sharing/forms/venue-event matching; native transport/UI bindings'}
(dst/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

import runpy
runpy.run_path(str(project/'tools/sync-events.py'))

runpy.run_path(str(project/'tools/sync-details.py'))

runpy.run_path(str(project/'tools/sync-time-travel.py'))

runpy.run_path(str(project/'tools/sync-radar.py'))
