from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).resolve().parents[1];src=p/'shared-source/time-travel-inline.js';s=src.read_text();out=p/'app/src/main/assets/shared'
a=s.index('  var shareYears=');b=s.index('\n\n  function readShareState',a);years=s[a:b]
a=s.index('    function rvrHistoric(');b=s.index('    function setStatus(',a);layers=s[a:b]
program=years+'\n'+layers+'\nprocess.stdout.write(JSON.stringify({shareYears,layers}));'
config=json.loads(subprocess.check_output(['node','-e',program],text=True))
config.update(visible=json.loads((p/'shared-source/time-travel-visible.json').read_text()),source='https://www.ruhrpottguru.de/zeitreise-von-oben/',sha256=hashlib.sha256(src.read_bytes()).hexdigest(),tileSize=256,minZoom=9,maxZoom=20)
(out/'time-travel.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n')
a=s.index('  function normalizeKey(');b=s.index('  var shareYears=',a);normalize=s[a:b]
a=s.index('    function findCityCenter(');b=s.index('    function onGlobalLocationChanged',a);city=s[a:b]
a=s.index('    function encodeShareToken(');b=s.index('    function shareUrl()',a);encoder=s[a:b]
a=s.index("    form.addEventListener('submit',function(e){")+len("    form.addEventListener('submit',function(e){");b=s.index('    function encodeShareToken(',a);search=s[a:b];search=search[:search.rindex('    });')]
text='(function(){const R=window.RPGReact;\n'+normalize+years+'\nwindow.rpgTimeShare=function(state){const currentYear=state.year,map={getCenter:()=>({lat:state.lat,lng:state.lng}),getZoom:()=>state.zoom},marker={getLatLng:()=>({lat:state.markerLat,lng:state.markerLng})};\n'+encoder+'\nreturn "https://www.ruhrpottguru.de/z/"+encodeShareToken()+"/";};\n'
text+='window.rpgTimeSearch=function(input){let result={kind:"message",status:""};const inputs={street:{value:input.street||""},number:{value:input.number||""},zip:{value:input.zip||""},city:{value:input.city||""}};const form={querySelector:selector=>inputs[(selector.match(/name="([^"]+)"/)||[])[1]]||null};class FormData{get(k){return inputs[k]&&inputs[k].value;}};const e={preventDefault:()=>{}},setStatus=msg=>{result.status=msg||"";},moveTo=(lat,lng,label)=>{result.kind="move";result.lat=lat;result.lng=lng;result.label=label;};const window={RPGReact:{...R,settings:{...R.settings,addressLocationToken:"native-transport"},api:{...R.api,post:(url,body)=>{result.kind="postcode";result.url=url;result.body=body;return new Promise(()=>{});}}}};const fetch=(url,options)=>{result.kind="address";result.url=url;result.body=JSON.parse(options.body);return new Promise(()=>{});};\n'+city+'\n(function(){\n'+search+'\n})();result.fields={street:inputs.street.value,number:inputs.number.value,zip:inputs.zip.value,city:inputs.city.value};return result;};})();\n'
(out/'time-travel-helpers.js').write_text(text)
