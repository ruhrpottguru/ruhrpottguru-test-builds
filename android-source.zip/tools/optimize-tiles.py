"""Re-encode the seven original 0.14 tile PNGs; preserve dimensions and names.
Usage: python3 tools/optimize-tiles.py /path/to/original/drawable-nodpi
Requires Pillow with WebP. Does not touch logo or documentary photographs.
"""
from pathlib import Path
from PIL import Image,ImageChops,ImageStat
import sys,json,hashlib,math
project=Path(__file__).resolve().parents[1]
source=Path(sys.argv[1]);destination=project/'app/src/main/res/drawable-nodpi'
report=[]
for name in ['aktiv','buedchen','events','food','highlights','industrial','kultur']:
 original=source/f'tile_{name}.png';target=destination/f'tile_{name}.webp'
 with Image.open(original) as image:
  image.save(target,'WEBP',quality=88,method=6)
  with Image.open(target) as compressed:
   assert compressed.size==image.size
   rms=ImageStat.Stat(ImageChops.difference(image.convert('RGB'),compressed.convert('RGB'))).rms
   mse=sum(x*x for x in rms)/3
   report.append(dict(name=name,pixels=list(image.size),originalBytes=original.stat().st_size,webpBytes=target.stat().st_size,psnrDb=round(10*math.log10(255**2/mse),2),originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),webpSha256=hashlib.sha256(target.read_bytes()).hexdigest(),quality=88))
 local=destination/original.name
 if local.exists():local.unlink()
(project/'QA/Optimierung-0.15-Bilder.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'originalBytes':sum(x['originalBytes'] for x in report),'webpBytes':sum(x['webpBytes'] for x in report),'minPsnrDb':min(x['psnrDb'] for x in report)}))
