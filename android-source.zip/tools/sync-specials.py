from pathlib import Path
p=Path(__file__).resolve().parents[1];v=(p/'shared-source/specials-views.js').read_text();out=p/'app/src/main/assets/shared/special-helpers.js'
def section(a,b):return v[v.index(a):v.index(b,v.index(a))]
helpers=section('  function homeEventDayAccess(','  function useCategoryItems(')
pipeline=section('            let items=raw.map(x=>RPG.normalizeEvent(x,location))','            if(live)setState({loading:false,error:')
halloween=section('  function halloweenFold(','  function HalloweenView(')
christmas=section('  const CHRISTMAS_CATEGORIES=','  function ChristmasView(')
countdown=section('  function halloweenTargetDate(','  function HalloweenHomeTeaser(')
routeSource=v[v.index('  function RouteView('):]
route=routeSource[routeSource.index("        const normalized=RPG.normalizePlace(x.element,'highlights',location);"):routeSource.index('        return h(C.Card,{key:x.slug,item:normalized,onOpen});')]
fallback=section('    const detailItem={','    return h(\'button\',{type:\'button\',className:\'rpgx-card rpgx-route-fallback-card\'')
text='(function(){const RPG=window.RPGReact;\n'+helpers+countdown+halloween+christmas
text+='\nwindow.rpgSpecialListing=function(raw,location,radius,mode){const home=false,eventWindow="";\n'+pipeline+'\nreturn {items:localItems,baseItems,effectiveRadius:effective};};\n'
text+='window.rpgRouteItem=function(x,location){if(x.element){\n'+route+'\nif(x.distanceKm==null)normalized.distanceKm=RPG.normalizePlace(x.element,\'highlights\',location).distanceKm;normalized._rpgNearTermKey="route:"+x.slug;normalized._nativeRoute=x;return normalized;}const item=x,image=String(x.fallbackImage||""),distance=Number(x.distanceKm),lat=Number(x.fallbackLat),lng=Number(x.fallbackLng);\n'+fallback+'\nif(x.fallbackLat==null||x.fallbackLng==null)detailItem.coords=null;if(x.distanceKm==null)detailItem.distanceKm=null;detailItem._rpgNearTermKey="route:"+x.slug;detailItem._nativeRoute=x;return detailItem;};\n'
text+='''window.rpgSpecialQuery=function(items,mode,filter,city){
 if(mode==='route'){
  const cities=Array.from(new Set(items.map(x=>x.city).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'de'));
  const filters=[['all','Alle'],['anchor','Ankerpunkte'],['panorama','Panoramen'],['settlement','Siedlungen']];
  return {items:items.filter(x=>(filter==='all'||x.routeType===filter)&&(!city||x.city===city)),filters:filters.map(([key,label])=>({key,label,count:items.filter(x=>key==='all'||x.routeType===key).length})),cities,count:items.length,kicker:'Offizielle Primärstandorte im Ruhrgebiet'};
 }
 if(mode==='halloween'){
  const matches=dedupeHalloweenSeries(items.filter(isHalloweenEvent)).map(item=>Object.assign({},item,{halloweenKind:halloweenEventKind(item)}));
  const filters=[['all','Alle'],['family','Familie'],['party','Party & Nacht'],['horror','Grusel & Horror']];
  return {items:filter==='all'?matches:matches.filter(item=>item.halloweenKind===filter),filters:filters.map(([key,label])=>({key,label,count:matches.filter(x=>key==='all'||x.halloweenKind===key).length})),cities:[],count:matches.length,kicker:halloweenCountdown(new Date())};
 }
 const matches=items.map(item=>({item,categories:christmasCategories(item)})).filter(x=>x.categories.length);
 return {items:matches.filter(x=>x.categories.includes(filter)).map(x=>x.item),filters:CHRISTMAS_CATEGORIES.map(([key,label])=>({key,label,count:matches.filter(x=>x.categories.includes(key)).length})),cities:[],count:matches.length,kicker:'Advent & Weihnachten im Ruhrgebiet'};
};
window.rpgSpecialDefault=mode=>mode==='weihnachten'?'weihnachtsmaerkte':'all';
window.rpgSpecialQA={isHalloweenEvent,halloweenEventKind,dedupeHalloweenSeries,halloweenSpecialCompare,christmasCategories,christmasSeasonYear};
})();
'''
out.write_text(text)
