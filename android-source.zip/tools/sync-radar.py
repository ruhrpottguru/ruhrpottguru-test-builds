from pathlib import Path
p=Path(__file__).resolve().parents[1];v=(p/'shared-source/views.js').read_text();dst=p/'app/src/main/assets/shared/radar-helpers.js'
def part(a,b):return v[v.index(a):v.index(b,v.index(a))]
base=part('  const BUDE_FEATURES=[','  function BudePlaceholder()')+part('  const WURST_FILTERS=[','  function WurstPlaceholder()')
quality=part('    const qualitySelect=(normalized)=>{','    const updateMapScope=')
bfilter=part('    const filtered=useMemo(()=>activeItems.filter(item=>{','    const timeKeys=')
bfilter=bfilter[:bfilter.index('    }),[activeItems,filters]);')].replace('    const filtered=useMemo(()=>activeItems.filter(item=>{','return activeItems.filter(item=>{')+'});'
toggle=part("    const timeKeys=['open']",'    const radiusSteps=[1,2.5,5,10,25];').replace('    const toggle=key=>setFilters(current=>{','    const toggle=(current,key)=>{').replace('    });','    };')
wfilter=part('      let out=state.items.filter(x=>filter===','    },[state.items,filter,sort,query]);')
text='(function(){const RPG=window.RPGReact;\n'+base+quality+toggle+'''
window.RadarRules={
select(raw,point,category){
 if(category==='buedchen')return qualitySelect(raw.map(x=>RPG.normalizePlace(x,'buedchen',point)).sort((a,b)=>(a.distanceKm??999)-(b.distanceKm??999)));
 return raw.map(x=>{const item=RPG.normalizePlace(x,'wurst',point);item.labels=wurstMenuItems(item).map(v=>v.charAt(0).toUpperCase()+v.slice(1));item.subtitle='Imbissbude';return item;});
},
buedchen(activeItems,filters){\n'''+bfilter+'''\n},
wurst(items,filter,query,sort){const state={items};\n'''+wfilter+'''\n},
toggle,
features:BUDE_FEATURES,
filters:WURST_FILTERS,
facts(item){return item.category==='buedchen'?{features:BUDE_FEATURES.filter(x=>budeFeature(item,x[0])).map(x=>({key:x[0],label:x[2]})),opening:openingState(item.openingHours),formatted:RPG.formatOpeningHours(item.openingHours)}:{menu:wurstMenuItems(item),tier:((item.tags||{})['rg:wurst_tier']==='B'&&(item.tags||{})['rg:wurst_review_status']!=='confirmed')?'Im Radar':'Geprüft'};}
};})();\n'''
dst.write_text(text)
