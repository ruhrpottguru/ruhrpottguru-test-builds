from pathlib import Path
p=Path(__file__).resolve().parents[1];src=p/'shared-source';out=p/'app/src/main/assets/shared';c=(src/'components.js').read_text();pe=(src/'place-events.js').read_text()
def function(name):
 a=c.index('  function '+name+'(');b=c.index('\n  function ',a+5);return c[a:b]
a=c.index('    const meta=RPG.CATEGORIES[item.category]');b=c.index('\n    function toggleSaved()',a);facts=c[a:b]
a=c.index('      let url=RPG.buildShareUrl(item);');b=c.index('\n      if(navigator.share)',a);sharing=c[a:b]
a=c.index('  const CONTRIBUTION_FIELDS=');b=c.index('\n\n  function ContributionForm',a);fields=c[a:b]
a=c.index('    const hasData=Object.values(fields)');b=c.index('    const submit=async()=>{',a);validate=c[a:b]
a=c.index('      const clean={};',b);b=c.index("      setStatus('sending');",a);payload=c[a:b]
a=c.index("      if(!images.length){setStatus('Bitte wähle mindestens ein Foto aus. Ein Bild ist",c.index('  function CommunityStoryForm'));b=c.index('      const fd=new FormData();',a);storyValidate=c[a:b];a=b;b=c.index("      setStatus('sending');",a);storyPayload=c[a:b]
text='(function(){const RPG=window.RPGReact,eventAllDayValue=window.rpgEventAllDayValue;\n'+function('routeTypeLabel')+'\n'+function('eventTypeBadgeMeta')+'\n'+fields+'\nwindow.rpgContributionFields=CONTRIBUTION_FIELDS;\n'
text+='window.rpgDetailFacts=function(item,foodInfo=null){const onTagFilter=()=>{};\n'+facts+'\nreturn {description,website:effectiveWebsite,menu:effectiveMenuUrl,reservation:effectiveReservationUrl,opening,openingStatus,price,glance:eventGlanceFacts,routeType,routeIndustrial:!!item.routeIndustrial,routeOfficialUrl:item.routeOfficialUrl||""};};\n'
text+='window.rpgDetailShare=function(item,mode,inviteMessage,inviteDuration){\n'+sharing+'\nreturn payload;};\n'
text+='class FormData{constructor(){this.fields={};}append(k,v){if(!/^image_\\d+$/.test(k))this.fields[k]=String(v);}}\n'
text+='window.rpgContributionPayload=function(item,input){const photoOnly=false,processingImages=false,fields=input.fields||{},images=(input.images||[]).map(x=>({...x,file:{name:x.name}})),rights=!!input.rights,submitterName=input.name||"",submitterEmail=input.email||"",sender=input.sender||"community";\n'+validate+'\nif(!canSend)return {error:validationMessage()};\n'+payload+'\nreturn {fields:fd.fields};};\n'
text+='window.rpgStoryPayload=function(item,input){const title=input.title||"",content=input.content||"",nickname=input.name||"",email=input.email||"",instagram=input.instagram||"",images=input.images||[],rights=!!input.rights,terms=!!input.terms,privacy=!!input.privacy,maxFiles=5;let error="";const setStatus=s=>{error=s;};(function(){\n'+storyValidate+'\n})();if(error)return {error};\n'+storyPayload+'\nreturn {fields:fd.fields};};\n'
text+=function('communityInstagram')+'\nwindow.rpgCommunityInstagram=communityInstagram;})();\n'
(out/'detail-helpers.js').write_text(text)
a=pe.index('        const id=Number(event.raw');b=pe.index("        return h('a'",a)
text=(out/'detail-helpers.js').read_text();text+='\nwindow.rpgPlaceEventRow=function(event){const RPG=window.RPGReact;\n'+pe[a:b]+'\nreturn {eventId:id,title:event.title,date:when,canonicalUrl:href};};\n';(out/'detail-helpers.js').write_text(text)
(out/'place-events-native.js').write_text(pe[:pe.index('  function PlaceEvents(')]+'window.rpgResetPlaceEventCache=()=>cache.clear();})(window);\n')
