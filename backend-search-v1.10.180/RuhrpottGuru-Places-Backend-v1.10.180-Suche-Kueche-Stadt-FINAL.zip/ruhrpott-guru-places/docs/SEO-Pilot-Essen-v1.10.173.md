# SEO-Pilot Essen – Backend v1.10.173

Geprüfter Installationsstand auf Basis v1.10.172; nicht automatisch veröffentlicht. Installation durch Jürgen als Ersatz des vorhandenen Places-Plugins. Theme bleibt v350.0; keine App-Datei verändert.

## Verhalten und Scope
Nur die bestehende WordPress-Seite mit URI stadt/essen/restaurants erhält eine Liste von höchstens12 Food-Orten. Überschrift: Food & Drinks im10-km-Umkreis von Essen. Die Auswahl kann Restaurants, Bars, Cafés und Imbisse umfassen, entsprechend dem unveränderten Food-Anbieter; kein Top-/Restaurant-only-Versprechen. Bestehender Text/Zählstand1212 bleibt unberührt und wurde nicht neu validiert.
Der the_content-Filter läuft mit Priorität19 vor dem bestehenden WPCode3421-Layoutfilter20. Er ruft die vorhandene rest_home-Methode intern mit category food, lat51.45657, lng7.01228, radiusKm10, limit12 auf. Es gibt keinen HTTP-Selbstaufruf, keine neue SQL-/Rankinglogik, keinen neuen REST-Vertrag. Vorhandene Canonicals aus elements.tags werden übernommen und auf Home-URL/Place-ID geprüft. Keine Voraussetzung für Bilder. Nulltreffer/Datenfehler lassen den bisherigen Inhalt unverändert.
Nur Frontend-Hauptinhalt der exakt passenden Seite; kein Admin/REST/Feed/Nebenloop, keine anderen Kategorien oder Städte. Vorhandene Inhalte mit Pilotmarker werden nicht erneut ergänzt. Keine eigenen Meta-/Canonical-/Schema-/H1-Filter. Alle bestehenden Produktionsmethoden und Datenlogiken bleiben bytegleich; hinzu kommen Hook/Methoden sowie Versionsmetadaten.

## Prüfungen
29 lokale PHP-Checks, davon12 Reihenfolgeprüfungen mit echtem zuvor abgerufenem Food-Feed. Requestvertrag, Scopegates, Idempotenz, Ausfall,503,WP_Error,Nulltreffer,Escaping/URL-Identität/bildfreie Treffer. Originaler aktuell gelesener WPCode3421 erhält die Liste in seiner Seitenschale. Weitere22 bestehende Backend-Regressionschecks auf dem Kandidaten bestanden (u.a. Radar-SQL bytegleich, Trinkhallen-Zulassung, Sitemap, sichere Bootstrap-Daten). PHP8.3-Syntaxprüfung gültig.
Isolierte WordPress-Vorschau per temporärem Theme-Testadapter: installierte Backenddatei vor Test exakt gegen Ausgangs-SHA256 geprüft, Kandidat nur im Speicher ausgeführt; kein Konstruktor/Migration/Cron der Testklasse. Browser zeigt12 sichtbare Links nach React-Mount; Klick auf Tacolicious öffnet passende vollständige Detailseite; Browser-Zurück zur Stadtseite. Keine horizontale Überbreite im geprüften Desktopfenster. Einzelne Browserabfrage lief in Timeout; anschließende Zustandsprüfung bestätigte erfolgreiches Ziel.
HTTP-Integration: Live-Stadtseite0 Ortslinks, Vorschau12 initiale Ortslinks. Title/H1-Zahl/Description/Canonical/JSON-LD bytegleich zum Live-HTML; Kontrollseite food ohne Pilotblock. Der Require wurde nach Abschluss aus dem Entwurf entfernt. Die anschließende Löschung der nun ungeladenen QA-Datei im Entwurf wurde durch das WPVibe-Tageslimit blockiert. Diese Datei ist nicht im Installations-ZIP; der Entwurf darf nicht veröffentlicht werden. Auf Live ist keine QA-Datei eingebunden. Kein Theme-Publish und keine Datenbankmutation.

## Grenzen
Die bestehenden Plain-WP-Seiten liefern ihre Inhalte in hidden/inert als Quelle für PlainWpView aus; dieser bestehende Themeweg bleibt unverändert. Links sind serverseitig im HTML und nach React-Mount sichtbar. Es wird keine vollständig sichtbare No-JS-Seite oder garantierte Google-Indexierung behauptet. Kein echter Android-/GPS-Test und keine vollständige Google-Crawl-Abnahme. GSC Wizard war beim früheren Zugriff subscription_required; keine kostenpflichtige Nutzung. Der neue Filter ist nur für den Essen-Piloten aktiviert, nicht für alle53Städte. Unbekannte Daten/Fehler werden nicht als Treffer ergänzt. Der vorhandene Food-Detailrückweg Entdecken führt zur Startseite; dies ist ein separater bestehender Navigationsbefund, nicht verändert.

## Installation und Rücknahme
WordPress Plugins → Installieren → Plugin hochladen → ZIP wählen → vorhandenes Plugin ersetzen. Danach die Stadtseite ohne Vorschauparameter prüfen. Bei Problemen kann das unverändert bereitgehaltene v1.10.172-ZIP das Plugin ersetzen. Keine neue Deinstallation, kein Zurücksetzen von Tabellen/Optionen nötig. Keine neue Schema-Migration oder Importplanung eingeführt.

## Vollständiger Produktionsdiff
```diff
--- a/ruhrpott-guru-places.php
+++ b/ruhrpott-guru-places.php
@@ -2,7 +2,7 @@
 /**
  * Plugin Name: RuhrpottGuru Places Backend
  * Description: Persistenter Places-Katalog für Food, Highlights, Kultur und Aktivitäten sowie Spezial-Inventare für Büdchen und „Hier geht’s um die Wurst“ in der Metropole Ruhr. OSM wird nur für Import/Sync verwendet; Besucher lesen aus MySQL. Mit automatischem OSM-Rollback bis der Katalog vollständig validiert ist.
- * Version: 1.10.172
+ * Version: 1.10.173
  * Author: RuhrpottGuru
  * License: GPL-2.0-or-later
  */
@@ -179,7 +179,7 @@
     // 0-14 Tage alle 4 Stunden, 0-90 Tage taeglich, kompletter 0-365-Tage-
     // Master woechentlich. Laufende Master-/Supplemental-Wellen werden nie
     // abgebrochen; der Dispatcher wartet, bis der Event-Importpfad frei ist.
-    const VERSION = '1.10.172';
+    const VERSION = '1.10.173';
     const ACTIVITY_V2_SPEC_VERSION = '1.4';
     const SCHEMA_VERSION = '1.10.129';
     const OPTION_STATUS = 'rg_places_status';
@@ -267,6 +267,7 @@
         add_action('template_redirect', array($this, 'maybe_render_seo_landing_v101096'), -30);
         add_action('template_redirect', array($this, 'prepare_city_guide_seo_v101144'), -25);
         add_action('wp_head', array($this, 'render_city_guide_seo_head_v101144'), 1);
+        add_filter('the_content', array($this, 'append_essen_food_links_pilot_v101173'), 19);
         add_filter('cron_schedules', array($this, 'cron_schedules'));
         add_action(self::CRON_HOOK, array($this, 'cron_sync_tick'));
         add_action(self::ACTIVITY_COVERAGE_HOOK, array($this, 'cron_activity_source_coverage_tick_v1089'));
@@ -3171,6 +3172,50 @@
     private function sanitize_category($category) {
         $category = strtolower(trim((string) $category));
         return in_array($category, array('food','highlights','culture','activities'), true) ? $category : '';
+    }
+
+    /** Pilot only: reuse the public Food resolver and its canonical URLs.
+     * Runs before the existing city-category shell (WPCode 3421, priority 20).
+     * No REST contract, category selection, ranking or location writes change.
+     */
+    public function append_essen_food_links_pilot_v101173($content) {
+        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST) || is_feed()
+            || !is_singular('page') || !is_main_query() || !in_the_loop()
+            || (int)get_the_ID() !== (int)get_queried_object_id()
+            || get_page_uri(get_queried_object_id()) !== 'stadt/essen/restaurants'
+            || strpos($content, 'id="rpg-essen-food-detail-links"') !== false) return $content;
+        try {
+            $request = new WP_REST_Request('POST', '/ruhrpottguru/v1/places/home');
+            $request->set_header('content-type', 'application/json');
+            $request->set_body(wp_json_encode(array('category'=>'food', 'lat'=>51.45657, 'lng'=>7.01228, 'radiusKm'=>10, 'limit'=>12)));
+            $response = $this->rest_home($request);
+            if (is_wp_error($response)) return $content;
+            $response = rest_ensure_response($response);
+            if ($response->get_status() !== 200) return $content;
+            $data = $response->get_data();
+            if (!is_array($data) || empty($data['ok']) || !isset($data['elements']) || !is_array($data['elements'])) return $content;
+            return $content . $this->seo_city_food_links_html_v101173($data['elements']);
+        } catch (Throwable $error) {
+            // An unavailable data feed must not break the existing city page.
+            return $content;
+        }
+    }
+
+    private function seo_city_food_links_html_v101173($elements) {
+        $links = array();
+        foreach (array_slice($elements, 0, 12) as $element) {
+            $tags = is_array($element) && isset($element['tags']) && is_array($element['tags']) ? $element['tags'] : array();
+            $id = (string)($tags['rg:place_id'] ?? '');
+            $name = trim((string)($tags['name'] ?? ''));
+            $url = (string)($tags['rg:canonical_url'] ?? '');
+            if (!preg_match('/^[1-9][0-9]*$/', $id) || $name === ''
+                || strpos($url, home_url('/ort/' . $id . '/')) !== 0) continue;
+            $links[] = '<li><a href="' . esc_url($url) . '">' . esc_html($name) . '</a></li>';
+        }
+        if (!$links) return '';
+        return '<section id="rpg-essen-food-detail-links" aria-labelledby="rpg-essen-food-links-title">'
+            . '<h2 id="rpg-essen-food-links-title">Food &amp; Drinks im 10-km-Umkreis von Essen</h2>'
+            . '<ul>' . implode('', $links) . '</ul></section>';
     }
 
     public function rest_home(WP_REST_Request $request) {

```

## Gemessene HTTP-Resultate
```json
[
  {
    "url": "https://www.ruhrpottguru.de/stadt/essen/restaurants/",
    "status": 200,
    "h1": 1,
    "description": [
      "Entdecke Restaurants, Cafés, Imbisse und Food-Spots in Essen. Mehr als 1.200 Orte für Essen und Trinken auf RuhrpottGuru."
    ],
    "canonical": [
      "https://www.ruhrpottguru.de/stadt/essen/restaurants/"
    ],
    "title": [
      "Restaurants in Essen – Essen & Food entdecken | RuhrpottGuru"
    ],
    "schema": [
      "{\"@context\":\"https://schema.org\",\"@type\":\"CollectionPage\",\"name\":\"Restaurants & Food in Essen\",\"url\":\"https://www.ruhrpottguru.de/stadt/essen/restaurants/\",\"description\":\"Entdecke Restaurants, Cafés, Imbisse und Food-Spots in Essen. Mehr als 1.200 Orte für Essen und Trinken auf RuhrpottGuru.\",\"isPartOf\":{\"@type\":\"WebSite\",\"name\":\"RuhrpottGuru\",\"url\":\"https://www.ruhrpottguru.de/\"},\"about\":{\"@type\":\"City\",\"name\":\"Essen\"},\"breadcrumb\":{\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"RuhrpottGuru\",\"item\":\"https://www.ruhrpottguru.de/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Städte\",\"item\":\"https://www.ruhrpottguru.de/stadt/\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Essen\",\"item\":\"https://www.ruhrpottguru.de/stadt/essen/\"},{\"@type\":\"ListItem\",\"position\":4,\"name\":\"Restaurants & Food\",\"item\":\"https://www.ruhrpottguru.de/stadt/essen/restaurants/\"}]}}"
    ],
    "links": 0,
    "pilot": 0,
    "qa_marker": false
  },
  {
    "url": "https://www.ruhrpottguru.de/stadt/essen/restaurants/?wpvibe_preview=qu4TFI3CiHNdvbnLBWLZWtKW0U2uwo1D",
    "status": 200,
    "h1": 1,
    "description": [
      "Entdecke Restaurants, Cafés, Imbisse und Food-Spots in Essen. Mehr als 1.200 Orte für Essen und Trinken auf RuhrpottGuru."
    ],
    "canonical": [
      "https://www.ruhrpottguru.de/stadt/essen/restaurants/"
    ],
    "title": [
      "Restaurants in Essen – Essen & Food entdecken | RuhrpottGuru"
    ],
    "schema": [
      "{\"@context\":\"https://schema.org\",\"@type\":\"CollectionPage\",\"name\":\"Restaurants & Food in Essen\",\"url\":\"https://www.ruhrpottguru.de/stadt/essen/restaurants/\",\"description\":\"Entdecke Restaurants, Cafés, Imbisse und Food-Spots in Essen. Mehr als 1.200 Orte für Essen und Trinken auf RuhrpottGuru.\",\"isPartOf\":{\"@type\":\"WebSite\",\"name\":\"RuhrpottGuru\",\"url\":\"https://www.ruhrpottguru.de/\"},\"about\":{\"@type\":\"City\",\"name\":\"Essen\"},\"breadcrumb\":{\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"RuhrpottGuru\",\"item\":\"https://www.ruhrpottguru.de/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Städte\",\"item\":\"https://www.ruhrpottguru.de/stadt/\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Essen\",\"item\":\"https://www.ruhrpottguru.de/stadt/essen/\"},{\"@type\":\"ListItem\",\"position\":4,\"name\":\"Restaurants & Food\",\"item\":\"https://www.ruhrpottguru.de/stadt/essen/restaurants/\"}]}}"
    ],
    "links": 12,
    "pilot": 1,
    "qa_marker": true
  },
  {
    "url": "https://www.ruhrpottguru.de/food/?wpvibe_preview=qu4TFI3CiHNdvbnLBWLZWtKW0U2uwo1D",
    "status": 200,
    "h1": 1,
    "description": [
      "Entdecke Restaurants, Cafés, Imbisse und besondere Food-Spots im Ruhrgebiet – passend zu deinem Standort und deiner Umgebung."
    ],
    "canonical": [
      "https://www.ruhrpottguru.de/food/"
    ],
    "title": [
      "Restaurants & Essen im Ruhrgebiet | RuhrpottGuru"
    ],
    "schema": [
      "{\"@context\":\"https://schema.org\",\"@graph\":[{\"@type\":\"Organization\",\"@id\":\"https://www.ruhrpottguru.de/#organization\",\"name\":\"RuhrpottGuru\",\"url\":\"https://www.ruhrpottguru.de/\",\"description\":\"Regionaler Freizeit- und Erlebnisguide für das Ruhrgebiet und die Metropole Ruhr.\",\"areaServed\":{\"@type\":\"AdministrativeArea\",\"name\":\"Metropole Ruhr\"}},{\"@type\":\"WebSite\",\"@id\":\"https://www.ruhrpottguru.de/#website\",\"url\":\"https://www.ruhrpottguru.de/\",\"name\":\"RuhrpottGuru\",\"description\":\"Events, Essen &amp; Freizeit im Ruhrgebiet\",\"publisher\":{\"@id\":\"https://www.ruhrpottguru.de/#organization\"},\"inLanguage\":\"de-DE\",\"potentialAction\":{\"@type\":\"SearchAction\",\"target\":{\"@type\":\"EntryPoint\",\"urlTemplate\":\"https://www.ruhrpottguru.de/suche/?q={search_term_string}\"},\"query-input\":\"required name=search_term_string\"}},{\"@type\":\"WebPage\",\"@id\":\"https://www.ruhrpottguru.de/food/#primary\",\"url\":\"https://www.ruhrpottguru.de/food/\",\"name\":\"Restaurants & Essen im Ruhrgebiet | RuhrpottGuru\",\"description\":\"Entdecke Restaurants, Cafés, Imbisse und besondere Food-Spots im Ruhrgebiet – passend zu deinem Standort und deiner Umgebung.\",\"inLanguage\":\"de-DE\",\"isPartOf\":{\"@id\":\"https://www.ruhrpottguru.de/#website\"},\"publisher\":{\"@id\":\"https://www.ruhrpottguru.de/#organization\"},\"datePublished\":\"2026-07-30T22:39:39+00:00\",\"dateModified\":\"2026-09-27T19:46:53+00:00\"}]}"
    ],
    "links": 0,
    "pilot": 0,
    "qa_marker": true
  }
]
```
